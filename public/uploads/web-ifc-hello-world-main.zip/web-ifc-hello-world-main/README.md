Exemplo seguindo a documentação do 'web-ifc-three' e mais alguns passos:
 - Adicionar '.js' no OrbitControls
 - Adicionar '.js' no three/examples/jsm/utils/BufferGeometryUtils dentro do node_modules que dá erro