// app/(auth)/components/SignUpForm.tsx
'use client';

import React, { useState, useTransition } from 'react';
import { registerUserWithEmailVerification } from '@/app/(auth)/actions/registerUserWithEmailVerification';
import { TextField, Button, Box, InputAdornment, IconButton } from '@mui/material';
import toast from 'react-hot-toast';
import Link from 'next/link';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

function SignUpForm() {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('Customer');
  const [showPassword, setShowPassword] = useState(false);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = (e) => {
    e.preventDefault();

    startTransition(async () => {
      const response = await registerUserWithEmailVerification({ email, name, password, role, company });
      if (response.error) {
        toast.error(response.error);
      } else {
        toast.success('A verification email has been sent. Please check your inbox.');
        // Optionally, you can redirect the user or clear the form fields here
      }
    });
  };

  return (
    <Box component="form" onSubmit={handleSubmit} noValidate>
      <TextField
        sx={{ width: '100%', mb: 2 }}
        required
        fullWidth
        label="Email"
        autoFocus
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
        <TextField
			sx={{ width: '100%', mb: 2 }}
			required
			fullWidth
			label="Company Name"
			autoFocus
			value={company}
			onChange={(e) => setCompany(e.target.value)}
		/>
      <TextField
        sx={{ width: '100%', mb: 2 }}
        required
        fullWidth
        label="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <TextField
        sx={{ width: '100%', mb: 2 }}
        label="Password"
        type={showPassword ? 'text' : 'password'}
        variant="outlined"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={() => setShowPassword(!showPassword)}
                onMouseDown={(e) => e.preventDefault()}
                edge="end"
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          ),
        }}
      />
      <Button
        sx={{ width: '100%', fontSize: '1rem', fontWeight: 'bold', color: 'white', height: 56 }}
        type="submit"
        fullWidth
        variant="contained"
        disabled={isPending}
      >
        {isPending ? 'Signing Up...' : 'Sign Up'}
      </Button>
      <Link href="/auth/login" className="py-4">
        <p className="text-secondary-light text-start py-4">
          Do you have an account? <span className="text-[#0066c0]">Sign in.</span>
        </p>
      </Link>
    </Box>
  );
}

export default SignUpForm;
