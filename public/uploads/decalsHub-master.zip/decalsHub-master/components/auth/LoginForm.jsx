'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession, signIn } from 'next-auth/react';
import {
  TextField, InputAdornment, IconButton, Button, CircularProgress,
} from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import useValidation from '@/hooks/useValidation';
import Link from 'next/link';

function LoginForm() {
  const session = useSession();
  const router = useRouter();
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loginError, setLoginError] = useState('');
  const { validateLogin, errors } = useValidation();

  useEffect(() => {
    if (session.status === 'loading') return;
    if (session.status === 'authenticated') {
      if (session.data.user.role === 'Admin') router.push('/dashboard');
      else router.push('/account/products');
    }
  }, [router, session]);

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleSignIn = async () => {
    setIsLoading(true);
    setLoginError(''); // Сбрасываем ошибки перед каждой попыткой

    const credentials = { signIn: true, login, password };
    const response = await signIn('credentials', { ...credentials, redirect: false });

    setIsLoading(false);

    if (response.error) {
      setLoginError(response.error);
    } else if (response.ok) {
      if (session.status === 'authenticated') {
        const userRole = session.data.user.role;
        if (userRole === 'Admin') {
          router.push('/dashboard');
        } else if (userRole === 'Customer') {
          router.push('/account');
        }
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (validateLogin(login, password)) {
      await handleSignIn();
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        sx={{ width: '100%', mb: 2 }}
        label="Login or email"
        variant="outlined"
        value={login}
        onChange={(e) => setLogin(e.target.value)}
        error={!!errors.login}
        helperText={errors.login}
      />
      <TextField
        sx={{ width: '100%', mb: 2 }}
        label="Password"
        type={showPassword ? 'text' : 'password'}
        variant="outlined"
        value={password}
        onChange={handlePasswordChange}
        error={!!errors.password}
        helperText={errors.password}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
                edge="end"
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          ),
        }}
      />
      {loginError && (
        <p className="text-red-500 mb-2 text-sm md:text-base border border-red-500 bg-red-100 rounded px-4 py-2">
          {loginError}
        </p>
      )}
      {isLoading ? (
        <CircularProgress />
      ) : (
        <Button
          sx={{ width: '100%', fontSize: '1rem', fontWeight: 'bold', color: 'white', height: 56 }}
          variant="contained"
          type="submit"
          disabled={isLoading}
        >
          Log in
        </Button>
      )}
      <Link href="/auth/sign-up" className="py-4">
        <p className="text-secondary-light text-start py-4">
          Don't have an account? <span className="text-[#0066c0]">Sign up to get one.</span>
        </p>
      </Link>
    </form>
  );
}

export default LoginForm;
