"use client"
import {IconButton, Button, TableRow, TableCell, Collapse, Box, Table, TableHead, TableBody} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import {useState} from "react"
import MaterialForm from "./MaterialForm"
import makeApiRequest from "@/libs/makeApiRequest"
import toast from "react-hot-toast"
function Row({defaultValue, category, onDelete, index}) {
	const [isEditing, setIsEditing] = useState(false)
	const [material, setMaterial] = useState(defaultValue)
	const handleSubmit = response => {setMaterial({...material, ...response}); setIsEditing(false)}
	async function handleDelete() {
		await makeApiRequest("/api/deleteMaterial", {id: material.id}).catch(e => toast.error(e.message))
		onDelete(index)
	}
	return (
		<>
			{
				isEditing ? (
					<MaterialForm 
						onSubmit={handleSubmit} 
						onCancel={() => setIsEditing(false)}
						defaultValue={{...material, cost: material.cost / 100}}
						makeApiRequest={body => makeApiRequest("/api/editMaterial", {...body, id: material.id})}
					/>
				) : material ? (
					<TableRow key={category.id + material.id}>
						<TableCell />
						<TableCell>{material.name}</TableCell>
						<TableCell>{material.cost / 100}</TableCell>
						<TableCell>{material.markup}</TableCell>
						<TableCell>{material.markup * material.cost / 100}</TableCell>
						<TableCell>
							<IconButton onClick={handleDelete}><DeleteIcon /></IconButton>
							<IconButton onClick={() => setIsEditing(true)}><EditIcon /></IconButton>
						</TableCell>
					</TableRow>
				) : (
					<MaterialForm 
						onSubmit={handleSubmit}
						onCancel={() => onDelete(index)}
						makeApiRequest={body => makeApiRequest("/api/createMaterial", {...body, categoryId: category.id})}
					/>
				)
			}
		</>
	)
}
export default function MaterialsTable({category, isOpen}) {
	const [materials, setMaterials] = useState(category.materials)
	const [createdMaterials, setCreatedMaterials] = useState([])
	return (
		<TableRow>
			<TableCell style={{paddingBottom: 0, paddingTop: 0}} colSpan={6}>
				<Collapse in={isOpen} timeout="auto" unmountOnExit>
					<Box sx={{margin: 1}}>
						<Box className="mb-5">
							<Button
								color="primary"
								variant="contained"
								sx={{color: 'white'}}
								startIcon={<AddIcon />}
								onClick={() => setCreatedMaterials(materials => [materials.length, ...materials])}
							>
								Add material
							</Button>
						</Box>
						<Table size="small" aria-label="items">
							<TableHead>
								<TableRow>
									<TableCell />
									<TableCell>Name</TableCell>
									<TableCell>Cost</TableCell>
									<TableCell>Markup</TableCell>
									<TableCell>Price</TableCell>
									<TableCell>Actions</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{createdMaterials.map(index => (
									<Row key={`created-${index}`}
										onDelete={index => setCreatedMaterials(materials => materials.filter(materialIndex => materialIndex != index))} 
										category={category} 
										index={index}
									/>
								))}
								{materials?.map(material => (
									<Row 
										key={material.id}
										defaultValue={material}
										category={category}
										index={material.id}
										onDelete={index => setMaterials(materials => materials.filter(material => material.id != index))}
									/>
								))}
							</TableBody>
						</Table>
					</Box>
				</Collapse>
			</TableCell>
		</TableRow>
	)
}