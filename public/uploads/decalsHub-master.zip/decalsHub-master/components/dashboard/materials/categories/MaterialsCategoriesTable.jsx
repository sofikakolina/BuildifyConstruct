"use client"
import React, {useEffect, useState} from "react"
import theme from "@/theme"
import {Button, ThemeProvider, CircularProgress, Box, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Typography} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown"
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp"
import makeApiRequest from "@/libs/makeApiRequest"
import MaterialsTable from "../MaterialsTable"
import MaterialsCategoryForm from "./MaterialsCategoryForm"
import toast from "react-hot-toast"
const styles = {
	mainBox: {display: "flex", flexDirection: "column", gap: "32px", py: "2rem"},
	headerBox: {display: "flex", justifyContent: "space-between"},
	title: {fontSize: "48px", fontWeight: "medium"},
	addButton: {color: "white", px: 3, py: 1, fontSize: '0.9rem'}
}
function Row({defaultValue, index, onDelete}) {
	const [isOpen, setIsOpen] = useState(false)
	const [isEditing, setIsEditing] = useState(false)
	const [category, setCategory] = useState(defaultValue)
	const handleSubmit = response => {setCategory({...category, ...response}); setIsEditing(false)}
	async function handleDelete() {
		await makeApiRequest("/api/deleteMaterialsCategory", {id: category.id})
			.catch(e => console.log(e.message))
		onDelete(index)
	}
	return (
		<>
			{
				isEditing ? (
					<MaterialsCategoryForm 
						onSubmit={handleSubmit} 
						onCancel={() => setIsEditing(false)}
						defaultValue={category} 
						makeApiRequest={(body) => makeApiRequest("/api/editMaterialsCategory", {...body, id: category.id})}
					/>
				) : category ? (
					<>
						<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
							<TableCell>
								<IconButton aria-label="expand row" size="small" onClick={() => setIsOpen(!isOpen)}>
									{isOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
								</IconButton>
							</TableCell>
							<TableCell>{category.name}</TableCell>
							<TableCell>
								<IconButton onClick={handleDelete}><DeleteIcon /></IconButton>
								<IconButton onClick={() => setIsEditing(true)}><EditIcon /></IconButton>
							</TableCell>
						</TableRow>
						<MaterialsTable category={category} isOpen={isOpen} />
					</>
				) : (
					<MaterialsCategoryForm 
						onSubmit={handleSubmit}
						onCancel={() => onDelete(index)}
						makeApiRequest={(body) => makeApiRequest("/api/createMaterialsCategory", body)}
					/>
				)
			}
		</>
	)
}
export default function MaterialsCategoriesTable() {
	const [categories, setCategories] = useState([])
	const [createdCategories, setCreatedCategories] = useState([])
	const [total, setTotal] = useState(0)
	const [page, setPage] = useState(0)
	const [size, setSize]= useState(10)
	const [isLoading, setIsLoading] = useState(true)
	async function handleDataFetch() {
		setIsLoading(true)
		const {total: newTotal, materialsCategories: newCategories} = await makeApiRequest(
			"/api/getMaterialsCategories", {page, size}
		).catch(e => toast.error(e.message))
		setTotal(newTotal)
		setCategories(newCategories)
		setIsLoading(false)
	}
	useEffect(() => {handleDataFetch()}, [page, size])
	return (
		<ThemeProvider theme={theme}>
			<Box sx={styles.mainBox}>
				<Box sx={styles.headerBox}>
					<Typography color="primary" variant="h2" sx={styles.title}>Materials</Typography>
					<Button
						sx={styles.addButton}
						color="primary"
						variant="contained"
						startIcon={<AddIcon />}
						onClick={() => setCreatedCategories(categories => [categories.length, ...categories])}
					>
						Add category
					</Button>
				</Box>
				<Box>
					<TableContainer>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell />
									<TableCell>category</TableCell>
									<TableCell>actions</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{createdCategories.map(index => (
									<Row 
										key={`created-${index}`}
										onDelete={index => setCreatedCategories(categories => categories.filter(categoryIndex => categoryIndex != index))}
										index={index}
									/>
								))}
								{
									isLoading ? (
										<TableRow>
											<TableCell colSpan={7} align="center">
												<CircularProgress />
											</TableCell>
										</TableRow>
									)
									: categories.map(category => (
										<Row
											defaultValue={category}
											onDelete={handleDataFetch}
											index={category.id}
											key={category.id}
										/>
									))
								}
							</TableBody>
						</Table>
					</TableContainer>
					<TablePagination count={total} rowsPerPage={size} page={page} onPageChange={(event, newPage) => setPage(newPage)}
						onRowsPerPageChange={(event) => {setSize(event.target.value); setPage(0)}} component="div" rowsPerPageOptions={[10, 20, 30, 40]}/>
				</Box>
			</Box>
		</ThemeProvider>
	)
}