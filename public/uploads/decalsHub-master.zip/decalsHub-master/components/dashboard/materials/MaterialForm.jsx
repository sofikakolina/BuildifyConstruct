import {useState} from 'react'
import {Grid, TextField, IconButton, Button, TableRow, TableCell} from "@mui/material"
import CloseIcon from '@mui/icons-material/Close'
import Joi from "joi-browser"
import toast from 'react-hot-toast'
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0),
	name: Joi.string().max(50).required(),
	cost: Joi.number().greater(0).required(),
	markup: Joi.number().greater(0).required(),
	categoryId: Joi.number().min(0)
})
export default function MaterialForm({onSubmit, onCancel, defaultValue, makeApiRequest}) {
	const [form, setForm] = useState(defaultValue ? defaultValue : {})
	const [errors, setErrors] = useState({})
	const handleFormChange = (event) => setForm(
		form => ({...form, [event.target.name]: event.target.value.trim()})
	)
	async function handleSubmit() {
		try {
			const {error, value} = validationSchema.validate({...form, cost: Math.round(form.cost * 100)}, {abortEarly: false})
			if(error) {setErrors(error.details.reduce((newErrors, detail) => ({...newErrors, [detail.path[0]]: detail.message}), {})); return}
			const response = await makeApiRequest(value)
			onSubmit(response ? response.material : value)
		}
		catch(e) {toast.error(e.message)}
	}
	return (
		<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
			<TableCell>
				<IconButton size="small" onClick={onCancel}>
					<CloseIcon />
				</IconButton>
			</TableCell>
			<TableCell>
				<Grid container>
					<TextField
						margin="normal"
						label="Name"
						variant="outlined"
						name="name"
						error={Boolean(errors.name)}
						helperText={errors.name}
						onChange={handleFormChange}
						defaultValue={defaultValue?.name}
					/>
				</Grid>
			</TableCell>
			<TableCell>
					<TextField
					margin="normal"
					label="Cost"
					variant="outlined"
					name="cost"
					type="number"
					error={Boolean(errors.cost)}
					helperText={errors.cost}
					onChange={handleFormChange}
					defaultValue={defaultValue?.cost}
				/>
			</TableCell>
			<TableCell>
				<TextField
					margin="normal"
					label="Markup"
					variant="outlined"
					type="number"
					name="markup"
					error={Boolean(errors.markup)}
					helperText={errors.markup}
					onChange={handleFormChange}
					defaultValue={defaultValue?.markup}
				/>
			</TableCell>
			<TableCell>{form.markup * form.cost}</TableCell>
			<TableCell>
				<Button
					type="button"
					onClick={handleSubmit}
					variant="contained"
					color="primary"
					sx={{color: "white"}}
				>
					Save
				</Button>
			</TableCell>
		</TableRow>
	)
}