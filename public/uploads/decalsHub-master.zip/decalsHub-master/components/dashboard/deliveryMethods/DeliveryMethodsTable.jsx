"use client"
import React, {useEffect, useState} from "react"
import theme from "@/theme"
import {Button, ThemeProvider, CircularProgress, Box, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Typography} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import makeApiRequest from "@/libs/makeApiRequest"
import DeliveryMethodForm from "./DeliveryMethodForm"
import toast from "react-hot-toast"
const styles = {
	mainBox: {display: "flex", flexDirection: "column", gap: "32px", py: "2rem"},
	headerBox: {display: "flex", justifyContent: "space-between"},
	title: {fontSize: "48px", fontWeight: "medium"},
	addButton: {color: "white", px: 3, py: 1, fontSize: '0.9rem'}
}
function Row({defaultValue, index, onDelete}) {
	const [isEditing, setIsEditing] = useState(false)
	const [delivery, setDelivery] = useState(defaultValue)
	const handleSubmit = response => {setDelivery({...delivery, ...response}); setIsEditing(false)}
	async function handleDelete() {
		await makeApiRequest("/api/deleteDeliveryMethod", {id: delivery.id}).catch(e => console.log(e.message))
		onDelete(index)
	}
	return (
		<>
			{
				isEditing ? (
					<DeliveryMethodForm
						onSubmit={handleSubmit} 
						onCancel={() => setIsEditing(false)}
						defaultValue={{...delivery, cost: delivery.cost / 100}}
						makeApiRequest={body => makeApiRequest("/api/editDeliveryMethod", {...body, id: delivery.id})}
					/>
				) : delivery ? (
					<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
						<TableCell />
						<TableCell>{delivery.name}</TableCell>
						<TableCell>{delivery.cost / 100}</TableCell>
						<TableCell>
							<IconButton onClick={handleDelete}><DeleteIcon /></IconButton>
							<IconButton onClick={() => setIsEditing(true)}><EditIcon /></IconButton>
						</TableCell>
					</TableRow>
				) : (
					<DeliveryMethodForm
						onSubmit={handleSubmit}
						onCancel={() => onDelete(index)}
						makeApiRequest={(body) => makeApiRequest("/api/createDeliveryMethod", body)}
					/>
				)
			}
		</>
	)
}
export default function DeliveryMethodsTable() {
	const [deliveries, setDeliveries] = useState([])
	const [createdDeliveries, setCreatedDeliveries] = useState([])
	const [total, setTotal] = useState(0)
	const [page, setPage] = useState(0)
	const [size, setSize]= useState(10)
	const [isLoading, setIsLoading] = useState(true)
	async function handleDataFetch() {
		setIsLoading(true)
		const {total: newTotal, deliveryMethods: newDeliveries} = await makeApiRequest("/api/getDeliveryMethods", {page, size})
			.catch(e => toast.error(e.message))
		setTotal(newTotal)
		setDeliveries(newDeliveries)
		setIsLoading(false)
	}
	useEffect(() => {handleDataFetch()}, [page, size])
	return (
		<ThemeProvider theme={theme}>
			<Box sx={styles.mainBox}>
				<Box sx={styles.headerBox}>
					<Typography color="primary" variant="h2" sx={styles.title}>Delivery methods</Typography>
					<Button
						sx={styles.addButton}
						color="primary"
						variant="contained"
						startIcon={<AddIcon />}
						onClick={() => setCreatedDeliveries(deliveries => [deliveries.length, ...deliveries])}
					>
						Add delivery
					</Button>
				</Box>
				<Box>
					<TableContainer>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell />
									<TableCell>Name</TableCell>
									<TableCell>Cost</TableCell>
									<TableCell>Actions</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{createdDeliveries.map(index => (
									<Row 
										key={`created-${index}`}
										onDelete={index => setCreatedDeliveries(deliveries => deliveries.filter(deliveryIndex => deliveryIndex != index))}
										index={index}
									/>
								))}
								{
									isLoading ? (
										<TableRow>
											<TableCell colSpan={7} align="center">
												<CircularProgress />
											</TableCell>
										</TableRow>
									)
									: deliveries.map(delivery => (
										<Row
											defaultValue={delivery}
											onDelete={handleDataFetch}
											index={delivery.id}
											key={delivery.id}
										/>
									))
								}
							</TableBody>
						</Table>
					</TableContainer>
					<TablePagination count={total} rowsPerPage={size} page={page} onPageChange={(event, newPage) => setPage(newPage)}
						onRowsPerPageChange={(event) => {setSize(event.target.value); setPage(0)}} component="div" rowsPerPageOptions={[10, 20, 30, 40]}/>
				</Box>
			</Box>
		</ThemeProvider>
	)
}