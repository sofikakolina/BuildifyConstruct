"use client"
import { ThemeProvider } from "@mui/material/styles"
import theme from "@/theme"
import React, { useState, useEffect } from "react"
import { useForm, Controller } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as Yup from "yup"
import { Autocomplete, Box, Button, TextField, Typography, Grid, Paper, FormControl, InputLabel, Select, MenuItem, FormHelperText, Switch, FormControlLabel, InputAdornment, IconButton } from "@mui/material"
import ImageDropzone from "./upload/UploadImage"
import AddressModal from "./address/AddressModal"
import AddressCard from "./address/Card"
import PhoneModal from "./phone/AddPhone"
import PhoneCard from "./phone/Card"
import makeApiRequest from "@/libs/makeApiRequest"
import { Role } from "@prisma/client"
import getFullAddress from "@/libs/getFullAddress"
import { useRouter } from "next/navigation"
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Link from "next/link"
import crypto from "crypto"
import toast from "react-hot-toast"
import Invoices from "@/components/dashboard/invoices/InvoicesbyUser"
import ProductsTable from "../products/ProductsTable"
import OrdersTable from "../orders/OrdersTable"
export default function UserForm({ user }) {
	const [addresses, setAddresses] = useState({ loaded: user ? [...user.addresses] : [], created: [], deleted: [] })
	const [selectedAddresses, setSelectedAddresses] = useState("")
	const [generatePassword, setGeneratePassword] = useState("")
	const [showPassword, setShowPassword] = useState(false);
	const [password, setPassword] = useState('');
	const [repeatPassword, setRepeatPassword] = useState('');
	const [selectedAddressIndex, setSelectedAddressIndex] = useState(null)
	const [phones, setPhones] = useState({ loaded: user ? [...user.phones] : [], created: [], deleted: [] })
	const [selectedPhones, setSelectedPhones] = useState(null)
	const [selectedPhoneIndex, setSelectedPhoneIndex] = useState(null)
	const [taxes, setTaxes] = useState([])
	const [isLoading, setLoading] = useState(false)
	const [historyCustomer, setHistoryCustomer] = useState('')
	const router = useRouter()
	const userSchema = Yup.object().shape({
		name: Yup.string().max(50).required(),
		email: Yup.string().email().required(),
		password: Yup.string().test("password-conditions", "Password must be at least 6 characters", value => {
			if (user) return !value || value.length >= 6
			return value && value.length >= 6
		}).max(100),
		repeatPassword: Yup.string().test("repeat-password", "Repeat password is required", value => {
			if (user) return !value || value.length >= 6
			return value && value.length >= 6
		}).oneOf([Yup.ref("password"), null], "Passwords need to match"),
		role: Yup.string().required(),
		company: Yup.string().max(50).notRequired(),
		emailVerified: Yup.string().nullable()
	})

	const { register, handleSubmit, control, formState: { errors }, reset, setValue } = useForm({
		resolver: yupResolver(userSchema), mode: "onChange", defaultValues: {
			name: user?.name, email: user?.email, password: "", repeatPassword: "",
			role: user ? user.role : Role.Customer, company: user ? user.company : "",
			emailVerified: user ? user.emailVerified : new Date().toISOString(),
			image: user?.image,
			tax: user?.tax
		}
	})

	const handleClickShowPassword = () => {
		setShowPassword(!showPassword);
	};

	const handlePasswordChange = (e) => {
		setPassword(e.target.value);
	};

	const handleRepeatPasswordChange = (e) => {
		setRepeatPassword(e.target.value);
	};

	const handleMouseDownPassword = (event) => {
		event.preventDefault();
	};

	const onSubmit = async data => {
		setLoading(true)
		const { repeatPassword, tax, ...value } = data
		if (!value.company) delete value.company
		try {
			if (user) {
				["password", "image"].forEach(key => { if (!value[key]) delete value[key] })
				await makeApiRequest("/api/editUser", { id: user.id, taxId: tax?.id, ...value })
				toast.success("User updated successfully!")
				setLoading(false)
			}
			else {
				({ user } = await makeApiRequest("/api/createUser", { ...value, taxId: tax?.id }))
				router.push("/dashboard/users")
			}
			await Promise.all([
				...addresses.loaded.map(address => {
					for (const [key, value] of Object.entries(user.addresses.find(item => item.id == address.id))) {
						if (address[key] != value) {
							["label", "type"].forEach(key => { if (!address[key]) delete address[key] })
							return makeApiRequest("/api/editAddress", {
								id: address.id, type: address.type, label: address.label, address: getFullAddress(address)
							})
						}
					}
				}),
				...addresses.created.map(address => {
					["label", "type"].forEach(key => { if (!address[key]) delete address[key] })
					return makeApiRequest("/api/createAddress", {
						userId: user.id, type: address.type, label: address.label, address: getFullAddress(address)
					})
				}),
				...addresses.deleted.map(id => makeApiRequest("/api/deleteAddress", { id })),
				...phones.loaded.map(phone => {
					for (const [key, value] of Object.entries(user.phones.find(item => item.id == phone.id)))
						if (phone[key] != value) {
							delete phone.userId
							return makeApiRequest("/api/editPhone", phone)
						}
				}),
				...phones.created.map(phone => makeApiRequest("/api/createPhone", { userId: user.id, ...phone })),
				...phones.deleted.map(id => makeApiRequest("/api/deletePhone", { id })),
			])
		}
		catch (error) { setLoading(false); toast.error(error.message) }
	}
	useEffect(() => {
		makeApiRequest("/api/getTaxes", {}).then(({ taxes }) => setTaxes(taxes)).catch(e => toast.error(e.message))
	}, [])
	return (
		<ThemeProvider theme={theme}>
			<Box>
				<form onSubmit={handleSubmit(onSubmit)}>
					<Box sx={{ display: "flex", justifyContent: "space-between", mb: 4 }}>
						<Typography variant="h4" sx={{ color: "primary" }}>
							{user ? "Edit user" : "Create user"}
						</Typography>
					</Box>
					<Grid container spacing={2}>
						<Grid item xs={12} md={4}>
							<Paper sx={{ borderRadius: "16px", padding: "80px 24px 40px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
								<Controller
									name="image"
									control={control}
									defaultValue={user?.image}
									render={({ field: { value, onChange } }) => (
										<ImageDropzone
											onDrop={path => onChange(path)}
											image={value}
										/>
									)}
								/>
								<Typography align="center" color="primary" variant="h6" sx={{ fontSize: "0.75rem", margin: "24px auto 0px", lineHeight: "1.5" }}>Allowed *.jpeg, *.jpg, *.png, *.gif<br />max size of 100 Mb</Typography>
								<Box sx={{ display: "flex", gap: "20px", justifyContent: "center", alignItems: "center", margin: "24px auto 0px" }}>
									<Box>
										<Typography variant="h6" sx={{ fontSize: "1.2rem" }}>Email Verified</Typography>
										<Typography variant="body2" sx={{ fontSize: "0.8rem" }}>Disabling this will automatically send the user a verification email</Typography>
									</Box>
									<FormControlLabel
										control={
											<Controller
												name="emailVerified"
												control={control}
												render={({ field: { value, onChange } }) => (
													<Switch
														checked={Boolean(value)}
														onChange={() => onChange(value ? null : new Date().toISOString())}
													/>
												)}
											/>
										}
									/>
								</Box>
							</Paper>
						</Grid>
						<Grid item xs={12} md={8}>
							<Paper sx={{ p: 2 }}>
								<Grid container spacing={2}>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											label="Name"
											{...register("name")}
											error={!!errors.name}
											helperText={errors.name?.message}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											label="Email"
											{...register("email")}
											error={!!errors.email}
											helperText={errors.email?.message}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<TextField
											fullWidth
											label="Company"
											{...register("company")}
											error={!!errors.company}
											helperText={errors.company?.message}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<Controller
											name="role"
											control={control}
											render={({ field, fieldState: { error } }) => (
												<FormControl fullWidth margin="dense" error={!!errors.role} sx={{ margin: 0 }}>
													<InputLabel id="role-label">Role</InputLabel>
													<Select
														{...field}
														labelId="role-label"
														label="Role"
														error={!!errors.role}
													>
														{
															Object.keys(Role).map(option => (
																<MenuItem key={option} value={option}>
																	{option}
																</MenuItem>
															))
														}
													</Select>
													{error && <FormHelperText>{errors.role?.message}</FormHelperText>}
												</FormControl>
											)}
										/>
									</Grid>
									<Grid item xs={12}>
										<Controller
											name="tax"
											fullWidth
											control={control}
											render={({ field: { onChange } }) => (
												<Autocomplete
													disablePortal
													fullWidth
													id="combo-box-demo"
													defaultValue={user?.tax}
													getOptionLabel={option => option.name}
													options={taxes}
													onChange={(event, tax) => onChange(tax)}
													sx={{ width: 300 }}
													renderOption={(props, option) => (
														<Box component="li" {...props} key={option.id}>
															{option.name} {option.rate}%
														</Box>
													)}
													renderInput={(params) => <TextField {...params} label="Tax" />}
												/>
											)}
										/>
									</Grid>
									<Grid item xs={12} sm={6}>
										<Button
											variant="contained"
											color="primary"
											onClick={() => {
												setAddresses(addresses => {
													const newAddresses = { ...addresses }
													newAddresses.created.push({})
													return newAddresses
												})
												setSelectedAddresses("created")
												setSelectedAddressIndex(addresses.created.length - 1)
											}}
											sx={{ mt: 2, px: 2, py: 1, color: "white" }}
										>
											Add Address
										</Button>
										{
											addresses.loaded.map((address, index) => (
												<AddressCard
													key={`loaded-address-${index}`}
													address={address}
													onEdit={() => {
														setSelectedAddresses("loaded")
														setSelectedAddressIndex(index)
													}}
													onDelete={() => setAddresses(addresses => {
														const newAddresses = { ...addresses }
														newAddresses.deleted.push(address.id)
														newAddresses.loaded.splice(index, 1)
														return newAddresses
													})}
												/>
											))
										}
										{
											addresses.created.map((address, index) => Object.keys(address).length
												? (
													<AddressCard
														key={`created-address-${index}`}
														address={address}
														onEdit={() => {
															setSelectedAddresses("created")
															setSelectedAddressIndex(index)
														}}
														onDelete={() => setAddresses(addresses => {
															const newAddresses = { ...addresses }
															newAddresses.created.splice(index, 1)
															return newAddresses
														})}
													/>
												) : ""
											)
										}
									</Grid>
									<Grid item xs={12} sm={6}>
										<Button
											variant="contained"
											color="primary"
											onClick={() => {
												setPhones(phones => {
													const newPhones = { ...phones }
													newPhones.created.push({})
													return newPhones
												})
												setSelectedPhones("created")
												setSelectedPhoneIndex(phones.created.length - 1)
											}}
											sx={{ mt: 2, px: 2, py: 1, color: "white" }}
										>
											Add Phone
										</Button>
										{
											phones.loaded.map((phone, index) => (
												<PhoneCard
													key={`loaded-phone-${index}`}
													phone={phone}
													onEdit={() => {
														setSelectedPhones("loaded")
														setSelectedPhoneIndex(index)
													}}
													onDelete={() => setPhones(phones => {
														const newPhones = { ...phones }
														newPhones.deleted.push(phone.id)
														newPhones.loaded.splice(index, 1)
														return newPhones
													})}
												/>
											))
										}
										{
											phones.created.map((phone, index) => Object.keys(phone).length
												? (
													<PhoneCard
														key={`created-phone-${index}`}
														phone={phone}
														onEdit={() => {
															setSelectedPhones("created")
															setSelectedPhoneIndex(index)
														}}
														onDelete={() => setPhones(phones => {
															const newPhones = { ...phones }
															newPhones.created.splice(index, 1)
															return newPhones
														})}
													/>
												) : ""
											)
										}
									</Grid>

									<Grid item xs={12} sm={12} sx={{ display: "flex", alignItems: "center", gap: "5px" }}>
										<TextField
											sx={{ width: '100%' }}
											label="Password"
											type={showPassword ? 'text' : 'password'}
											variant="outlined"
											{...register("password")}
											onChange={handlePasswordChange}
											error={!!errors.password}
											InputLabelProps={{ shrink: !!generatePassword || !!password }} // Устанавливаем shrink в true, если есть сгенерированный пароль или введен текст
											helperText={errors.password?.message}
											InputProps={{
												endAdornment: (
													<InputAdornment position="end">
														<IconButton
															aria-label="toggle password visibility"
															onClick={handleClickShowPassword}
															onMouseDown={handleMouseDownPassword}
															edge="end"
														>
															{showPassword ? <VisibilityOff /> : <Visibility />}
														</IconButton>
													</InputAdornment>
												),
											}}
										/>

										<Button
											sx={{
												padding: "10px 30px 10px 30px",
												'&:hover': { // Стили для hover-эффекта
													backgroundColor: "#d7d7d766", // Серый цвет для hover
													padding: "10px 30px 10px 30px"
												}
											}}
											onClick={() => {
												const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_#$&*!?';
												const length = 15;
												let password = '';
												for (let i = 0; i < length; i++) {
													const randomIndex = Math.floor(crypto.randomBytes(1)[0] / 255 * characters.length);
													password += characters.charAt(randomIndex);
												}
												const newPassword = password;
												setGeneratePassword(newPassword);
												setValue("password", newPassword);
												setValue("repeatPassword", newPassword);
											}}
										>
											<Link
												component="button"
												variant="contained"
												href="#"
												color="primary"

												sx={{
													px: 2,
													py: 1,
													color: "white",
													textDecoration: "none",
													backgroundColor: "primary.main", // Цвет кнопки
													'&:hover': { // Стили для hover-эффекта
														backgroundColor: "#505050 !important", // Серый цвет для hover
														color: "#fff !important" // Белый цвет для hover
													}
												}}
											>
												Generate
											</Link>
										</Button>

										<TextField
											sx={{ width: '100%' }}
											label="Repeat password"
											type={showPassword ? 'text' : 'password'}
											variant="outlined"
											{...register("repeatPassword")}
											onChange={handleRepeatPasswordChange}
											error={!!errors.repeatPassword}
											// value={generatePassword} // Установка сгенерированного пароля в значение текстового поля
											InputLabelProps={{ shrink: !!generatePassword || !!repeatPassword }} // Устанавливаем shrink в true, если есть сгенерированный пароль или введен текст
											helperText={errors.repeatPassword?.message}
											InputProps={{
												endAdornment: (
													<InputAdornment position="end">
														<IconButton
															aria-label="toggle password visibility"
															onClick={handleClickShowPassword}
															onMouseDown={handleMouseDownPassword}
															edge="end"
														>
															{showPassword ? <VisibilityOff /> : <Visibility />}
														</IconButton>
													</InputAdornment>
												),
											}}
										/>
									</Grid>

									<Grid item xs={12} md={8} sx={{ display: "flex", justifyContent: "flex-end" }}>
										<Button type="submit" variant="contained" color="primary" disabled={isLoading} sx={{ color: "white", px: 3, py: 2 }}>
											{
												isLoading
													? user ? "Updating..." : "Creating..."
													: user ? "Update user" : "Create user"
											}
										</Button>
									</Grid>
								</Grid>
							</Paper>
						</Grid>
					</Grid>
				</form>
				<AddressModal
					addresses={addresses}
					selectedAddresses={selectedAddresses}
					selectedAddressIndex={selectedAddressIndex}
					onClose={() => setSelectedAddressIndex(null)}
					setAddresses={setAddresses}
				/>
				<PhoneModal
					phones={phones}
					selectedPhones={selectedPhones}
					selectedPhoneIndex={selectedPhoneIndex}
					onClose={() => setSelectedPhoneIndex(null)}
					setPhones={setPhones}
				/>
				<div className="flex flex-col justify-center pt-8">
					<div className="flex justify-center gap-10">
						<Button
							onClick={() => { setHistoryCustomer("products") }}
							style={{
								backgroundColor: historyCustomer === "products" ? '#F69220' : '',
								color: historyCustomer == "products" ? '#fff' : "",
								borderRadius: '10px',
								fontSize: "16px",
								fontWeight: "600",
							}}>
							Products
						</Button>
						<Button
							onClick={() => setHistoryCustomer("orders")}
							style={{
								backgroundColor: historyCustomer === "orders" ? '#F69220' : '',
								color: historyCustomer == "orders" ? '#fff' : "",
								borderRadius: '10px',
								fontSize: "16px",
								fontWeight: "600",
							}}>
							Orders
						</Button>
						<Button
							onClick={() => setHistoryCustomer("invoices")}
							style={{
								backgroundColor: historyCustomer === "invoices" ? '#F69220' : '',
								color: historyCustomer == "invoices" ? '#fff' : "",
								borderRadius: '10px',
								fontSize: "16px",
								fontWeight: "600",
							}}>
							Invoices
						</Button>
					</div>

					{historyCustomer == "products" ? <ProductsTable userId={user.id} /> : historyCustomer == "orders" ? <OrdersTable userId={user.id} /> : historyCustomer == "invoices" ? <Invoices userId={user.id} /> : null}
				</div>
			</Box>
		</ThemeProvider>
	)
}