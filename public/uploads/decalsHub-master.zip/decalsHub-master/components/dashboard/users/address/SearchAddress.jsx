import React, { useState, useEffect } from 'react';
import { Autocomplete, TextField } from '@mui/material';

const SearchAddress = ({ setValue }) => {
  const [inputValue, setInputValue] = useState('');
  const [options, setOptions] = useState([]);
  const [autocompleteService, setAutocompleteService] = useState(null);

  useEffect(() => {
    const handleScriptLoad = () => {
      if (window.google && window.google.maps.places) {
        setAutocompleteService(new window.google.maps.places.AutocompleteService());
      }
    };

    if (window.google && window.google.maps.places) {
      handleScriptLoad();
    } else {
      const script = document.createElement("script");
      script.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&language=en&region=en&libraries=places`;
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);
      script.onload = () => handleScriptLoad();
    }
  }, []);




  const handleInputChange = (_, newInputValue) => {
    setInputValue(newInputValue);
    if (!autocompleteService || newInputValue.length < 3) {
      setOptions([]);
      return;
    }

    autocompleteService.getPlacePredictions({
      input: newInputValue,
      componentRestrictions: { country: ["us", "ca"] }
    }, (predictions, status) => {
      if (status === window.google.maps.places.PlacesServiceStatus.OK && predictions) {
        setOptions(predictions.map(prediction => prediction.description));
      } else {
        setOptions([]);
      }
    });
  };

  const handlePlaceSelect = async (address) => {
    const geocoder = new window.google.maps.Geocoder();
    geocoder.geocode({ address }, (results, status) => {
      if (status === 'OK' && results[0]) {
        const place = results[0];
        const addressComponents = place.address_components;

        // Инициализируем поля адреса
        const addressFields = {
          street: '',
          building: '',
          city: '',
          state: '',
          zip: '',
          country: '',
          suburb: '',
        };

        // Обрабатываем компоненты адреса
        addressComponents.forEach(component => {
          const { types, long_name } = component;

          // Проверяем и заполняем соответствующие поля
          if (types.includes('street_number')) {
            addressFields.building = long_name; // Номер дома
          }
          if (types.includes('route')) {
            addressFields.street = long_name; // Название улицы
          }
          if (types.includes('locality')) {
            addressFields.city = long_name;
          } else if (types.includes('administrative_area_level_1')) {
            addressFields.state = long_name;
          } else if (types.includes('postal_code')) {
            addressFields.zip = long_name;
          } else if (types.includes('country')) {
            addressFields.country = long_name;
          } else if (types.includes('sublocality') || types.includes('sublocality_level_1')) {
            addressFields.suburb = long_name;
          }
        });

        // Обновляем состояние формы для каждого поля
        Object.keys(addressFields).forEach(field => {
          setValue(field, addressFields[field], false);
        });
      }
    });
  };

  return (
    <>
      <Autocomplete
        freeSolo
        disableClearable
        options={options}
        onInputChange={handleInputChange}
        onChange={(event, newValue) => {
          if (newValue) {
            handlePlaceSelect(newValue);
          }
        }}
        renderInput={(params) => (
          <TextField {...params} label="Search Address" variant="outlined" />
        )}
      />
    </>
  );
};

export default SearchAddress;
