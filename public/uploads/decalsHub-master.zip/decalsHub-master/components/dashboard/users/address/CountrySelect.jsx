import * as React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import InputAdornment from "@mui/material/InputAdornment";
import { countries } from "countries-list"; 

const CountrySelect = ({ setFieldValue }) => {
  const [value, setValue] = React.useState(null);

  const handleClear = (e) => {
    setValue(null);
    setFieldValue("country", "");
  };

  const countriesOptions = Object.keys(countries).map((code) => ({
    label: countries[code].name,
    id: code,
  }));

  return (
    <Autocomplete
      id="country-select"
      disableClearable
      value={value}
      onChange={(event, newValue) => {
        setValue(newValue);
        setFieldValue("country", newValue ? newValue.label : ""); 
      }}
      openOnFocus
      sx={{ width: 300 }}
      options={countriesOptions}
      autoHighlight
      onOpen={handleClear}
      getOptionLabel={(option) => option.label}
      renderOption={(props, option) => (
        <Box
          component="li"
          sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
          {...props}
        >
          <img
            loading="lazy"
            width="20"
            src={`https://flagcdn.com/w20/${option.id.toLowerCase()}.png`}
            srcSet={`https://flagcdn.com/w40/${option.id.toLowerCase()}.png 2x`}
            alt={option.label}
          />
          {option.label}
        </Box>
      )}
      renderInput={(params) => (
        <TextField
          {...params}
          label="Country"
          placeholder="Country"
          inputProps={{
            ...params.inputProps,
            autoComplete: "new-password"
          }}
          InputProps={{
            ...params.InputProps,
            startAdornment: value ? (
              <InputAdornment disablePointerEvents position="start">
                <img
                  loading="lazy"
                  width="20"
                  src={`https://flagcdn.com/w20/${value.id.toLowerCase()}.png`}
                  srcSet={`https://flagcdn.com/w40/${value.id.toLowerCase()}.png 2x`}
                  alt={value.label}
                />
              </InputAdornment>
            ) : null
          }}
        />
      )}
    />
  );
};

export default CountrySelect;
