import React, { useEffect } from "react"
import { Modal, Box, Button, Typography, FormControl, InputLabel, Select, MenuItem, TextField, Grid, FormHelperText } from "@mui/material"
import { useForm, Controller } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import * as Yup from "yup"
import CloseIcon from "@mui/icons-material/Close"
import SearchAddress from "./SearchAddress"
import { AddressType } from "@prisma/client"
const validationSchema = Yup.object().shape({
	type: Yup.string().required("Address type is required"),
	label: Yup.string(),
	street: Yup.string().required("Street is required"),
	suburb: Yup.string(),
	city: Yup.string().required("City is required"),
	state: Yup.string().required("State is required"),
	zip: Yup.string().required("ZIP/Postal code is required"),
	country: Yup.string().required("Country is required"),
	building: Yup.string().required("Building is required"),
	apartment: Yup.string(),
})
const modalStyle = {
	position: "absolute",
	top: "50%",
	left: "50%",
	transform: "translate(-50%, -50%)",
	bgcolor: "background.paper",
	boxShadow: 24,
	p: 4,
	display: "flex",
	flexDirection: "column",
	gap: 2,
	borderRadius: 2,
}
const fieldProps = [
	{ name: "label", md: 6, label: "Label" },
	{ name: "street", md: 6, label: "Street" },
	{ name: "building", md: 3, label: "Building" },
	{ name: "suburb", md: 3, label: "Suburb" },
	{ name: "city", md: 4, label: "City" },
	{ name: "state", md: 4, label: "State" },
	{ name: "zip", md: 4, label: "ZIP/Postal code" },
	{ name: "country", md: 6, label: "Country" },
	{ name: "apartment", md: 6, label: "Apartment" },
]
export default function AddressModal({ onClose, selectedAddressIndex, addresses, selectedAddresses, setAddresses }) {
	const { control, handleSubmit, formState, setValue, reset } = useForm({
		resolver: yupResolver(validationSchema), mode: "onChange"
	})
	useEffect(() => {
		const address = addresses[selectedAddresses]?.[selectedAddressIndex]
		reset(address && Object.keys(address).length ? {
			...address, label: address.label ? address.label : "",
			suburb: address.suburb ? address.suburb : "",
			state: address.state ? address.state : "", apartment: address.apartment ? address.apartment : "",
		} : {
			type: AddressType.Primary, label: "", street: "", suburb: "", city: "", state: "",
			zip: "", country: "", building: "", apartment: ""
		})
	}, [selectedAddressIndex, selectedAddresses])
	function onSubmit(data) {
		setAddresses(addresses => {
			const newAddresses = { ...addresses }
			newAddresses[selectedAddresses][selectedAddressIndex] = data
			return newAddresses
		})
		onClose()
		reset()
	}
	function handleClose() {
		onClose()
		if (selectedAddresses != "created" || !Object.keys(addresses[selectedAddresses][selectedAddressIndex]).length)
			setAddresses(addresses => {
				const newAddresses = { ...addresses }
				newAddresses.created.splice(selectedAddressIndex, 1)
				return newAddresses
			})
	}
	return (
		<Modal
			open={typeof selectedAddressIndex == "number"}
			onClose={handleClose}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
		>
			<Box sx={modalStyle}>
				<Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
					<Typography id="modal-modal-title" variant="h4" component="h2" color="primary">
						{
							addresses[selectedAddresses]?.[selectedAddressIndex]
								&& Object.keys(addresses[selectedAddresses]?.[selectedAddressIndex]).length
								? "Edit Address"
								: "Add Address"
						}
					</Typography>
					<CloseIcon onClick={handleClose} style={{ cursor: "pointer" }} />
				</Box>
				<form onSubmit={handleSubmit(onSubmit)}>
					<Grid container spacing={2}>
						<Grid item xs={12}>
							<SearchAddress setValue={setValue} />
						</Grid>
						<Grid item xs={12} md={6}>
							<Controller
								name="type"
								control={control}
								render={({ field, fieldState: { error } }) => (
									<FormControl fullWidth margin="dense" error={!!error}>
										<InputLabel id="address-type-label">Address Type</InputLabel>
										<Select
											{...field}
											labelId="address-type-label"
											label="Address Type"
											error={!!error}
										>
											{Object.keys(AddressType).map((option) => (
												<MenuItem key={option} value={option}>
													{option}
												</MenuItem>
											))}
										</Select>
										{error && <FormHelperText>{error.message}</FormHelperText>}
									</FormControl>
								)}
							/>
						</Grid>
						{fieldProps.map(({ name, md, label }) => (
							<Grid item xs={12} md={md} key={name}>
								<Controller
									name={name}
									control={control}
									render={({ field }) => (
										<TextField
											{...field}
											fullWidth
											margin="dense"
											label={label}
											error={!!formState.errors[name]}
											helperText={formState.errors[name]?.message}
										/>
									)}
								/>
							</Grid>
						))}
					</Grid>
					<Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
						<Button
							type="submit"
							variant="contained"
							size="medium"
							sx={{ color: "white", px: 4, py: 2, fontSize: "16px" }}
						>
							Save Address
						</Button>
					</Box>
				</form>
			</Box>
		</Modal>
	)
}