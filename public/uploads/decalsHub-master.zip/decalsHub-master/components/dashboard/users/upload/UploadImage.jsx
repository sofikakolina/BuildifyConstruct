import React, { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Box, Avatar, Typography, CircularProgress } from "@mui/material"
import { CameraAlt as CameraIcon } from "@mui/icons-material"
import makeApiRequest from "@/libs/makeApiRequest"
export default function ImageDropzone({ onDrop, image }) {
	const [isLoading, setIsLoading] = useState(false)
	const [isHovering, setIsHovering] = useState(false)
	const [thumbnail, setThumbnail] = useState(image)
	const onDropCallback = useCallback(async acceptedFiles => {
		setIsLoading(true)
		const file = acceptedFiles[0]
		if (!file) return
		setThumbnail(URL.createObjectURL(file))
		const data = new FormData()
		data.append("file", file)
		const { path } = await makeApiRequest("/api/uploadFile", data)
		setIsLoading(false)
		onDrop(path)
	}, [onDrop])
	const { getRootProps, getInputProps } = useDropzone({
		onDrop: onDropCallback,
		accept: {
			"image/*": [
				".jpeg",
				".jpg",
				".png",
				".gif",
				".webp",
				".bmp",
				".tiff",
				".heic",
				".heif",
				".avif",
				".svg",
				".eps",
				".ai",
				".raw",
				".ico",
				".webm"
			]
		},
		maxFiles: 1
	})
	return (
		<Box {...getRootProps({ className: "dropzone" })}
			sx={{
				position: "relative",
				borderRadius: "50%",
				border: "2px dashed #F69220",
				width: 120,
				height: 120,
				display: "flex",
				alignItems: "center",
				justifyContent: "center",
				cursor: "pointer",
				overflow: "hidden",
				flexDirection: "column",
				backgroundColor: "#f0f0f0",
				"&:hover .hoverOverlay": {
					display: "flex",
				},
			}}
			onMouseEnter={() => setIsHovering(true)}
			onMouseLeave={() => setIsHovering(false)}
		>
			<input {...getInputProps()} />
			{
				isLoading ? <CircularProgress />
					: thumbnail ? (
						<>
							<Avatar src={thumbnail} alt="Uploaded" sx={{ width: 100, height: 100 }} />
							<Box className="hoverOverlay" sx={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", flexDirection: "column", justifyContent: "center", alignItems: "center", backgroundColor: "rgba(255, 255, 255, 0.8)", borderRadius: "50%", display: isHovering ? "flex" : "none" }}>
								<CameraIcon color="primary" />
								<Typography color="primary" variant="caption">Update Photo</Typography>
							</Box>
						</>
					) : (
						<Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", flexDirection: "column" }}>
							<CameraIcon color="primary" fontSize="large" />
							<Typography color="primary" variant="caption" sx={{ marginTop: "8px", fontSize: "12px" }}>Upload Image</Typography>
						</Box>
					)
			}
		</Box>
	)
}