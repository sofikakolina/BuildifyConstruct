import React, { useEffect } from "react"
import { Modal, Box, Button, Typography, MenuItem, TextField, Grid, FormControl, Select, InputLabel } from "@mui/material"
import { useForm, Controller } from 'react-hook-form'
import { yupResolver } from "@hookform/resolvers/yup"
import * as Yup from "yup"
import CloseIcon from "@mui/icons-material/Close"
import { PhoneType } from "@prisma/client"
const validationSchema = Yup.object().shape({
	type: Yup.string().required("Phone type is required"),
	number: Yup.string()
		.required("Phone number is required")
		.matches(/^\+?[1-9]\d{1,14}(\s*\(\d+\))?[-.\s]?\d+([-.\s]?\d+)*$/, "Phone number must be valid")
})
const modalStyle = {
	position: "absolute",
	top: "50%",
	left: "50%",
	transform: "translate(-50%, -50%)",
	bgcolor: "background.paper",
	boxShadow: 24,
	p: 4,
	display: "flex",
	flexDirection: "column",
	gap: 2,
	borderRadius: 2
}
export default function PhoneModal({ phones, setPhones, selectedPhones, selectedPhoneIndex, onClose }) {
	const { handleSubmit, control, formState: { errors }, reset, register } = useForm({
		resolver: yupResolver(validationSchema), mode: "onChange"
	})
	useEffect(() => {
		const phone = phones[selectedPhones]?.[selectedPhoneIndex]
		reset(phone && Object.keys(phone).length ? phone : { type: PhoneType.Mobile, number: "" })
	}, [selectedPhoneIndex, selectedPhones])
	function onSubmit(data) {
		setPhones((phones) => {
			const newPhones = { ...phones }
			newPhones[selectedPhones][selectedPhoneIndex] = data
			return newPhones
		})
		onClose()
		reset()
	}
	function handleClose() {
		onClose()
		if (selectedPhones != "created" || !Object.keys(phones[selectedPhones][selectedPhoneIndex]).length) setPhones((phones) => {
			const newPhones = { ...phones }
			newPhones.created.splice(selectedPhoneIndex, 1)
			return newPhones
		})
	}
	return (
		<Modal
			open={typeof selectedPhoneIndex == "number"}
			onClose={handleClose}
			aria-labelledby="modal-modal-title"
			aria-describedby="modal-modal-description"
		>
			<Box sx={modalStyle}>
				<Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
					<Typography id="modal-modal-title" variant="h4" component="h2" color="primary">
						{phones[selectedPhones]?.[selectedPhoneIndex] && Object.keys(phones[selectedPhones]?.[selectedPhoneIndex]).length
							? "Edit Phone"
							: "Add Phone"}
					</Typography>
					<CloseIcon onClick={handleClose} cursor="pointer" />
				</Box>
				<form onSubmit={handleSubmit(onSubmit)}>
					<Grid container spacing={3}>
						<Grid item xs={12} md={4}>
							<Controller
								name="type"
								control={control}
								render={({ field, fieldState: { error } }) => (
									<FormControl fullWidth margin="dense" error={!!error}>
										<InputLabel id="phone-type-label">Phone Type</InputLabel>
										<Select
											{...field}
											labelId="phone-type-label"
											label="Phone Type"
											error={!!error}
										>
											{Object.keys(PhoneType).map((option) => (
												<MenuItem key={option} value={option}>
													{option}
												</MenuItem>
											))}
										</Select>
										{error && <FormHelperText>{error.message}</FormHelperText>}
									</FormControl>
								)}
							/>
						</Grid>
						<Grid item xs={12} md={8}>
							<TextField
								fullWidth
								margin="dense"
								label="Phone Number"
								{...register("number")}
								error={!!errors.number}
								helperText={errors.number && errors.number.message}
							/>
						</Grid>
						<Grid item xs={12}>
							<Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2 }}>
								<Button type="submit" variant="contained" size="medium" sx={{ color: "white", px: 4, py: 2, fontSize: "16px" }}>
									Save Phone
								</Button>
							</Box>
						</Grid>
					</Grid>
				</form>
			</Box>
		</Modal>
	)
}