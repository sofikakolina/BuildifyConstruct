import {Typography, Box, Card, CardContent, CardActions, IconButton} from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
export default function PhoneCard({phone, onDelete, onEdit}) {
	return (
		<Box mt={2} width="100%">
			<Card variant="outlined" sx={{backgroundColor: "#fafafa", border: "1px solid #e0e0e0", boxShadow: "none"}}>
				<CardContent>
					<Typography variant="subtitle1" sx={{fontWeight: "bold"}}>{phone.phoneType}</Typography>
					<Typography variant="body2" color="textSecondary" sx={{marginTop: "8px"}}>
						{`${phone.number}`}
					</Typography>
				</CardContent>
				<CardActions disableSpacing sx={{justifyContent: "flex-end", paddingRight: "16px"}}>
					<IconButton aria-label="edit" onClick={onEdit} size="large">
						<EditIcon fontSize="small" sx={{color: "#1976d2"}} />
					</IconButton>
					<IconButton aria-label="delete" onClick={onDelete} size="large">
						<DeleteIcon fontSize="small" sx={{color: "#d32f2f"}} />
					</IconButton>
				</CardActions>
			</Card>
		</Box>
	)
}