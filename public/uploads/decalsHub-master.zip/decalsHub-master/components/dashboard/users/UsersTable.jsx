"use client"
import React, { useState, useEffect } from "react"
import theme from "@/theme"
import { ThemeProvider } from '@mui/material/styles'
import { Avatar, TextField, Select, MenuItem, CircularProgress, Table, TableRow, Button, Box, Typography, TableHead, TableBody, TableCell, TablePagination, IconButton, FormControl, InputLabel } from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import AddIcon from "@mui/icons-material/Add"
import { AddressType, PhoneType } from "@prisma/client"
import getFullAddress from "@/libs/getFullAddress"
import Link from "next/link"
import toast from "react-hot-toast"
import makeApiRequest from "@/libs/makeApiRequest"
const styles = {
	mainBox: { display: "flex", flexDirection: "column", gap: "32px", py: "2rem" },
	headerBox: { display: "flex", justifyContent: "space-between" },
	title: { fontSize: "48px", fontWeight: "medium" },
	addButton: { color: "white", px: 3, py: 1, fontSize: '0.9rem' }
}
export default function UsersTable() {
	const [users, setUsers] = useState([])
	const [search, setSearch] = useState("")
	const [total, setTotal] = useState(0)
	const [page, setPage] = useState(0)
	const [size, setSize] = useState(10)
	const [isLoading, setIsLoading] = useState(true)
	const [sort, setSort] = useState({company: "asc"})
	const [role, setRole] = useState("customers")
	async function handleFetch() {
		if(role == "customers") {
			var {users: newUsers, total: newTotal} = await makeApiRequest(
				"/api/getCustomers", {page, size, ...(() => search.length ? { search } : {})(), sort}
			)
		}
		else {
			var {staff, total: newTotal} = await makeApiRequest("/api/getStaff")
			var newUsers = [...staff.designers, ...staff.executors, ...staff.managers, ...staff.sellers]
		}
		setUsers(newUsers)
		setTotal(newTotal)
		setIsLoading(false)
	}
	useEffect(() => { handleFetch() }, [page, size, search, sort, role])
	async function handleUserDeletion(id) {
		try {
			await fetch("/api/deleteUser", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				credentials: "include",
				body: JSON.stringify({ id })
			})
			handleFetch()
		} catch (error) { toast.error(error.message) }
	}
	return (
		<ThemeProvider theme={theme}>
			<Box sx={styles.mainBox}>
				<Box sx={styles.headerBox}>
					<Typography color="primary" variant="h2" sx={styles.title}>Users</Typography>
					<Link href="/dashboard/users/create">
						<Button
							sx={styles.addButton}
							color="primary"
							variant="contained"
							startIcon={<AddIcon />}
						>
							Add User
						</Button>
					</Link>
				</Box>
				<Box sx={{ display: "flex", gap: '10px', alignItems: 'center' }}>
					<FormControl sx={{maxWidth: '300px', width: '100%'}}>
						<InputLabel id="label-filter">Sort</InputLabel>
						<Select
							labelId="select-filter-label"
							id="select-filter-label"
							value={JSON.stringify(sort)}
							label="Sort"
							sx={{width: '100%'}}
							onChange={event => setSort(JSON.parse(event.target.value))}
						>
							<MenuItem value={JSON.stringify({createdAt: "desc"})}>Date</MenuItem>
							<MenuItem value={JSON.stringify({company: "asc"})}>A-Z</MenuItem>
							<MenuItem value={JSON.stringify({company: "desc"})}>Z-A</MenuItem>
						</Select>
					</FormControl>
					<FormControl sx={{maxWidth: '300px', width: '100%'}}>
						<InputLabel id="label-filter">Sort</InputLabel>
						<Select
							labelId="select-role-label"
							id="select-role"
							value={role}
							label="Role"
							sx={{width: '100%'}}
							onChange={event => setRole(event.target.value)}
						>
							<MenuItem value="customers">Customers</MenuItem>
							<MenuItem value="staff">Staff</MenuItem>
						</Select>
					</FormControl>

					<TextField
						sx={{ width: '100%' }}
						label="Search"
						onChange={event => setSearch(() => {
							setPage(0)
							return event.target.value
						})}
					/>
				</Box>
				<Box sx={styles.box}>
					{isLoading ? (
						<Box sx={{ height: "50vh", display: "flex", justifyContent: "center", alignItems: "center" }}>
							<CircularProgress />
						</Box>
					) :
						<Table stickyHeader aria-label="sticky table">
							<TableHead>
								<TableRow>
									<TableCell>Name</TableCell>
									<TableCell>Company</TableCell>
									<TableCell>Address</TableCell>
									<TableCell>Phone</TableCell>
									<TableCell>Role</TableCell>
									<TableCell>Actions</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{users.map(user => (
									<TableRow key={user.id}>
										<TableCell>
											<Link href={`/dashboard/users/${user.id}`}>
												<Box sx={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
													<Avatar src={user.image} alt={user.name} />
													<Box>
														<Typography variant="body1">{user.name}</Typography>
														<Typography variant="body2" color="text.secondary">{user.email}</Typography>
													</Box>
												</Box>
											</Link>
										</TableCell>
										<TableCell>{user.company}</TableCell>
										<TableCell size="medium" style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'wrap' }}>
											{getFullAddress(user.addresses.find(address => address.type == AddressType.Primary))}
										</TableCell>
										<TableCell>{user.phones.find(phone => phone.type == PhoneType.Mobile)?.number}</TableCell>
										<TableCell>{user.role}</TableCell>
										<TableCell>
											<Link href={`/dashboard/users/${user.id}`}><IconButton aria-label="edit"><EditIcon /></IconButton></Link>
											<IconButton onClick={() => handleUserDeletion(user.id)} aria-label="delete"><DeleteIcon /></IconButton>
										</TableCell>
									</TableRow>
								))}
							</TableBody>
						</Table>}
				</Box>
				<TablePagination
					component="div"
					count={total}
					page={page}
					onPageChange={(_event, newPage) => setPage(newPage)}
					rowsPerPage={size}
					onRowsPerPageChange={(event) => {
						setSize(parseInt(event.target.value, 10))
						setPage(0)
					}}
					rowsPerPageOptions={[10, 20, 30, 40]}
				/>
			</Box>
		</ThemeProvider>
	)
}
