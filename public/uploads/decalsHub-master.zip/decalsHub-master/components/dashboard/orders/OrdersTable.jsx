"use client";
import {
	ThemeProvider,
	CircularProgress,
	TextField,
	Box,
	Collapse,
	IconButton,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TablePagination,
	TableRow,
	Typography,
} from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import React, { useEffect, useState } from "react";
import {
	getOrderTotal,
	getOrderItemPrice,
	getOrderSubtotal,
	getOrderTax,
} from "@/libs/calculations";
import formatDateToChicago from "@/libs/formatDate";
import theme from "@/theme";
import toast from "react-hot-toast";

function Row({ order }) {
	const [isOpen, setIsOpen] = useState(false);
	return (
		<React.Fragment>
			<TableRow sx={{ "& > *": { borderBottom: "unset" } }}>
				<TableCell>
					<IconButton
						aria-label="expand row"
						size="small"
						onClick={() => setIsOpen(!isOpen)}
					>
						{isOpen ? (
							<KeyboardArrowUpIcon />
						) : (
							<KeyboardArrowDownIcon />
						)}
					</IconButton>
				</TableCell>
				<TableCell>{order.id}</TableCell>
				<TableCell>{order.user.name}</TableCell>
				<TableCell>{order.status}</TableCell>
				<TableCell>{order.addressId ? "delivery" : "pickup"}</TableCell>
				<TableCell>{formatDateToChicago(order.createdAt)}</TableCell>
				<TableCell>{formatDateToChicago(order.updatedAt)}</TableCell>
				<TableCell>
					${(getOrderTax(order) / 100).toFixed(2)} ({" "}
					{order.user.tax?.rate} % )
				</TableCell>
				<TableCell>${order.payment.amount / 100}</TableCell>
			</TableRow>
			<TableRow>
				<TableCell
					style={{ paddingBottom: 0, paddingTop: 0 }}
					colSpan={6}
				>
					<Collapse in={isOpen} timeout="auto" unmountOnExit>
						<Box sx={{ margin: 1 }}>
							<Typography
								variant="h6"
								gutterBottom
								component="div"
							>
								Items
							</Typography>
							<Table size="small" aria-label="items">
								<TableHead>
									<TableRow>
										<TableCell>Image</TableCell>
										<TableCell>Name</TableCell>
										<TableCell>Dimensions</TableCell>
										<TableCell>Total</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{order?.orderItems?.length > 0 &&
										order.orderItems.map((item) => (
											<TableRow
												key={
													order.id +
													(item.product?.id || "")
												}
											>
												<TableCell>
													{item.product?.image ? (
														<img
															width={150}
															height={150}
															src={
																item.product
																	.image
															}
														/>
													) : (
														"No image available"
													)}
												</TableCell>
												<TableCell>
													{item.product?.name ||
														"No name available"}
												</TableCell>
												<TableCell>
													{item.product?.width &&
													item.product?.height
														? `w:${item.product.width} x h:${item.product.height}`
														: "Dimensions unavailable"}
												</TableCell>
												<TableCell>
													$
													{item.product
														? (getOrderItemPrice(
																item
														  ) *
																item.quantity) /
														  100
														: "Price unavailable"}
												</TableCell>
											</TableRow>
										))}
								</TableBody>
							</Table>
						</Box>
					</Collapse>
				</TableCell>
			</TableRow>
		</React.Fragment>
	);
}
export default function OrdersTable({ userId }) {
	const [orders, setOrders] = useState([]);
	const [total, setTotal] = useState(0);
	const [page, setPage] = useState(0);
	const [size, setSize] = useState(10);
	const [search, setSearch] = useState("");
	const [isLoading, setIsLoading] = useState(true);
	useEffect(() => {
		(async () => {
			try {
				const requestData = userId
					? {
							userId,
							page,
							size,
							...(() => (search.length ? { search } : {}))(),
					  }
					: {
							page,
							size,
							...(() => (search.length ? { search } : {}))(),
					  };
				const { total: newTotal, orders: newOrders } = await fetch(
					"/api/getOrders",
					{
						headers: { "Content-Type": "application/json" },
						method: "POST",
						credentials: "include",
						body: JSON.stringify(requestData),
					}
				).then((response) => {
					if (!response.ok)
						throw new Error("Network response was not okay");
					return response.json();
				});
				setTotal(newTotal);
				setOrders(newOrders);
				setIsLoading(false);
			} catch (e) {
				toast.error(e.message);
			}
		})();
	}, [page, size, search]);
	return (
		<ThemeProvider theme={theme}>
			<Box>
				<TableContainer>
					<Typography
						variant="h4"
						gutterBottom
						component="h2"
						color="primary.main"
					>
						Orders
					</Typography>
					<Box
						sx={{
							display: "flex",
							gap: "10px",
							alignItems: "center",
							marginBottom: "14px",
						}}
					>
						<TextField
							sx={{ width: "100%" }}
							label="Search"
							onChange={(event) =>
								setSearch(() => {
									setPage(0);
									return event.target.value;
								})
							}
						/>
					</Box>
					<Table>
						<TableHead>
							<TableRow>
								<TableCell />
								<TableCell>Id</TableCell>
								<TableCell>User</TableCell>
								<TableCell>Status</TableCell>
								<TableCell>Delivery method</TableCell>
								<TableCell>Created at</TableCell>
								<TableCell>Updated at</TableCell>
								<TableCell>Tax</TableCell>
								<TableCell>Total</TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{isLoading ? (
								<TableRow>
									<TableCell colSpan={7} align="center">
										<CircularProgress />
									</TableCell>
								</TableRow>
							) : (
								orders.map((order) => (
									<Row order={order} key={order.id} />
								))
							)}
						</TableBody>
					</Table>
				</TableContainer>
				<TablePagination
					count={total}
					rowsPerPage={size}
					page={page}
					onPageChange={(event, newPage) => setPage(newPage)}
					onRowsPerPageChange={(event) => {
						setSize(event.target.value);
						setPage(0);
					}}
					component="div"
					rowsPerPageOptions={[10, 20, 30, 40]}
				/>
			</Box>
		</ThemeProvider>
	);
}
