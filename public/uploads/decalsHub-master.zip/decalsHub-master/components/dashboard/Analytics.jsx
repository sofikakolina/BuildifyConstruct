"use client";
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import makeApiRequest from '@/libs/makeApiRequest';
import Image from 'next/image';
import {
	CircularProgress,
	Container,
	Paper
} from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import LocalMallOutlinedIcon from '@mui/icons-material/LocalMallOutlined';
import MonetizationOnOutlinedIcon from '@mui/icons-material/MonetizationOnOutlined';
import PercentIcon from '@mui/icons-material/Percent';
import AddCardIcon from '@mui/icons-material/AddCard';
import PrecisionManufacturingIcon from '@mui/icons-material/PrecisionManufacturing';
import CachedIcon from '@mui/icons-material/Cached';
const Chart = dynamic(() => import('react-apexcharts'), { ssr: false });
import { motion } from 'framer-motion';
import { fadeInOut } from '@/libs/animations';
import { getOrderTax } from '@/libs/calculations';
import { PaymentStatus } from '@prisma/client';
import { Box } from "@mui/material"

const salesChartOptions = {
	chart: {
		id: 'basic-bar',
		toolbar: { show: false },
		background: '#ffffff',
		foreColor: '#333',
		animations: {
			enabled: true,
			easing: 'easeinout',
			speed: 800,
			animateGradually: {
				enabled: true,
				delay: 150
			},
			dynamicAnimation: {
				enabled: true,
				speed: 350
			}
		},
		dropShadow: {
			enabled: true,
			top: 3,
			left: 3,
			blur: 4,
			opacity: 0.1
		}
	},
	dataLabels: { enabled: false },
	colors: ['#4CAF50', '#FF5722'],
	xaxis: {
		type: 'datetime',
		labels: { formatter: value => new Date(value).toLocaleDateString() },
	},
	stroke: { curve: 'smooth' },
	fill: {
		type: 'gradient',
		gradient: {
			shadeIntensity: 1,
			opacityFrom: 0.7,
			opacityTo: 0.9,
			stops: [0, 100],
		},
	},
	tooltip: { x: { format: 'dd/MM/yy' } },
	grid: {
		borderColor: '#e7e7e7',
		row: {
			colors: ['#f3f3f3', 'transparent'],
			opacity: 0.5
		},
	},
};

const CardComponent = ({ icon, title, value, bgColor, textColor }) => (
	<motion.div {...fadeInOut} transition={{ ease: 'easeOut' }}>
		<div className={`${bgColor} rounded-xl shadow-lg p-6 flex items-center space-x-4`}>
			<div className={`${textColor} p-3 rounded-full`}>
				{icon}
			</div>
			<div>
				<div className="text-lg font-semibold text-gray-700">{title}</div>
				<div className="text-3xl font-bold text-gray-900">{value}</div>
			</div>
		</div>
	</motion.div>
);

export default function Dashboard({userRole}) {
	const [analytics, setAnalytics] = useState(null);
	const [salesChartData, setSalesChartData] = useState([]);
	const [taxesChartData, setTaxesChartData] = useState([]);
	const [isLoading, setIsLoading] = useState(true);
	const [show, setShow] = useState((userRole=="Admin" || userRole=="Manager"))

	useEffect(() => {
		if (show) {
			(async () => {
				const analytics = await makeApiRequest('/api/getAnalytics');
				const salesDataMap = new Map();
				const taxesDataMap = new Map();
				const today = new Date();
				const last30Days = Array.from({ length: 30 }, (_, i) => {
					const date = new Date(today);
					date.setDate(today.getDate() - i);
					return date.toISOString().split('T')[0];
				}).reverse();
	
				last30Days.forEach(day => {
					salesDataMap.set(day, 0);
					taxesDataMap.set(day, 0);
				});
	
				analytics.payments.forEach(payment => {
					const day = payment.createdAt.split('T')[0];
					if (salesDataMap.has(day)) {
						salesDataMap.set(day, salesDataMap.get(day) + payment.amount);
						taxesDataMap.set(day, taxesDataMap.get(day) + getOrderTax(payment.order));
					}
				});
	
				setSalesChartData(Array.from(salesDataMap.entries()).map(([key, value]) => ({ x: key, y: value / 100 })));
				setTaxesChartData(Array.from(taxesDataMap.entries()).map(([key, value]) => ({ x: key, y: value / 100 })));
				setAnalytics(analytics);
				setIsLoading(false);
			})();
		} else {
			setIsLoading(false);
		}
	}, [show]);
	

	if (isLoading) {
		return (
			<div className="flex justify-center items-center h-screen">
				<CircularProgress />
			</div>
		);
	}

	return (
		show ? 
		<div className='px-6'>
			<h1 className="text-4xl font-bold mb-10 text-primary">Analytics this year</h1>
			<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
				<CardComponent
					icon={<PersonIcon className="text-white" />}
					title="New users"
					value={analytics.newUsersThisYear}
					bgColor="bg-blue-50"
					textColor="bg-blue-500"
				/>
				<CardComponent
					icon={<LocalMallOutlinedIcon className="text-white" />}
					title="Orders"
					value={analytics.payments.length}
					bgColor="bg-green-50"
					textColor="bg-green-500"
				/>
				<CardComponent
					icon={<MonetizationOnOutlinedIcon className="text-white" />}
					title="Monetization"
					value={`$${(analytics.payments.reduce((amount, payment) => amount + payment.amount, 0) / 100).toFixed(2)}`}
					bgColor="bg-yellow-50"
					textColor="bg-yellow-500"
				/>
				<CardComponent
					icon={<PercentIcon className="text-white" />}
					title="Conversion"
					value={`${(analytics.conversion).toFixed(2)}%`}
					bgColor="bg-purple-50"
					textColor="bg-purple-500"
				/>
				<CardComponent
					icon={<AddCardIcon className="text-white" />}
					title="Average order"
					value={`$${analytics.payments.length ? (analytics.payments.reduce((sum, p) => sum + p.amount, 0) / analytics.payments.length / 100).toFixed(2) : 0}`}
					bgColor="bg-pink-50"
					textColor="bg-pink-500"
				/>
				<CardComponent
					icon={<PrecisionManufacturingIcon className="text-white" />}
					title="Orders in production"
					value={analytics.incompleteOrders}
					bgColor="bg-indigo-50"
					textColor="bg-indigo-500"
				/>
				<CardComponent
					icon={<CachedIcon className="text-white" />}
					title="Refunded"
					value={`$${(analytics.payments.reduce((sum, p) => p.status === PaymentStatus.Refunded ? sum + p.amount : sum, 0) / 100).toFixed(2)}`}
					bgColor="bg-red-50"
					textColor="bg-red-500"
				/>
			</div>
			<div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
				<motion.div {...fadeInOut} transition={{ ease: 'easeOut' }}>
					<Paper className="p-8 rounded-xl shadow-lg">
						<h2 className="text-2xl font-semibold mb-6 text-gray-800">Sales</h2>
						<Chart
							series={[
								{ name: 'Sales', data: salesChartData },
								{ name: 'Taxes', data: taxesChartData, color: 'red' },
							]}
							options={salesChartOptions}
							type="area"
							width="100%"
							height={350}
						/>
					</Paper>
				</motion.div>
				<motion.div {...fadeInOut} transition={{ ease: 'easeOut' }}>
					<Paper className="p-8 rounded-xl shadow-lg">
						<h2 className="text-2xl font-semibold mb-6 text-gray-800">Top 5 Products</h2>
						{analytics.products.map((product, index) => (
							<div key={index} className="flex items-center space-x-6 mb-6">
								<span className="text-lg font-semibold text-gray-700">{index + 1}.</span>
								<div className="relative w-full max-w-[150px] rounded-lg overflow-hidden bg-gray-200">
									<div className="relative w-full h-24">
										<Image
											loading="lazy"
											src={product.image}
											alt={product.name}
											layout="fill"
											objectFit="contain"
											className="rounded-lg"
										/>
									</div>
								</div>


								<span className="text-lg text-gray-800">{product.name}</span>
							</div>
						))}
					</Paper>
				</motion.div>
			</div>
		</div> :  <h1 className="text-4xl font-bold mb-10 text-primary text-center items-center h-full">Welcome to decalsHub!</h1>
	);
}
