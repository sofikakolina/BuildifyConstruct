import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import React, { useState } from "react";
import ImageDropzone from "./ImageDropzoneProof";
import toast from "react-hot-toast";
import { createProofMessage } from "@/app/actions/createProofMessage";
import { saveAs } from "file-saver";
import { FiDownload } from "react-icons/fi";

export default function Proofing({ productRequest, session }) {
	const [proofs, setProofs] = useState(productRequest.proofs || []);
	const [newMessage, setNewMessage] = useState("");
	const [creationMessage, setCreationMessage] = useState("");
	const [expanded, setExpanded] = useState(null);
	const [error, setError] = useState("");
	const [uploadedImage, setUploadedImage] = useState(null);
	const [isLightboxOpen, setIsLightboxOpen] = useState(false);
	const [lightboxIndex, setLightboxIndex] = useState(0);
	const [lightboxImages, setLightboxImages] = useState([]);

	const openLightbox = (images, index) => {
		setLightboxImages(images.filter((src) => /\.(jpeg|jpg|png|gif)$/i.test(src)));
		setLightboxIndex(index);
		setIsLightboxOpen(true);
	  };	  

	const saveProof = async () => {
		if (!uploadedImage) {
			toast.error("Please upload a file before saving.");
			return;
		}
		if (!creationMessage.trim()) {
			toast.error("Please enter a message for the proof.");
			return;
		}
		try {
			const createResponse = await fetch("/api/createProof", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					productRequestId: productRequest.id,
					assetSrc: uploadedImage,
					messageContent: creationMessage,
					userId: session.user.id,
				}),
			});

			if (!createResponse.ok) {
				const errorData = await createResponse.json();
				throw new Error(errorData.error || "Failed to create proof.");
			}

			const { proof } = await createResponse.json();
			const proofDetailsResponse = await fetch("/api/getProof", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ id: proof.id }),
			});

			if (!proofDetailsResponse.ok) {
				throw new Error("Failed to fetch proof details.");
			}

			const { proof: fullProof } = await proofDetailsResponse.json();
			setProofs((prevProofs) => [...prevProofs, fullProof]);
			setUploadedImage(null);
			setCreationMessage("");
			toast.success("Proof created successfully with a message!");
		} catch (error) {
			console.error("Error saving proof:", error.message);
			toast.error("Failed to save proof.");
		}
	};

	const toggleExpand = (index) => {
		setExpanded(expanded === index ? null : index);
	};

	const sendMessage = async (proofId) => {
		if (!newMessage.trim()) {
			toast.error("Please enter a message to send.");
			return;
		}

		try {
			const proofMessage = await createProofMessage({
				proofId,
				content: newMessage,
				userId: session.user.id,
			});

			const updatedProofs = proofs.map((proof) =>
				proof.id === proofId
					? { ...proof, messages: [...proof.messages, proofMessage] }
					: proof
			);

			setProofs(updatedProofs);
			setNewMessage("");
			toast.success("Message sent successfully!");
		} catch (error) {
			console.error("Error sending message:", error.message);
			toast.error("Failed to send message.");
		}
	};

	return (
		<div className="flex flex-col gap-6 bg-white shadow-lg rounded-lg p-6">
			<h1 className="text-2xl font-bold text-center">Proofs</h1>
			<div className="border-t border-gray-200 my-4"></div>

			<div className="flex flex-col gap-4">
				{proofs.map((proof, index) => (
					<div
						key={proof.id}
						className="border p-4 rounded-lg shadow-sm"
					>
						<div className="flex justify-between items-center">
							<div>
								<p>
									<strong>Version:</strong> {index + 1}
								</p>
								<p>
									<strong>Status:</strong>{" "}
									{proof.accepted ? "Approved" : "Pending"}
								</p>
								<p>
									<strong>Created At:</strong>{" "}
									{new Date(proof.createdAt).toLocaleString()}
								</p>
							</div>
							<button
								onClick={() => toggleExpand(index)}
								className="text-sm text-blue-500 hover:underline"
							>
								{expanded === index
									? "Hide Details"
									: "View Details"}
							</button>
						</div>
						{expanded === index && (
							<div className="mt-4">
								<div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
									{proof.assets.map((asset, assetIndex) => {
										const isImage = /\.(jpeg|jpg|png|gif)$/i.test(asset.src); // Проверка на изображение

										return (
											<div className="relative" key={asset.id}>
												{isImage ? (
													<img
														src={asset.src}
														alt="Proof Asset"
														className="rounded-lg shadow-md cursor-pointer"
														onClick={() =>
															openLightbox(
																proof.assets.filter((a) => /\.(jpeg|jpg|png|gif)$/i.test(a.src)).map((a) => a.src),
																assetIndex
															)
														}
													/>
												) : (
													<div className="p-4 bg-gray-100 rounded-lg shadow-md">
														<p className="text-sm text-gray-700">
															<a
																href={asset.src}
																target="_blank"
																rel="noopener noreferrer"
																className="text-blue-500 hover:underline"
															>
																{decodeURIComponent(asset.src.split("/").pop())}
															</a>
														</p>
													</div>
												)}
												<button
													onClick={async () => {
														const fileName = decodeURIComponent(asset.src.split("/").pop());
														const response = await fetch(
															`/api/download?fileName=${encodeURIComponent(asset.src)}`
														);
														if (!response.ok) {
															toast.error("Failed to download file.");
															return;
														}
														const blob = await response.blob();
														saveAs(blob, fileName);
													}}
													className="absolute top-2 right-2 bg-white p-2 rounded-full shadow-md flex items-center justify-center hover:bg-gray-100"
													aria-label="Download"
												>
													<FiDownload className="text-blue-500" size={20} />
												</button>
											</div>
										);
									})}

								</div>
								<div className="mt-4 space-y-2">
									{proof.messages.map((message) => (
										<div
											key={message.id}
											className="p-2 bg-gray-100 rounded-lg"
										>
											<p className="text-sm font-semibold">
												{message.user.name || "Unknown"}
												:
											</p>
											<p>{message.content}</p>
										</div>
									))}
								</div>
								<div className="mt-4 flex items-center gap-2">
									<textarea
										className="border rounded-lg p-2 w-full"
										placeholder="Add a message to this proof"
										value={newMessage}
										onChange={(e) =>
											setNewMessage(e.target.value)
										}
									></textarea>
									<button
										onClick={() => sendMessage(proof.id)}
										className="px-4 py-2 bg-blue-500 text-white rounded-lg"
									>
										Send Message
									</button>
								</div>
							</div>
						)}
					</div>
				))}

				<ImageDropzone
					onDrop={(path) => {
						setUploadedImage(path);
						setError("");
					}}
					initialImage={uploadedImage}
					error={error}
				/>

				<textarea
					className="border rounded-lg p-4 min-h-40 w-full"
					placeholder="Add a message for the new proof"
					value={creationMessage}
					onChange={(e) => setCreationMessage(e.target.value)}
				></textarea>

				<button
					onClick={saveProof}
					className="px-4 py-2 bg-green-500 text-white rounded-lg"
				>
					Save Proof
				</button>
			</div>

			{isLightboxOpen && (
				<Lightbox
					mainSrc={lightboxImages[lightboxIndex]}
					nextSrc={
						lightboxImages[
						(lightboxIndex + 1) % lightboxImages.length
						]
					}
					prevSrc={
						lightboxImages[
						(lightboxIndex + lightboxImages.length - 1) %
						lightboxImages.length
						]
					}
					onCloseRequest={() => setIsLightboxOpen(false)}
					onMovePrevRequest={() =>
						setLightboxIndex(
							(lightboxIndex + lightboxImages.length - 1) %
							lightboxImages.length
						)
					}
					onMoveNextRequest={() =>
						setLightboxIndex(
							(lightboxIndex + 1) % lightboxImages.length
						)
					}
				/>
			)}
		</div>
	);
}
