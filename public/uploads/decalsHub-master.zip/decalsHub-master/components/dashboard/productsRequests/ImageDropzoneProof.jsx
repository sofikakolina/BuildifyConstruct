import React, { useState, useCallback, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import makeApiRequest from "@/libs/makeApiRequest";
import toast from "react-hot-toast";

export default function ImageDropzone({ onDrop, initialImage, error }) {
  const [isLoading, setIsLoading] = useState(false);
  const [thumbnail, setThumbnail] = useState(initialImage);
  const [fileName, setFileName] = useState(
    initialImage?.substring(initialImage.lastIndexOf("/") + 1)
  );

  const onDropCallback = useCallback(
    async (acceptedFiles) => {
      if (!acceptedFiles || acceptedFiles.length === 0) {
        toast.error("No file selected.");
        return;
      }

      setIsLoading(true);
      const file = acceptedFiles[0];

      try {

        setFileName(file.name);
        setThumbnail(URL.createObjectURL(file));

        const formData = new FormData();
        formData.append("file", file);

        const response = await fetch("/api/uploadFile", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          throw new Error("Failed to upload file.");
        }

        const { path } = await response.json();
        onDrop(path);
        toast.success("File uploaded successfully!");
      } catch (error) {
        console.error("Upload error:", error);
        toast.error("An error occurred during file upload.");
      } finally {
        setIsLoading(false);
      }
    },
    [onDrop]
  );


  const { getRootProps, getInputProps } = useDropzone({
    onDrop: onDropCallback,
    accept: {
      "image/*": [".jpeg", ".jpg", ".png"],
      "application/pdf": [".pdf"],
      "application/postscript": [".eps"],
    },
    maxFiles: 1,
  });


  return (
    <div className="flex flex-col items-center">
      <div
        {...getRootProps()}
        className={`w-full p-6 border-2 border-dashed rounded-lg text-center cursor-pointer flex items-center justify-center transition-all min-h-52 duration-200 ${error ? "border-red-500 bg-red-50" : "border-gray-300 bg-gray-100"
          }`}
      >
        <input {...getInputProps()} />
        {!thumbnail && !isLoading && (
          <p className="text-gray-500 font-semibold">
            Drag & drop a file (JPEG, PNG, PDF, EPS) here, or click to select
          </p>
        )}

        {thumbnail && !isLoading && (
          <div className="flex flex-col items-center">
            {fileName.match(/\.(jpeg|jpg|png)$/i) ? (
              <img
                src={thumbnail}
                alt="Preview"
                className="w-32 h-32 object-cover rounded-lg shadow-md"
              />
            ) : (
              <div className="w-32 h-32 flex items-center justify-center bg-gray-200 rounded-lg shadow-md">
                <p className="text-gray-600 text-sm text-center px-2">{fileName}</p>
              </div>
            )}
            <p className="mt-2 text-gray-600 text-sm">{fileName}</p>
            <button
              onClick={() => {
                setThumbnail(null);
                setFileName(null);
                onDrop(null); // Уведомить родительский компонент об удалении
              }}
              className="mt-2 px-4 py-2 bg-red-500 text-white rounded-lg shadow-md hover:bg-red-600"
            >
              Remove File
            </button>
          </div>
        )}

        {isLoading && (
          <div className="flex justify-center items-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-gray-500"></div>
          </div>
        )}
      </div>
      {error && (
        <p className="mt-2 text-sm text-red-500">
          {error || "An error occurred during file upload."}
        </p>
      )}
    </div>
  );
}
