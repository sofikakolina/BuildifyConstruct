"use client";
import { Typography } from "@mui/material";
import { useState } from "react";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";
import Proofing from "./Proofs";
import CreateProduct from "./Form";
import { Role } from "@prisma/client";
import { FiDownload } from "react-icons/fi";
import { saveAs } from "file-saver";

export default function ProductRequestDetails({ productRequest, session }) {
	if (!productRequest) {
		return (
			<Typography variant="h6">
				Product request data is not available
			</Typography>
		);
	}

	const {
		name,
		description,
		createdAt,
		companyName,
		usDotNumber,
		mcNumber,
		kyuNumber,
		vinNumber,
		grossWeight,
		stickerDetails = [],
		hasLogo,
		status,
		images = [],
		user,
	} = productRequest;

	const [isOpen, setIsOpen] = useState(false);
	const [photoIndex, setPhotoIndex] = useState(0);

	const imagesSrc = images.map((image) => image.src);

	return (
		<>
			<div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
				<div className="bg-white shadow-lg rounded-lg p-6 space-y-6">
					<h1 className="text-2xl font-bold text-center">
						{name || "Product Request Details"}
					</h1>
					<div className="border-t border-gray-200 my-4"></div>

					<div className="grid grid-cols-2">
						<div>
							<h2 className="text-lg font-semibold mb-2">
								General Information
							</h2>

							<p className="text-gray-600">
								<strong>Created At:</strong>{" "}
								{new Date(createdAt).toLocaleString()}
							</p>
							<div className="mt-2">
								<strong>Status:</strong>{" "}
								<span
									className={`px-3 py-1 rounded-full text-white ${status === "REQUESTED"
										? "bg-blue-500"
										: "bg-green-500"
										}`}
								>
									{status}
								</span>
							</div>
						</div>
						<p className="text-gray-600">
							<strong>Description:</strong>{" "}
							{description || "No description provided"}
						</p>
					</div>

					{/* Company Details */}
					<div>
						<h2 className="text-lg font-semibold mb-2">
							Company Details
						</h2>
						<p className="text-gray-600">
							<strong>Company Name:</strong>{" "}
							{companyName || "N/A"}
						</p>
						<p className="text-gray-600">
							<strong>USDOT Number:</strong>{" "}
							{usDotNumber || "N/A"}
						</p>
						<p className="text-gray-600">
							<strong>MC Number:</strong> {mcNumber || "N/A"}
						</p>
						<p className="text-gray-600">
							<strong>KYU Number:</strong> {kyuNumber || "N/A"}
						</p>
						<p className="text-gray-600">
							<strong>VIN Number:</strong> {vinNumber || "N/A"}
						</p>
						<p className="text-gray-600">
							<strong>Gross Weight:</strong>{" "}
							{grossWeight ? `${grossWeight} lbs` : "N/A"}
						</p>
					</div>

					{/* Sticker Details */}
					<div>
						<h2 className="text-lg font-semibold mb-2">
							Sticker Details
						</h2>
						{stickerDetails.length > 0 ? (
							<ul className="space-y-4">
								{stickerDetails.map((detail) => (
									<li
										key={detail.id}
										className="bg-gray-50 p-4 rounded-lg shadow-sm"
									>
										<p className="text-gray-600">
											<strong>Type:</strong>{" "}
											{detail.stickerType}
										</p>
										<p className="text-gray-600">
											<strong>Quantity:</strong>{" "}
											{detail.quantity}
										</p>
										{detail.data && (
											<p className="text-gray-600">
												<strong>
													Additional Data:
												</strong>{" "}
												{detail.data}
											</p>
										)}
									</li>
								))}
							</ul>
						) : (
							<p className="text-gray-600">
								No sticker details available
							</p>
						)}
						<p className="text-gray-600">
							<strong>Includes Logo:</strong>{" "}
							{hasLogo ? "Yes" : "No"}
						</p>
					</div>

					{/* User Information */}
					<div>
						<h2 className="text-lg font-semibold mb-2">
							User Information
						</h2>
						<p className="text-gray-600">
							<strong>Name:</strong> {user?.name || "N/A"}
						</p>
						<p className="text-gray-600">
							<strong>Email:</strong> {user?.email || "N/A"}
						</p>
					</div>

					{/* Images */}
					<div>
						<h2 className="text-lg font-semibold mb-2">Images</h2>
						{images && images.length > 0 ? (
							<div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
								{images.map((image, index) => {
									const fileName = decodeURIComponent(image.src.split("/").pop());
									const isImage = /\.(jpeg|jpg|png|gif)$/i.test(image.src); // Проверка на изображение

									return (
										<div key={image.id} className="relative group">
											{isImage ? (
												<img
													src={image.src}
													alt="Product Image"
													className="w-full h-auto rounded-lg shadow-md cursor-pointer"
													onClick={() => {
														setPhotoIndex(index);
														setIsOpen(true);
													}}
												/>
											) : (
												<div className="w-full h-32 flex items-center justify-center border rounded-lg shadow-md bg-gray-100 text-gray-700">
													<p className="text-center text-xs px-2">{fileName}</p>
												</div>
											)}
											<button
												onClick={async () => {
													const response = await fetch(
														`/api/download?fileName=${encodeURIComponent(image.src)}`
													);
													if (!response.ok) {
														toast.error("Failed to download file.");
														return;
													}
													const blob = await response.blob();
													saveAs(blob, fileName);
												}}
												className="absolute top-2 right-2 bg-white p-2 rounded-full shadow-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
												aria-label="Download"
											>
												<FiDownload className="text-blue-500" size={20} />
											</button>
										</div>
									);
								})}
							</div>
						) : (
							<p className="text-gray-600">No images available</p>
						)}
					</div>

					{/* Lightbox */}
					{isOpen && imagesSrc.some((src) => /\.(jpeg|jpg|png|gif)$/i.test(src)) && (
						<Lightbox
							className="absolute z-[9999]"
							mainSrc={imagesSrc[photoIndex]}
							nextSrc={imagesSrc[(photoIndex + 1) % imagesSrc.length]}
							prevSrc={
								imagesSrc[(photoIndex + imagesSrc.length - 1) % imagesSrc.length]
							}
							onCloseRequest={() => setIsOpen(false)}
							onMovePrevRequest={() =>
								setPhotoIndex((photoIndex + imagesSrc.length - 1) % imagesSrc.length)
							}
							onMoveNextRequest={() =>
								setPhotoIndex((photoIndex + 1) % imagesSrc.length)
							}
						/>
					)}
				</div>
				<Proofing session={session} productRequest={productRequest} />
			</div>
			{session.user.role === Role.Admin && (
				<div className="flex my-6 w-full">
					<CreateProduct productRequest={productRequest} />
				</div>
			)}
		</>
	);
}
