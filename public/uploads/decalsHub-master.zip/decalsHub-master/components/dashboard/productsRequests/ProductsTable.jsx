"use client";
import { useState, useEffect } from "react";
import React from "react";
import {
	Box,
	Typography,
	Button,
	CircularProgress,
	TablePagination,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	Avatar,
} from "@mui/material";
import Link from "next/link";
import makeApiRequest from "@/libs/makeApiRequest";
import toast from "react-hot-toast";
const styles = {
	mainBox: {
		display: "flex",
		flexDirection: "column",
		gap: "32px",
		py: "2rem",
	},
	headerBox: { display: "flex", justifyContent: "space-between" },
	title: { fontSize: "48px", fontWeight: "medium" },
	addButton: { color: "white", px: 3, py: 1, fontSize: "0.9rem" },
};
function Row({ productRequest, user }) {

	// Определяем цвета в зависимости от статуса
	const statusColors = {
		REQUESTED: "blue",
		IN_PROGRESS: "orange",
		DECLINED: "red",
		APPROVED: "green",
	};

	const statusColor = statusColors[productRequest.status] || "gray";

	return (
		<>
			<TableRow sx={{ "& > *": { borderBottom: "unset" } }}>
				<TableCell>
					<Box
						sx={{
							display: "flex",
							alignItems: "center",
							gap: "10px",
						}}
					>
						<Avatar src={user.image} alt={user.name} />
						<Box>
							<Typography variant="body1">{user.name}</Typography>
							<Typography variant="body2" color="text.secondary">
								{user.email}
							</Typography>
							<Typography variant="body2" color="text.secondary">
								{user.company}
							</Typography>
						</Box>
					</Box>
				</TableCell>
				<TableCell>
					{new Date(productRequest.createdAt).toLocaleString(
						"en-US",
						{
							year: "numeric",
							month: "long",
							day: "numeric",
							hour: "2-digit",
							minute: "2-digit",
							second: "2-digit",
						}
					)}
				</TableCell>
				<TableCell>{productRequest.companyName}</TableCell>
				<TableCell>
					<Typography
						sx={{
							px: 2,
							py: 0.5,
							borderRadius: 1,
							color: "white",
							backgroundColor: statusColor,
							display: "inline-block",
						}}
					>
						{productRequest.status}
					</Typography>
				</TableCell>
				<TableCell>
					<Link
						href={`/dashboard/productsRequests/${productRequest.id}`}
					>
						<Button
							sx={styles.addButton}
							color="primary"
							variant="contained"
						>
							Details
						</Button>
					</Link>
				</TableCell>
			</TableRow>
		</>
	);
}


export default function ProductsTable() {
	const [productsRequests, setProductsRequests] = useState([]);
	const [total, setTotal] = useState(0);
	const [isLoading, setIsLoading] = useState(true);
	const [page, setPage] = useState(0);
	const [size, setSize] = useState(10);

	useEffect(() => {
		handleFetch();
	}, [size, page]);
	async function handleFetch() {
		try {
			const { total: newTotal, productsRequests: newProductsRequests } =
				await makeApiRequest("/api/getProductsRequests", {
					page,
					size,
				});
			setTotal(newTotal);
			setProductsRequests(newProductsRequests);
			setIsLoading(false);
		} catch (e) {
			toast.error(e.message);
		}
	}

	return (
		<Box>
			<TableContainer>
				<Table>
					<TableHead>
						<TableRow>
							<TableCell>User</TableCell>
							<TableCell>Date</TableCell>
							<TableCell>Company Name</TableCell>
							<TableCell>Status</TableCell>
							<TableCell>Actions</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{isLoading ? (
							<TableRow>
								<TableCell colSpan={7} align="center">
									<CircularProgress />
								</TableCell>
							</TableRow>
						) : (
							productsRequests.map((productRequest) => (
								<Row
									productRequest={productRequest}
									user={productRequest.user}
									key={productRequest.id}
								/>
							))
						)}
					</TableBody>
				</Table>
			</TableContainer>
			<TablePagination
				count={total}
				rowsPerPage={size}
				page={page}
				onPageChange={(event, newPage) => setPage(newPage)}
				onRowsPerPageChange={(event) => {
					setSize(event.target.value);
					setPage(0);
				}}
				component="div"
				rowsPerPageOptions={[10, 20, 30, 40]}
			/>
		</Box>
	);
}
