"use client";
import React, { useState, useEffect } from "react";
import {
	Box,
	Typography,
	Paper,
	Grid,
	Button,
	Stack,
	InputAdornment,
	TextField,
	Autocomplete,
	Checkbox,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { grey, red } from "@mui/material/colors";
import MaterialsSelector from "./MaterialsSelector";
import makeApiRequest from "@/libs/makeApiRequest";
import ImageDropzone from "./ImageDropzone";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
export default function CreateProduct({ productRequest, product }) {
	const [users, setUsers] = useState([]);
	const [materials, setMaterials] = useState(
		product?.productMaterials.map((pm) => pm.material) || []
	);
	const [isLoading, setIsLoading] = useState(false);
	const [categoryId, setCategoryId] = useState(product?.categoryId);
	const [categories, setCategories] = useState([]);
	const [newCategory, setNewCategory] = useState("");
	const router = useRouter();
	const productSchema = Yup.object().shape({
		name: Yup.string()
			.required("Product name is required")
			.max(50, "Product name must be less than 50 characters"),
		height: Yup.number().typeError("Not a number").nullable().notRequired(),
		width: Yup.number().typeError("Not a number").nullable().notRequired(),
		description: Yup.string().max(
			200,
			"Description must be less than 200 characters"
		),
		discount: Yup.number()
			.typeError("Not a number")
			.nullable()
			.transform((value, originalValue) =>
				String(originalValue).trim() === "" ? null : value
			)
			.min(0, "Discount cannot be less than 0%")
			.max(100, "Discount cannot be more than 100%")
			.notRequired(),
		image: Yup.mixed().required("A file is required"),
	});
	const {
		register,
		handleSubmit,
		watch,
		setValue,
		control,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(productSchema),
		mode: "onChange",
		defaultValues: {
			name: productRequest?.name,
			description: productRequest?.description
				? productRequest.description
				: "",
			image: product?.image,
			discount: product?.discount || "0",
			width: product?.width,
			height: product?.height,
			user: productRequest?.user,
		},
	});
	const [discount, width, height, user] = watch([
		"discount",
		"width",
		"height",
		"user",
	]);
	useEffect(() => {
		setIsLoading(true);
		Promise.all([
			makeApiRequest("/api/getCustomers", {
				size: Number.MAX_SAFE_INTEGER,
			}).then(({ users }) => setUsers(users)),
			makeApiRequest("/api/getProductsCategories").then(
				({ productsCategories }) => {
					const noCategory = productsCategories.find(
						(cat) => cat.name === "No category"
					);
					setCategories([
						...productsCategories,
						{ id: null, name: "New category" },
					]);
					if (!product) {
						setCategoryId(noCategory?.id || null);
					} else {
						setCategoryId(product.categoryId);
					}
				}
			),
		])
			.then(() => setIsLoading(false))
			.catch((e) => toast.error(e.message));
	}, []);

	const onSubmit = async (data) => {
		setIsLoading(true);
		["description", "width", "height"].forEach((key) => {
			if (!data[key]) delete data[key];
		});
		const { user, priceFixed, ...value } = data;
		value.price = priceFixed ? Math.round(value.price * 100) : null;
		try {
			const category = categoryId
				? categoryId
				: (
						await makeApiRequest("/api/createProductCategory", {
							name: newCategory,
						})
				  ).productCategory.id;
			if (product) {
				await Promise.all([
					makeApiRequest("/api/editProduct", {
						id: product.id,
						...value,
						...(() =>
							user ? { userId: user.id } : { userId: null })(),
						categoryId: category,
					}),
					...product.productMaterials
						.filter(
							(pm) =>
								!materials.some((m) => m.id == pm.materialId)
						)
						.map((pm) =>
							makeApiRequest("/api/deleteProductMaterial", {
								productId: product.id,
								materialId: pm.materialId,
							})
						),
					...materials
						.filter(
							(m) =>
								!product.productMaterials.find(
									(pm) => pm.materialId == m.id
								)
						)
						.map((m) =>
							makeApiRequest("/api/createProductMaterial", {
								productId: product.id,
								materialId: m.id,
							})
						),
				]);
			} else {
				({ product } = await makeApiRequest("/api/createProduct", {
					...value,
					...(() => (user ? { userId: user.id } : {}))(),
					categoryId: category,
				}));
				await Promise.all(
					materials.map((m) =>
						makeApiRequest("/api/createProductMaterial", {
							productId: product.id,
							materialId: m.id,
						})
					)
				);
				router.push("/dashboard/products");
			}
			setIsLoading(false);
			toast.success("The product has been updated!");
		} catch (e) {
			toast.error(e.message);
		}
	};
	return (
		<>
			<Paper
				square={false}
				elevation={1}
				sx={{ padding: 4, width: "100%" }}
			>
				<Box sx={{ mb: 4 }}>
					<Typography
						color="primary"
						variant="h2"
						sx={{ fontSize: "32px" }}
					>
						{"Create product"}
					</Typography>
				</Box>
				<Box>
					<form onSubmit={handleSubmit(onSubmit)}>
						<Grid container spacing={2} sx={{ mb: 4 }}>
							<Grid item xs={12} md={5}>
								<Typography
									variant="h6"
									sx={{ fontSize: "24px" }}
								>
									Details
								</Typography>
								<Typography
									color={grey[500]}
									variant="p"
									sx={{ fontSize: "14px" }}
								>
									Title, short description, image...
								</Typography>
							</Grid>
							<Grid item xs={12} md={7}>
								<Paper elevation={1} sx={{ padding: 3 }}>
									<Stack
										direction={"column"}
										sx={{
											display: "flex",
											justifyContent: "center",
											flexDirection: "column",
											gap: 2,
										}}
									>
										<TextField
											fullWidth
											label="Product name"
											{...register("name")}
											error={!!errors.name}
											helperText={errors.name?.message}
										/>
										<Grid xs={12} md={12} container>
											<Grid xs={6} item>
												<Autocomplete
													id="category"
													options={categories.filter(
														(cat) =>
															cat.name !==
															"No category"
													)} // Исключаем "No category" из списка
													renderInput={(params) => (
														<TextField
															{...params}
															label="Category"
														/>
													)}
													renderOption={(
														props,
														option
													) => (
														<Box
															component="li"
															{...props}
															key={
																option.id ||
																"new-category"
															}
														>
															{option.name}
														</Box>
													)}
													defaultValue={categories.find(
														(cat) =>
															cat.name ===
															"No category"
													)} // Устанавливаем "No category" по умолчанию
													onChange={(
														event,
														category
													) => {
														if (!category) {
															// Если ничего не выбрано, устанавливаем "No category"
															const noCategory =
																categories.find(
																	(cat) =>
																		cat.name ===
																		"No category"
																);
															setCategoryId(
																noCategory?.id ||
																	null
															);
														} else if (
															category.id === null
														) {
															// Если выбрано "New category"
															setCategoryId(null);
														} else {
															// Устанавливаем выбранную категорию
															setCategoryId(
																category.id
															);
														}
													}}
													isOptionEqualToValue={(
														option,
														value
													) =>
														option.id === value?.id
													}
													getOptionLabel={(option) =>
														option.name
													}
												/>
											</Grid>
											{categoryId === null && (
												<Grid xs={6} item>
													<TextField
														id="new-category"
														label="New category"
														onChange={(event) =>
															setNewCategory(
																event.target
																	.value
															)
														}
													/>
												</Grid>
											)}
										</Grid>
										<TextField
											id="textarea-produt"
											label="Description"
											multiline
											rows={4}
											{...register("description")}
											error={!!errors.description}
											helperText={
												errors.description?.message
											}
										/>
										<Controller
											control={control}
											name="image"
											defaultValue={product?.image}
											render={({
												field: { onChange, value },
											}) => (
												<ImageDropzone
													onDrop={(path) =>
														onChange(path)
													}
													image={value}
													errors={
														errors.image?.message
													}
													red={red}
												/>
											)}
										/>
									</Stack>
								</Paper>
							</Grid>
						</Grid>
						<Grid container spacing={2} sx={{ mb: 4 }}>
							<Grid item xs={12} md={5}>
								<Typography
									variant="h6"
									sx={{ fontSize: "24px" }}
								>
									Materials
								</Typography>
								<Typography
									color={grey[500]}
									variant="p"
									sx={{ fontSize: "14px" }}
								>
									Select Materials, etc
								</Typography>
							</Grid>
							<Grid item xs={12} md={7}>
								<Paper elevation={1} sx={{ padding: 3 }}>
									<MaterialsSelector
										materials={materials}
										setMaterials={setMaterials}
									/>
								</Paper>
							</Grid>
						</Grid>
						<Grid container spacing={2}>
							<Grid item xs={12} md={5}>
								<Typography
									variant="h6"
									sx={{ fontSize: "24px" }}
								>
									Pricing
								</Typography>
								<Typography
									color={grey[500]}
									variant="p"
									sx={{ fontSize: "14px" }}
								>
									Type of product, pricing...
								</Typography>
							</Grid>
							<Grid item xs={12} md={7}>
								<Paper elevation={1} sx={{ padding: 3 }}>
									<Stack
										direction={"column"}
										sx={{
											display: "flex",
											justifyContent: "center",
											flexDirection: "column",
											gap: 2,
										}}
									>
										<Grid container spacing={1}>
											<Grid item xs={4}>
												<TextField
													fullWidth
													label="Discount"
													{...register("discount")}
													error={!!errors.discount}
													helperText={
														errors.discount?.message
													}
													InputProps={{
														startAdornment: (
															<InputAdornment position="start">
																%
															</InputAdornment>
														),
													}}
												/>
											</Grid>
											<Grid item xs={4}>
												<TextField
													fullWidth
													label="Width(in)"
													{...register("width")}
													error={!!errors.width}
													helperText={
														errors.width?.message
													}
													InputProps={{
														startAdornment: (
															<InputAdornment position="start">
																w
															</InputAdornment>
														),
													}}
												/>
											</Grid>
											<Grid item xs={4}>
												<TextField
													fullWidth
													label="Height(in)"
													{...register("height")}
													error={!!errors.height}
													helperText={
														errors.height?.message
													}
													InputProps={{
														startAdornment: (
															<InputAdornment position="start">
																h
															</InputAdornment>
														),
													}}
												/>
											</Grid>
											<Grid item xs={6}>
												<Box
													sx={{
														display: "flex",
														justyfiContent:
															"center",
														alignItems: "center",
														gap: 2,
														width: "100%",
													}}
												>
													<Controller
														name="user"
														fullWidth
														control={control}
														render={({
															field: { onChange },
														}) => (
															<Autocomplete
																disablePortal
																fullWidth
																id="user-select"
																defaultValue={productRequest?.user.id ? {id: productRequest.user.id, name: productRequest.user.name} : null}
																isOptionEqualToValue={(
																	option,
																	value
																) =>
																	option.id ===
																	value.id
																}
																getOptionLabel={(
																	option
																) =>
																	option.name
																}
																options={users.map(
																	(user) => ({
																		id: user.id,
																		name: user.name,
																		company:
																			user.company,
																	})
																)}
																filterOptions={(
																	options,
																	{
																		inputValue,
																	}
																) => {
																	if (
																		!inputValue
																	)
																		return options;
																	return options.filter(
																		(o) =>
																			o.name
																				?.toLowerCase()
																				.includes(
																					inputValue.toLowerCase()
																				) ||
																			o.company
																				?.toLowerCase()
																				.includes(
																					inputValue.toLowerCase()
																				)
																	);
																}}
																onChange={(
																	event,
																	user
																) =>
																	onChange(
																		user
																	)
																}
																sx={{
																	width: 300,
																}}
																renderOption={(
																	props,
																	option
																) => (
																	<Box
																		component="li"
																		{...props}
																		key={
																			option.id
																		}
																	>
																		{
																			option.name
																		}{" "}
																		{
																			option.company
																		}
																	</Box>
																)}
																renderInput={(
																	params
																) => (
																	<TextField
																		{...params}
																		label="Assign to user"
																	/>
																)}
															/>
														)}
													/>
												</Box>
											</Grid>
											<Grid
												item
												xs={6}
												className="flex items-center justify-center space-x-4"
											>
												<Controller
													name="priceFixed"
													control={control}
													render={({
														field: {
															value,
															onChange,
														},
													}) => (
														<div className="flex flex-row items-center text-lg">
															<h3>Fixed price</h3>
															<Checkbox
																checked={value}
																onChange={(
																	event
																) =>
																	onChange(
																		event
																			.target
																			.checked
																	)
																}
															/>
														</div>
													)}
												/>
												<Controller
													name="price"
													control={control}
													render={({
														field: {
															value,
															onChange,
														},
													}) => (
														<TextField
															label="Price"
															value={value}
															error={
																!!errors.price
															}
															helperText={
																errors.price
																	?.message
															}
															onChange={(
																event
															) => {
																setValue(
																	"priceFixed",
																	true
																);
																onChange(
																	event.target
																		.value
																);
															}}
															InputProps={{
																startAdornment:
																	(
																		<InputAdornment position="start">
																			$
																		</InputAdornment>
																	),
															}}
														/>
													)}
												/>
											</Grid>
										</Grid>
									</Stack>
								</Paper>
							</Grid>
						</Grid>
						<Box
							sx={{
								display: "flex",
								justifyContent: "flex-end",
								mt: 4,
								mb: 4,
							}}
						>
							<Button
								type="submit"
								size="large"
								variant="contained"
								color="primary"
								sx={{ color: "white" }}
							>
								{isLoading
									? product
										? "Updating..."
										: "Creating..."
									: product
									? "Update product"
									: "Create product"}
							</Button>
						</Box>
					</form>
				</Box>
				{/* <Box >
					<Grid item xs={12} md={5} sx={{ mb: 4 }}>
						<Typography color="primary" variant="h2" sx={{ fontSize: "32px" }}>{"Data from the user"}</Typography>
					</Grid>
					<Box sx={{ display: 'flex', alignItems: 'center', gap: '10px', mb:4 }}>
						<Avatar src={productRequest.user.image} alt={productRequest.user.name} />
						<Box>
							<Typography variant="body1">{productRequest.user.name}</Typography>
							<Typography variant="body2" color="text.secondary">{productRequest.user.email}</Typography>
							<Typography variant="body2" color="text.secondary">{productRequest.user.company}</Typography>
						</Box>
					</Box>
					<Grid container spacing={1} sx={{ mb: 4 }}>
						<Grid item xs={6} md={5}>
							<Typography variant="h6" sx={{ fontSize: "24px" }}>Name</Typography>
							<Typography color={grey[500]} variant="p" sx={{ fontSize: "14px" }}>{productRequest.name}</Typography>
						</Grid>
						<Grid item xs={6} md={5}>
							<Typography variant="h6" sx={{ fontSize: "24px" }}>Description</Typography>
							<Typography color={grey[500]} variant="p" sx={{ fontSize: "14px" }}>{productRequest.description}</Typography>
						</Grid>
					</Grid>
					<Grid item xs={12} md={5}>
						<Box sx={{display:"flex", justifyContent:"space-between"}}>
							<Typography variant="h6" sx={{ fontSize: "24px" }}>Images</Typography>
							<Button onClick={() => downloadImages(productRequest.images)} disabled  type="submit" size="large" variant="contained" color="primary" sx={{ color: "white" }}>Download all images</Button>
						</Box>
						<div className={`grid grid-cols-1 lg:grid-cols-${Math.min(productRequest.images?.length, 4)} gap-5`}
							style={{
								border: "1px solid #F69220",
								padding: "10px",
								borderRadius: "10px",
								marginTop: "10px",
								gap: "30px"
							}}>


							{productRequest.images?.map((image, index) => (
							<Card key={index} sx={{
								position: "relative", 
								borderRadius: "20px",
								border: "1px solid #e0e0e0",
							}}>
								<CardActionArea sx={{ borderRadius: "20px" }}>
									<CardMedia
										component="img"
										image={image.src}
										alt={image.id}
										sx={{ objectFit: "cover", p: 2 }}
									/>
								
								</CardActionArea>
							</Card>
							))}
						</div>
					</Grid>
				</Box> */}
			</Paper>
		</>
	);
}
