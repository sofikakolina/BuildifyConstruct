"use client"
import React, {useEffect, useState} from "react"
import theme from "@/theme"
import {Collapse, ThemeProvider, CircularProgress, Box, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Typography, useStepContext, Button} from "@mui/material"
import makeApiRequest from "@/libs/makeApiRequest"
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown"
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp"
import dynamic from "next/dynamic"
import toast from "react-hot-toast"
const ReactQuill = dynamic(() => import("react-quill"), {ssr: false})
import "react-quill/dist/quill.snow.css"
import { EmailTemplateType } from "@prisma/client"
const styles = {
	mainBox: {display: "flex", flexDirection: "column", gap: "32px", py: "2rem"},
	headerBox: {display: "flex", justifyContent: "space-between"},
	title: {fontSize: "48px", fontWeight: "medium"},
	addButton: {color: "white", px: 3, py: 1, fontSize: '0.9rem'}
}
function Row({defaultValue}) {
	const [isOpen, setIsOpen] = useState(false)
	const [subject, setSubject] = useState(defaultValue.subject)
	const [html, setHtml] = useState(defaultValue.html)
	const [isEditing, setIsEditing] = useState(false)
	const [editor, setEditor] = useState(null)
	return (
		<>
			<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
				<TableCell>
					<IconButton aria-label="expand row" size="small" onClick={() => setIsOpen(!isOpen)}>
						{isOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
					</IconButton>
				</TableCell>
				<TableCell>{defaultValue.type}</TableCell>
			</TableRow>
			<TableRow>
				<TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
					<Collapse in={isOpen} timeout="auto" unmountOnExit>
						<Box sx={{ margin: 1 }}>
							<Table size="small" aria-label="items">
								<TableHead>
									<TableRow>
										<TableCell>View</TableCell>
										<TableCell>Actions</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									<TableRow>
										<TableCell>
											<div className="flex w-full text-editor flex-col">
												<div id="toolbar" className="w-full">
													<span className="ql-formats">
														<select className="ql-header" defaultValue="3">
															<option value="1">Heading</option>
															<option value="2">Subheading</option>
															<option value="3">Normal</option>
														</select>
													</span>
													<span className="ql-formats">
														<button className="ql-bold" />
														<button className="ql-italic" />
														<button className="ql-underline" />
														<button className="ql-strike" />
														<button className="ql-clean" />
													</span>
													<span className="ql-formats">
														<button className="ql-list" value="ordered" />
														<button className="ql-list" value="bullet" />
													</span>
													<span className="ql-formats">
														<button className="ql-link" />
														<button className="ql-image" />
														<button className="ql-video" />
													</span>
												</div>
												<div className="px-4 py-2 w-full space-x-6 border-gray-300 border-[1px]">
													<span>Variables:</span>
													{
														(defaultValue.type == EmailTemplateType.Invoice ? [
															"name", "email", "company", "phone", "order", "invoice", "invoice-due-date",
														] : defaultValue.type == EmailTemplateType.Proof ? [
															"proof-link", "name"
														] : defaultValue.type == EmailTemplateType.ProofMessage ? [
															"sender", "recipient", "company", "message", "proof-link"
														]: []).map(value => (
															<button key={value} className="hover:text-blue-500 transition-colors duration-100" onClick={() => document.execCommand("insertText", false, `<${value}>`)}>
																{value}
															</button>
														))
													}
												</div>
												<ReactQuill
													placeholder="Subject"
													defaultValue={subject}
													onChange={html => {setIsEditing(true); setSubject(html.slice(3, -4).replace("<br>", ""))}}
													modules={{toolbar: false}}
													theme="snow"
												/>
												<ReactQuill
													className="w-full mb-7"
													placeholder="Body"
													defaultValue={html}
													onChange={html => {setIsEditing(true); setHtml(html)}}
													onChangeSelection={(_, __, newEditor) => {if(!editor) setEditor(newEditor)}}
													theme="snow"
													modules={{toolbar: {container: "#toolbar"}}}
													formats={["header", "bold", "italic", "underline", "link", "image", "list", "align", "strike"]}
												/>
											</div>
										</TableCell>
										<TableCell>
											<Button
												variant="contained"
												color="primary"
												sx={{color: "white"}}
												disabled={!isEditing}
												onClick={async () => {
													await makeApiRequest("/api/editEmailTemplate", {id: defaultValue.id, subject, html})
														.catch(error => toast.error(error.message))
													setIsEditing(false)
												}}
											>
												Submit
											</Button>
										</TableCell>
									</TableRow>
								</TableBody>
							</Table>
						</Box>
					</Collapse>
				</TableCell>
			</TableRow>
		</>
	)
}
export default function EmailTemplatesTable() {
	const [emailTemplates, setEmailTemplates] = useState([])
	const [total, setTotal] = useState(0)
	const [page, setPage] = useState(0)
	const [size, setSize]= useState(10)
	const [isLoading, setIsLoading] = useState(true)
	async function handleDataFetch() {
		setIsLoading(true)
		const {total, emailTemplates} = await makeApiRequest("/api/getEmailTemplates", {page, size})
			.catch(e => toast.error(e.message))
		setTotal(total)
		setEmailTemplates(emailTemplates)
		setIsLoading(false)
	}
	useEffect(() => {handleDataFetch()}, [page, size])
	return (
		<ThemeProvider theme={theme}>
			<Box sx={styles.mainBox}>
				<Box sx={styles.headerBox}>
					<Typography color="primary" variant="h2" sx={styles.title}>Email templates</Typography>
				</Box>
				<Box>
					<TableContainer>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell />
									<TableCell>Type</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{
									isLoading ? (
										<TableRow>
											<TableCell colSpan={7} align="center">
												<CircularProgress />
											</TableCell>
										</TableRow>
									)
									: emailTemplates.map(template => (
										<Row
											defaultValue={template}
											onDelete={handleDataFetch}
											key={template.id}
										/>
									))
								}
							</TableBody>
						</Table>
					</TableContainer>
					<TablePagination
						count={total}
						rowsPerPage={size}
						page={page}
						onPageChange={(_, newPage) => setPage(newPage)}
						onRowsPerPageChange={(event) => {setSize(event.target.value); setPage(0)}}
						component="div"
						rowsPerPageOptions={[10, 20, 30, 40]}
					/>
				</Box>
			</Box>
		</ThemeProvider>
	)
}