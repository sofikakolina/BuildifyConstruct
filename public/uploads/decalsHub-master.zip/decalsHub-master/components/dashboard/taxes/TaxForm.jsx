import Joi from "joi-browser"
import {TableRow, TableCell, IconButton, TextField, Button} from "@mui/material"
import CloseIcon from '@mui/icons-material/Close'
import {useState} from "react"
import toast from "react-hot-toast"
const validationSchema = Joi.object({
	name: Joi.string().max(50).required(),
	rate: Joi.number().greater(0).required()
})
export default function TaxForm({onSubmit, onCancel, defaultValue, makeApiRequest}) {
	const [form, setForm] = useState(defaultValue ? defaultValue : {})
	const [errors, setErrors] = useState({})
	const handleFormChange = (event) => setForm(form => ({...form, [event.target.name]: (() => {
		const value = event.target.value.trim()
		const number = Number(value)
		if(!isNaN(number)) return number
		return value
	})()}))
	async function handleSubmit() {
		try {
			const {error, value} = validationSchema.validate(form, {abortEarly: false, stripUnknown: true})
			if(error) {setErrors(error.details.reduce((newErrors, detail) => ({...newErrors, [detail.path[0]]: detail.message}), {})); return}
			const response = await makeApiRequest(value)
			onSubmit(response ? response.tax: value)
		}
		catch(e) {toast.error(e.message)}
	}
	return (
		<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
			<TableCell>
				<IconButton size="small" onClick={onCancel}>
					<CloseIcon />
				</IconButton>
			</TableCell>
			<TableCell>
				<TextField
					margin="normal"
					label="Name"
					variant="outlined"
					name="name"
					error={Boolean(errors.name)}
					helperText={errors.name}
					onChange={handleFormChange}
					defaultValue={form.name}
				/>
			</TableCell>
			<TableCell>
				<TextField
					type="number"
					margin="normal"
					label="Rate"
					variant="outlined"
					name="rate"
					error={Boolean(errors.rate)}
					helperText={errors.rate}
					onChange={handleFormChange}
					defaultValue={form.rate}
				/>
			</TableCell>
			<TableCell>
				<Button type="button" onClick={handleSubmit} variant="contained" color="primary" sx={{color: 'white'}}>
					Save
				</Button>
			</TableCell>
		</TableRow>
	)
}