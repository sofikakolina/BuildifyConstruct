"use client"
import React, {useEffect, useState} from "react"
import theme from "@/theme"
import {Button, ThemeProvider, CircularProgress, Box, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Typography} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import EditIcon from "@mui/icons-material/Edit"
import DeleteIcon from "@mui/icons-material/Delete"
import makeApiRequest from "@/libs/makeApiRequest"
import TaxForm from "./TaxForm"
import toast from "react-hot-toast"
const styles = {
	mainBox: {display: "flex", flexDirection: "column", gap: "32px", py: "2rem"},
	headerBox: {display: "flex", justifyContent: "space-between"},
	title: {fontSize: "48px", fontWeight: "medium"},
	addButton: {color: "white", px: 3, py: 1, fontSize: '0.9rem'}
}
function Row({defaultValue, index, onDelete}) {
	const [isOpen, setIsOpen] = useState(false)
	const [isEditing, setIsEditing] = useState(false)
	const [tax, setTax] = useState(defaultValue)
	const handleSubmit = response => {setTax({...tax, ...response}); setIsEditing(false)}
	async function handleDelete() {
		await makeApiRequest("/api/deleteTax", {id: tax.id}).catch(e => console.log(e.message))
		onDelete(index)
	}
	return (
		<>
			{
				isEditing ? (
					<TaxForm
						onSubmit={handleSubmit} 
						onCancel={() => setIsEditing(false)}
						defaultValue={tax} 
						makeApiRequest={body => makeApiRequest("/api/editTax", {...body, id: tax.id})}
					/>
				) : tax ? (
					<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
						<TableCell />
						<TableCell>{tax.name}</TableCell>
						<TableCell>{tax.rate}</TableCell>
						<TableCell>
							<IconButton onClick={handleDelete}><DeleteIcon /></IconButton>
							<IconButton onClick={() => setIsEditing(true)}><EditIcon /></IconButton>
						</TableCell>
					</TableRow>
				) : (
					<TaxForm
						onSubmit={handleSubmit}
						onCancel={() => onDelete(index)}
						makeApiRequest={(body) => makeApiRequest("/api/createTax", body)}
					/>
				)
			}
		</>
	)
}
export default function TaxesTable() {
	const [taxes, setTaxes] = useState([])
	const [createdTaxes, setCreatedTaxes] = useState([])
	const [total, setTotal] = useState(0)
	const [page, setPage] = useState(0)
	const [size, setSize]= useState(10)
	const [isLoading, setIsLoading] = useState(true)
	async function handleDataFetch() {
		setIsLoading(true)
		const {total: newTotal, taxes: newTaxes} = await makeApiRequest("/api/getTaxes", {page, size})
			.catch(e => toast.error(e.message))
		setTotal(newTotal)
		setTaxes(newTaxes)
		setIsLoading(false)
	}
	useEffect(() => {handleDataFetch()}, [page, size])
	return (
		<ThemeProvider theme={theme}>
			<Box sx={styles.mainBox}>
				<Box sx={styles.headerBox}>
					<Typography color="primary" variant="h2" sx={styles.title}>Taxes</Typography>
					<Button
						sx={styles.addButton}
						color="primary"
						variant="contained"
						startIcon={<AddIcon />}
						onClick={() => setCreatedTaxes(taxes => [taxes.length, ...taxes])}
					>
						Add tax
					</Button>
				</Box>
				<Box>
					<TableContainer>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell />
									<TableCell>Name</TableCell>
									<TableCell>Rate</TableCell>
									<TableCell>Actions</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{createdTaxes.map(index => (
									<Row 
										key={`created-${index}`}
										onDelete={index => setCreatedTaxes(taxes => taxes.filter(taxIndex => taxIndex != index))}
										index={index}
									/>
								))}
								{
									isLoading ? (
										<TableRow>
											<TableCell colSpan={7} align="center">
												<CircularProgress />
											</TableCell>
										</TableRow>
									)
									: taxes.map(tax => (
										<Row
											defaultValue={tax}
											onDelete={handleDataFetch}
											index={tax.id}
											key={tax.id}
										/>
									))
								}
							</TableBody>
						</Table>
					</TableContainer>
					<TablePagination count={total} rowsPerPage={size} page={page} onPageChange={(event, newPage) => setPage(newPage)}
						onRowsPerPageChange={(event) => {setSize(event.target.value); setPage(0)}} component="div" rowsPerPageOptions={[10, 20, 30, 40]}/>
				</Box>
			</Box>
		</ThemeProvider>
	)
}