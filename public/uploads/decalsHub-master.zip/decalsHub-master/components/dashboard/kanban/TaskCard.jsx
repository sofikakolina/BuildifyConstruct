"use client";
import React, { useState, useRef, useEffect, useMemo } from "react";
import {
	Paper,
	Box,
	Typography,
	Button,
	FormControl,
	InputLabel,
	Select,
	MenuItem,
	TextField,
	Popover,
	Avatar,
	Skeleton,
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import ThumbDownAltIcon from "@mui/icons-material/ThumbDownAlt";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import CommentIcon from "@mui/icons-material/Comment";
import VisibilityIcon from "@mui/icons-material/Visibility";
import Link from "next/link";
import dayjs from "dayjs";
import OrderModal from "./OrderModal";
import { OrderPriority } from "@prisma/client";
import makeApiRequest from "@/libs/makeApiRequest";
import toast from "react-hot-toast";
import { useKanban } from "./KanbanContext";

const TaskCard = ({ order, session, staff }) => {
	const { data, updateData } = useKanban();
	const [priority, setPriority] = useState(order.priority || "");
	const [anchorElDate, setAnchorElDate] = useState(null);
	const [openOrderModal, setOpenOrderModal] = useState(false);

	const formatDate = (dateString) => dayjs(dateString).format("ddd, MM/DD");

	const handleChangePriority = async (event) => {
		const newPriority = event.target.value;
		try {
			await makeApiRequest("/api/editOrder", {
				id: order.id,
				priority: newPriority,
			});
			setPriority(newPriority);

			const updatedOrder = { ...order, priority: newPriority };
			const columnIndex = data.columnOrder.findIndex((col) =>
				data.columns[col].orders.some((o) => o.id === order.id)
			);
			const orderIndex = data.columns[
				data.columnOrder[columnIndex]
			].orders.findIndex((o) => o.id === order.id);
			updateData(data.columnOrder[columnIndex], orderIndex, updatedOrder);

			toast.success("Priority updated successfully");
		} catch (error) {
			toast.error(error.message);
		}
	};

	const formattedDate = useMemo(
		() => dayjs(order.payment.dueDate).format("ddd, MM/DD"),
		[order.payment.dueDate]
	);
	const formattedDateCreated = useMemo(
		() => dayjs(order.payment.createdAt).format("ddd, MM/DD"),
		[order.payment.createdAt]
	);

	const handleOpenDatePopover = (event) =>
		setAnchorElDate(event.currentTarget);

	const handleCloseDatePopover = () => setAnchorElDate(null);

	const handleOpenOrderModal = () => setOpenOrderModal(true);
	const handleCloseOrderModal = () => setOpenOrderModal(false);

	const ImageWithSkeleton = ({ src, alt }) => {
		const [imageLoading, setImageLoading] = useState(true);
		const imgRef = useRef();

		useEffect(() => {
			if (imgRef.current && imgRef.current.complete) {
				setImageLoading(false);
			}
		}, [src]);

		return (
			<>
				{imageLoading && (
					<Skeleton variant="rectangular" width="100%" height={175} />
				)}
				<img
					ref={imgRef}
					src={src}
					alt={alt}
					style={{
						display: imageLoading ? "none" : "block",
						maxWidth: "200px",
						padding: "10px",
					}}
					onLoad={() => setImageLoading(false)}
					className="proofingImage rounded"
				/>
			</>
		);
	};

	return (
		<Paper>
			<Box className="orderPreview flex flex-col gap-5">
				{order?.proofs.length > 0 ? (
					<Box className="proofingPreview">
						<a
							onClick={handleOpenOrderModal}
							className="cursor-pointer"
						>
							<figure className="relative flex justify-center">
								{order.proofs.slice(-1).map((i) =>
									i.assets && i.assets.length > 0 ? (
										<ImageWithSkeleton
											key={i.id}
											src={i.assets[0].src}
											alt="Proofing image"
										/>
									) : null
								)}

								<figcaption className="absolute bottom-2 right-2 bg-primary bg-opacity-70 p-1 rounded flex gap-3 items-center">
									<span className="text-white flex gap-1 items-center">
										<CommentIcon
											sx={{ fontSize: "1rem" }}
											className=" text-white"
										/>
										{order.proofs.reduce(
											(sum, proof) =>
												sum + proof.messages.length,
											0
										)}
									</span>
									<span className="text-white flex gap-1 items-center">
										<VisibilityIcon
											sx={{ fontSize: "1rem" }}
											className=" text-white"
										/>
										{order.proofs.reduce(
											(sum, proof) => sum + proof.views,
											0
										)}
									</span>
									{order?.proofs.some(
										(proof) => proof.accepted
									) ? (
										<span>
											<ThumbUpIcon
												sx={{ fontSize: "1rem" }}
												className="text-white"
											/>
										</span>
									) : (
										<span>
											<ThumbDownAltIcon
												sx={{ fontSize: "1rem" }}
												className="text-white"
											/>
										</span>
									)}
								</figcaption>
							</figure>
						</a>
					</Box>
				) : (
					<Box className="proofingPreview">
						<a
							onClick={handleOpenOrderModal}
							className="cursor-pointer"
						>
							<figure className="relative flex justify-center">
								{order.orderItems.length > 0 && (
									<ImageWithSkeleton
										key={order.orderItems[0].id}
										src={order.orderItems[0].image}
										alt="Order item image"
									/>
								)}
							</figure>
						</a>
					</Box>
				)}
				<Box
					sx={{
						mt: 2,
						mx: 2,
						display: "flex",
						justifyContent: "space-between",
						alignItems: "center",
					}}
				>
					<button
						onClick={handleOpenOrderModal}
						className="hover:text-primary hover:underline text-sm font-bold cursor-pointer"
					>
						ORD #{order.id}
					</button>
					<Link
						href={"/dashboard/users/" + order.user.id}
						className="hover:text-primary hover:underline text-sm font-bold"
					>
						{order?.user.company}
					</Link>
					<Typography className="quantity text-sm font-bold bg-primary text-white rounded-md px-2 py-1">
						Qty:{" "}
						{order.orderItems.reduce(
							(sum, item) => sum + item.quantity,
							0
						)}
					</Typography>
				</Box>
				<Box
					className="orderSummary"
					sx={{ display: "flex", flexDirection: "column", gap: 1 }}
				>
					<Box
						sx={{
							mx: 2,
							display: "flex",
							gap: "10px",
							alignItems: "center",
							justifyContent: "space-between",
						}}
					>
						<FormControl sx={{ minWidth: 120 }} size="small">
							<InputLabel id="priority">Priority</InputLabel>
							<Select
								labelId="priority"
								id="priority"
								value={priority}
								label="Priority"
								onChange={handleChangePriority}
							>
								<MenuItem value={OrderPriority.Normal}>
									{OrderPriority.Normal}
								</MenuItem>
								<MenuItem value={OrderPriority.Rush}>
									{OrderPriority.Rush}
								</MenuItem>
							</Select>
						</FormControl>
						<Box
							sx={{
								display: "flex",
								flexDirection: "column",
								gap: "10px",
							}}
						>
							<Typography sx={{ fontSize: "12px" }}>
								Created At: {formattedDateCreated}
							</Typography>
							<Typography
								onClick={handleOpenDatePopover}
								sx={{
									cursor: "pointer",
									textDecoration: "underline",
									fontSize: "12px",
								}}
							>
								Due date: {formattedDate}
							</Typography>
						</Box>
						<Popover
							open={Boolean(anchorElDate)}
							anchorEl={anchorElDate}
							onClose={handleCloseDatePopover}
							anchorOrigin={{
								vertical: "bottom",
								horizontal: "left",
							}}
							transformOrigin={{
								vertical: "top",
								horizontal: "left",
							}}
						>
							<Box sx={{ p: 2 }}>
								<LocalizationProvider
									dateAdapter={AdapterDayjs}
								>
									<DatePicker
										label="Due Date"
										value={dayjs(order.payment.dueDate)}
										onChange={(newValue) => {
											if (newValue) {
												updateData(order.id, newValue);
											}
										}}
										renderInput={(params) => (
											<TextField {...params} />
										)}
									/>
								</LocalizationProvider>
							</Box>
						</Popover>
					</Box>
					<Box
						className="teamPreview bg-[#f5f7f9] rounded-b"
						sx={{
							px: 2,
							py: 3,
							display: "flex",
							alignItems: "center",
							gap: "5px",
						}}
					>
						{order.staffAssignments.length > 0 &&
							order.staffAssignments.map((assignment, index) => (
								<Avatar
									key={assignment.employee.id}
									sx={{ width: "30px", height: "30px" }}
									alt="Team"
									src={assignment.employee.image}
								/>
							))}
					</Box>
				</Box>
			</Box>
			{staff && (
				<OrderModal
					session={session}
					order={order}
					formatDate={formatDate}
					openOrder={openOrderModal}
					priority={priority}
					setPriority={setPriority}
					handleCloseOrder={handleCloseOrderModal}
					staff={staff}
					updateData={updateData}
					data={data}
				/>
			)}
		</Paper>
	);
};

export default TaskCard;
