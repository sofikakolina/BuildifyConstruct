'use client';
import React, { useEffect, useState } from 'react';
import { DragDropContext } from '@hello-pangea/dnd';
import { Box, Button, Typography } from '@mui/material';
import { KanbanProvider, useKanban } from './KanbanContext';
import Column from './Column';
import makeApiRequest from '@/libs/makeApiRequest';
import Link from 'next/link';


const KanbanBoardComponent = ({ session }) => {
  const { data, onDragEnd } = useKanban();
  const totalTasks = data.columnOrder.reduce((acc, columnId) => acc + data.columns[columnId].orders.length, 0);
  const [staff, setStaff] = useState()
  useEffect(() => {makeApiRequest("/api/getStaff").then(({staff}) => setStaff(staff))}, [])
  return (
    <>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', paddingX: '20px' }}>
        <Typography variant='h4' className='flex items-center gap-1'>
          Jobs<span className='text-sm'>({totalTasks})</span>
        </Typography>
        <Link href={"/dashboard/jobs/create"} className='hover:text-primary hover:underline text-sm font-bold'>
          <Button variant="contained" sx={{ color: 'white', backgroundColor: 'primary.main' }}>Add new</Button>
        </Link>
      </Box>
      <Box sx={{ display: 'flex', flexDirection: 'column', height: '100%', overflowY: 'hidden' }}>
        <DragDropContext onDragEnd={onDragEnd}>
          <Box sx={{ display: 'flex', flexGrow: 1, my: 2 }}>
            {data.columnOrder.map(columnId => {
              const column = data.columns[columnId];
              return (
                <Column key={column.id} columnId={column.id} column={column} session={session} staff={staff} />
              );
            })}
          </Box>
        </DragDropContext>
      </Box>
    </>
  );
};


const KanbanBoard = ({ session }) => (
  <KanbanProvider>
    <KanbanBoardComponent session={session} />
  </KanbanProvider>
);

export default KanbanBoard;
