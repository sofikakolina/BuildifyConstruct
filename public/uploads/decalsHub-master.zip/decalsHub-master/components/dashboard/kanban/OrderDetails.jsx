"use client";
import {
	Paper,
	Typography,
	Box,
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableHead,
	TableRow,
	TableFooter,
} from "@mui/material";
import {
	getOrderItemPrice,
	getOrderSubtotal,
	getOrderTax,
} from "@/libs/calculations";
import { useState } from "react";
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";

export default function OrderDetails({ order, userRole }) {
	const [show, setShow] = useState(
		userRole === "Admin" || userRole === "Manager"
	);
	const [isOpen, setIsOpen] = useState(false);
	const [selectedImage, setSelectedImage] = useState("");

	const handleImageClick = (image) => {
		setSelectedImage(image);
		setIsOpen(true);
	};

	return (
		<>
			<Paper elevation={3} sx={{ p: 1, zIndex: "1400" }}>
				<Typography sx={{ fontWeight: "bold", mb: 2 }} variant="body1">
					Order Summary
				</Typography>
				<Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
					<TableContainer component={Paper}>
						<Table>
							<TableHead>
								<TableRow>
									<TableCell>Image</TableCell>
									<TableCell>Details</TableCell>
									<TableCell>Quantity</TableCell>
									<TableCell>
										{show ? "Pricing" : null}
									</TableCell>
								</TableRow>
							</TableHead>
							<TableBody>
								{order.orderItems.map((item, index) => (
									<TableRow key={item.id} index={index}>
										<TableCell>
											<Box>
												<img
													className="object-cover rounded cursor-pointer"
													src={item.image}
													alt={item.name}
													style={{
														maxWidth: "150px",
													}}
													onClick={() =>
														handleImageClick(
															item.image
														)
													} // Open lightbox on click
												/>
											</Box>
										</TableCell>
										<TableCell>
											<Typography variant="h6">
												{item.name}
											</Typography>
											{item.materials.map((m, index) => (
												<Typography
													key={index}
													variant="body1"
													sx={{ fontSize: "14px" }}
												>
													{m.name} (
													{`$${m.cost / 100}`})
												</Typography>
											))}
											<Typography
												variant="body1"
												sx={{ fontSize: "14px" }}
											>
												Size: {item.width}in x{" "}
												{item.height}in
											</Typography>
											<Typography
												variant="h3"
												sx={{ fontSize: "16px" }}
											>
												Comment:
											</Typography>
											<Typography
												variant="body1"
												sx={{ fontSize: "14px" }}
											>
												{item.comment}
											</Typography>
										</TableCell>
										<TableCell>
											<Typography
												variant="body1"
												sx={{ fontSize: "14px" }}
											>
												{item.quantity}
											</Typography>
										</TableCell>
										<TableCell>
											{show ? (
												<Typography
													variant="body1"
													sx={{ fontSize: "16px" }}
												>
													{(getOrderItemPrice(item) *
														item.quantity) /
														100}
													$
												</Typography>
											) : null}
										</TableCell>
									</TableRow>
								))}
							</TableBody>

							<TableFooter>
								{show && (
									<>
										<TableRow>
											<TableCell colSpan={3}>
												<Typography
													variant="body1"
													sx={{ fontSize: "16px" }}
												>
													Subtotal
												</Typography>
											</TableCell>
											<TableCell>
												<Typography
													variant="body1"
													sx={{ fontSize: "16px" }}
												>
													$
													{getOrderSubtotal(order) /
														100}
												</Typography>
											</TableCell>
										</TableRow>
										<TableRow>
											<TableCell colSpan={3}>
												<Typography
													variant="body1"
													sx={{ fontSize: "16px" }}
												>
													Taxes (
													{order.user.tax
														? order.user.tax.rate
														: 0}
													)
												</Typography>
											</TableCell>
											<TableCell>
												<Typography
													variant="body1"
													sx={{ fontSize: "16px" }}
												>
													${getOrderTax(order) / 100}
												</Typography>
											</TableCell>
										</TableRow>
									</>
								)}
								<TableRow>
									<TableCell colSpan={3}>
										<Typography
											variant="body1"
											sx={{ fontSize: "16px" }}
										>
											Shipping
										</Typography>
									</TableCell>
									<TableCell>
										<Typography
											variant="body1"
											sx={{ fontSize: "16px" }}
										>
											{order.invoice.deliveryCost
												? `$${
														order.invoice
															.deliveryCost / 100
												  }`
												: "Pickup"}
										</Typography>
									</TableCell>
								</TableRow>
								{show && (
									<TableRow>
										<TableCell colSpan={3}>
											<Typography
												variant="body1"
												sx={{ fontSize: "16px" }}
											>
												Total
											</Typography>
										</TableCell>
										<TableCell>
											<Typography
												variant="body1"
												sx={{ fontSize: "16px" }}
											>
												${order.payment.amount / 100}
											</Typography>
										</TableCell>
									</TableRow>
								)}
							</TableFooter>
						</Table>
					</TableContainer>
				</Box>

				{/* Lightbox for enlarged image */}
			</Paper>
			{isOpen && (
				<Lightbox
					className="absolute z-[9999]"
					mainSrc={selectedImage}
					onCloseRequest={() => setIsOpen(false)}
				/>
			)}
		</>
	);
}
