'use client';
import { Box, Typography, IconButton, Button, Paper, Divider, Popover, } from '@mui/material';
import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Delete, Download } from '@mui/icons-material';
import { grey } from '@mui/material/colors';
import makeApiRequest from '@/libs/makeApiRequest';
import toast from 'react-hot-toast';
import { useKanban } from './KanbanContext';
import { downloadFile } from "@/libs/download";

export default function Assets({ order }) {
	const [files, setFiles] = useState([]);
	const [openDropzone, setOpenDropzone] = useState(false);
	const [anchorElDropzone, setAnchorElDropzone] = useState(null);
	const [assets, setAssets] = useState(order.assets)
	const [srcs, setSrcs] = useState([])
	const { addAsset, deleteAsset } = useKanban();
	const { getRootProps, getInputProps } = useDropzone({
		accept: { 'image/*': ['.jpeg', '.jpg', '.png'] },
		onDrop: async acceptedFiles => {
			const uploadedFiles = acceptedFiles.map(file => ({
				id: Math.random().toString(36).substr(2, 9),
				preview: URL.createObjectURL(file),
				name: file.name,
				size: file.size
			}));
			setFiles([...files, ...uploadedFiles]);
			setSrcs(
				await Promise.all(acceptedFiles.map(async file => {
					const body = new FormData()
					body.append("file", file)
					return (
						await makeApiRequest("/api/uploadFile", body).catch(error => toast.error(error.message))
					).path
				}))
			)

		}
	});

	const handleClickDropzone = (event) => {
		setAnchorElDropzone(event.currentTarget);
		setOpenDropzone(true);
	};

	const handleCloseDropzone = () => {
		setOpenDropzone(false);
		setAnchorElDropzone(null);
	};

	const handleSaveFiles = async () => {
		const newAssets = await Promise.all(srcs.map(
			async (src, i) => (
				await makeApiRequest(
					"/api/createOrderAsset", { orderId: order.id, src, name: files[i].name }
				).catch(error => toast.error(error.message))
			).orderAsset
		))
		setAssets(prevAssets => [...prevAssets, ...newAssets]);
		newAssets.forEach(asset => addAsset(order.id, asset));
		setFiles([]);
		handleCloseDropzone();
	};


	const handleRemoveAsset = assetId => makeApiRequest("/api/deleteOrderAsset", { id: assetId })
		.then(() => setAssets(prev => prev.filter(asset => asset.id !== assetId)),
			deleteAsset(order.id, assetId))
		.catch(error => toast.error(error.message))

	const handleRemoveFromDropZone = i => {
		setSrcs(prev => {
			const newSrcs = [...prev]
			newSrcs.splice(i, 1)
			return newSrcs
		})
		setFiles(prev => {
			const newFiles = [...prev]
			newFiles.splice(i, 1)
			return newFiles
		})
	}


	const idDropzone = openDropzone ? 'simple-popover' : undefined;

	return (
		<Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
			<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
				<Typography sx={{ fontWeight: 'bold', mb: 2 }} variant='body1'>Assets ({order.assets.length})</Typography>
				<Button size="large" aria-describedby={idDropzone} onClick={handleClickDropzone} sx={{ color: 'white', display: 'flex' }} variant="contained">
					Add new asset
				</Button>
			</Box>
			<Popover
				id={idDropzone}
				open={openDropzone}
				anchorEl={anchorElDropzone}
				onClose={handleCloseDropzone}
				anchorOrigin={{
					vertical: 'bottom',
					horizontal: 'right',
				}}
				transformOrigin={{
					vertical: 'bottom',
					horizontal: 'left',
				}}
			>
				<Box sx={{ p: 2, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
					<div {...getRootProps({ style: { padding: 20, borderRadius: '10px', border: '2px dashed #F69220', width: 250, height: 250, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', cursor: 'pointer' } })}>
						<input {...getInputProps()} />
						<Typography variant='body1' sx={{ textAlign: 'center', fontWeight: 'bold' }}>Drag 'n' drop a file here, or click to select a file</Typography>
					</div>
					{files.map((file, index) => (
						<Box key={index} sx={{ textAlign: 'center' }}>
							<img src={file.preview} alt={file.name} style={{ maxWidth: '100%', maxHeight: '100px', margin: '10px 0' }} />
							<Typography variant="body2">{file.name} - {(file.size / 1024).toFixed(2)} KB</Typography>
							<Button variant="contained" color="error" sx={{ mt: 1, color: 'white' }} onClick={() => handleRemoveFromDropZone(index)}>Remove</Button>
						</Box>
					))}
					<Button sx={{ width: '100%', color: 'white', borderRadius: '8px', mt: 2 }} variant="contained" onClick={handleSaveFiles}>Save</Button>
				</Box>
			</Popover>
			<Paper elevation={2} sx={{ p: 2, display: 'flex', flexDirection: 'column', gap: 1 }}>
				{assets.map((asset, index) => (
					<Box key={asset.id}>
						<Box sx={{ display: 'flex', gap: 2, py: 2 }}>
							<img className='max-h-[100px] rounded' src={asset.src}></img>
							<Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
								<Typography>{asset.name}</Typography>
								<Box sx={{ display: 'flex', gap: 2 }}>
									<IconButton
										aria-label="delete"
										onClick={() => downloadFile(asset.src)}
										sx={{
											borderRadius: '4px',
											backgroundColor: (theme) => theme.palette.primary.main,
											color: 'white',
											transition: 'background-color 0.3s ease, box-shadow 0.3s ease',
											'&:hover': {
												backgroundColor: (theme) => theme.palette.primary.dark,
												boxShadow: '0px 0px 12px rgba(0,0,0,0.3)',
												color: 'white',
											},
										}}
									>
										<Download />
									</IconButton>
									<IconButton
										aria-label="delete"
										onClick={() => handleRemoveAsset(asset.id)}
										sx={{
											borderRadius: '4px',
											backgroundColor: (theme) => theme.palette.primary.main,
											color: 'white',
											transition: 'background-color 0.3s ease, box-shadow 0.3s ease',
											'&:hover': {
												backgroundColor: (theme) => theme.palette.primary.dark,
												boxShadow: '0px 0px 12px rgba(0,0,0,0.3)',
												color: 'white',
											},
										}}
									>
										<Delete />
									</IconButton>
								</Box>
							</Box>
						</Box>
						{index !== order.assets.length - 1 && <Divider />}
					</Box>
				))}
			</Paper>
		</Box>
	);
}