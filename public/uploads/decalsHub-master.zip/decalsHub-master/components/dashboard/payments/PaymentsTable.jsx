"use client"
import React, {useEffect, useState} from "react"
import {CircularProgress, Box, Collapse, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, Typography} from "@mui/material"
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown"
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp"
import { getOrderItemPrice } from "@/libs/calculations"
import toast from "react-hot-toast"
function Row({payment}) {
	const [isOpen, setIsOpen] = useState(false)
	return (
		<React.Fragment>
			<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
				<TableCell>
					<IconButton aria-label="expand row" size="small" onClick={() => setIsOpen(!isOpen)}>
						{isOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
					</IconButton>
				</TableCell>
				<TableCell>{payment.order.user.name}</TableCell>
				<TableCell>{payment.provider}</TableCell>
				<TableCell>{payment.amount / 100}</TableCell>
				<TableCell>{payment.status}</TableCell>
				<TableCell>{payment.createdAt}</TableCell>
				<TableCell>{payment.updatedAt}</TableCell>
			</TableRow>
			<TableRow>
				<TableCell style={{paddingBottom: 0, paddingTop: 0}} colSpan={6}>
					<Collapse in={isOpen} timeout="auto" unmountOnExit>
						<Box sx={{margin: 1}}>
							<Typography variant="h6" gutterBottom component="div">Order</Typography>
							<Table size="small" aria-label="items">
								<TableHead>
									<TableRow>
										<TableCell>image</TableCell>
										<TableCell>name</TableCell>
										<TableCell>width</TableCell>
										<TableCell>height</TableCell>
										<TableCell>quantity</TableCell>
										<TableCell>total price, $</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{payment.order.orderItems?.map(item => (
										<TableRow key={payment.id + item.id}>
											<TableCell>{<img width={150} height={150} alt={item.product.name} src={item.product.image} />}</TableCell>
											<TableCell>{item.product.name}</TableCell>
											<TableCell>{item.width}</TableCell>
											<TableCell>{item.height}</TableCell>
											<TableCell>{item.quantity}</TableCell>
											<TableCell>${getOrderItemPrice(item) * item.quantity / 100}</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</Box>
					</Collapse>
				</TableCell>
			</TableRow>
		</React.Fragment>
	)
}
export default function PaymentsTable() {
	const [payments, setPayments] = useState([])
	const [total, setTotal] = useState(0)
	const [page, setPage] = useState(0)
	const [size, setSize]= useState(10)
	const [isLoading, setIsLoading] = useState(true)
	useEffect(() => {
		(async () => {
			try {
				const {total: newTotal, payments: newPayments} = await fetch("/api/getPayments", {
					headers: {"Content-Type": "application/json"},
					method: "POST",
					credentials: "include",
					body: JSON.stringify({page, size})
				}).then((response) => {
					if(!response.ok) throw new Error("Network response was not okay")
					return response.json()
				})
				setTotal(newTotal)
				setPayments(newPayments)
				setIsLoading(false)
			}
			catch(e) {toast.error(e.message)}
		})()
	}, [page, size])
	return (
		<Box>
			<TableContainer>
				<Typography variant="h4" gutterBottom component="div">Payments</Typography>
				<Table>
					<TableHead>
						<TableRow>
							<TableCell />
							<TableCell>user</TableCell>
							<TableCell>provider</TableCell>
							<TableCell>amount, $</TableCell>
							<TableCell>status</TableCell>
							<TableCell>created at</TableCell>
							<TableCell>updated at</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{isLoading
							? (
								<TableRow>
									<TableCell colSpan={7} align="center">
										<CircularProgress/>
									</TableCell>
								</TableRow>
							)
							: payments.map(payment => <Row payment={payment} key={payment.id}/>)
						}
					</TableBody>
				</Table>
			</TableContainer>
			<TablePagination count={total} rowsPerPage={size} page={page} onPageChange={(event, newPage) => setPage(newPage)}
				onRowsPerPageChange={(event) => {setSize(event.target.value); setPage(0)}} component="div" rowsPerPageOptions={[10, 20, 30, 40]}/>
		</Box>
	)
}