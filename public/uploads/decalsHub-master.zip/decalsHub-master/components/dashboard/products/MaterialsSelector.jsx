import React, {useState, useEffect} from "react"
import {Checkbox, FormControlLabel, FormGroup, Box, Typography, Accordion, AccordionSummary, AccordionDetails, CircularProgress} from "@mui/material"
import ExpandMoreIcon from "@mui/icons-material/ExpandMore"
import makeApiRequest from "@/libs/makeApiRequest"
export default function MaterialsSelector({materials, setMaterials}) {
	const [categories, setCategories] = useState([])
	const [isLoading, setLoading] = useState(true)
	useEffect(() => {
		(async () => {
			setLoading(true)
			await makeApiRequest("/api/getMaterialsCategories", {})
				.then(({materialsCategories}) => setCategories(materialsCategories))
			setLoading(false)
		})()
	}, [])

	return (
		<Box sx={{mt: 2}}>
			{isLoading ? (
				<CircularProgress />
			) : (
				categories.map(category => (
					<Accordion key={category.id}>
						<AccordionSummary
							expandIcon={<ExpandMoreIcon />}
							aria-controls={`panel${category.id}-content`}
							id={`panel${category.id}-header`}
						>
							<Typography>{category.name}</Typography>
						</AccordionSummary>
						<AccordionDetails>
							<FormGroup>
								{category.materials.length > 0 ? (
									category.materials.map(material => (
										<FormControlLabel
											key={material.id}
											control={
												<Checkbox
													checked={materials.some(m => m.id == material.id) || false}
													onChange={() => setMaterials(materials => {
														const newMaterials = [...materials]
														const index = materials.findIndex(m => m.id == material.id)
														if(index >= 0) newMaterials.splice(index, 1)
														else newMaterials.push(material)
														return newMaterials
													})}
													color="primary"
												/>
											}
											label={`${material.name} - Cost: $${material.cost / 100}, Markup: ${material.markup}x, Price: $${material.cost * material.markup / 100}`}
										/>
									))
								) : (
									<Typography>No materials available</Typography>
								)}
							</FormGroup>
						</AccordionDetails>
					</Accordion>
				))
			)}
		</Box>
	)
}