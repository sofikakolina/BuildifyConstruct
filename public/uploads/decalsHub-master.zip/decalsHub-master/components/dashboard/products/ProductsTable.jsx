"use client"
import {useState, useEffect} from "react"
import React from "react"
import {TextField, IconButton, Collapse, Box, Typography, Button, CircularProgress, TablePagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow} from "@mui/material"
import EditIcon from "@mui/icons-material/Edit"
import AddIcon from "@mui/icons-material/Add"
import DeleteIcon from "@mui/icons-material/Delete"
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown"
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp"
import Link from "next/link"
import makeApiRequest from "@/libs/makeApiRequest"
import Image from "next/image"
import {getProductPrice} from "@/libs/calculations"
import toast from "react-hot-toast"
import Lightbox from "react-image-lightbox";
import "react-image-lightbox/style.css";

const styles = {
	mainBox: { display: "flex", flexDirection: "column", gap: "32px", py: "2rem" },
	headerBox: { display: "flex", justifyContent: "space-between" },
	title: { fontSize: "48px", fontWeight: "medium" },
	addButton: { color: "white", px: 3, py: 1, fontSize: '0.9rem' }
}
function Row({ product, onDelete }) {
	const [isOpen, setIsOpen] = useState(false);
	const [isLightboxOpen, setIsLightboxOpen] = useState(false);
	const [lightboxImage, setLightboxImage] = useState("");
  
	return (
	  <>
		<TableRow sx={{ "& > *": { borderBottom: "unset" } }}>
		  <TableCell>
			<IconButton aria-label="expand row" size="small" onClick={() => setIsOpen(!isOpen)}>
			  {isOpen ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
			</IconButton>
		  </TableCell>
		  <TableCell>
			<button
			  type="button"
			  onClick={() => {
				setLightboxImage(product.image);
				setIsLightboxOpen(true);
			  }}
			>
			  <Image
				className="w-auto max-w-[200px] h-auto cursor-pointer"
				quality={80}
				loading="lazy"
				width={150}
				height={150}
				src={product.image}
				alt={product.name}
			  />
			</button>
		  </TableCell>
		  <TableCell>{product.name}</TableCell>
		  <TableCell>{product.width}″</TableCell>
		  <TableCell>{product.height}″</TableCell>
		  <TableCell>${getProductPrice(product) / 100}</TableCell>
		  <TableCell>
			<Link href={`/dashboard/products/${product.id}`}>
			  <IconButton aria-label="edit">
				<EditIcon />
			  </IconButton>
			</Link>
			<IconButton onClick={() => onDelete(product.id)} aria-label="delete">
			  <DeleteIcon />
			</IconButton>
		  </TableCell>
		</TableRow>
		<TableRow>
		  <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
			<Collapse in={isOpen} timeout="auto" unmountOnExit>
			  <Box sx={{ margin: 1 }}>
				<Typography variant="h6" gutterBottom component="div">
				  Materials
				</Typography>
				<Table size="small" aria-label="items">
				  <TableHead>
					<TableRow>
					  <TableCell>Name</TableCell>
					  <TableCell>Cost</TableCell>
					  <TableCell>Markup</TableCell>
					  <TableCell>Price per sqft</TableCell>
					</TableRow>
				  </TableHead>
				  <TableBody>
					{product.productMaterials.map((l) => (
					  <TableRow key={product.id + l.id}>
						<TableCell>{l.material.name}</TableCell>
						<TableCell>{l.material.cost / 100}</TableCell>
						<TableCell>{l.material.markup}</TableCell>
						<TableCell>{(l.material.markup * l.material.cost) / 100}</TableCell>
					  </TableRow>
					))}
				  </TableBody>
				</Table>
			  </Box>
			</Collapse>
		  </TableCell>
		</TableRow>
  
		{/* Lightbox */}
		{isLightboxOpen && (
		  <Lightbox
			mainSrc={lightboxImage}
			onCloseRequest={() => setIsLightboxOpen(false)}
		  />
		)}
	  </>
	);
  }
  
export default function ProductsTable({userId}) {
	const [products, setProducts] = useState([])
	const [allProducts, setAllProducts] = useState([])
	const [total, setTotal] = useState(0)
	const [search, setSearch] = useState("")
	const [isLoading, setIsLoading] = useState(true)
	const [page, setPage] = useState(0)
	const [size, setSize] = useState(10)
	async function handleFetch() {
		try {
			const requestData =search ? userId ? { userId, page:0, size:Number.MAX_SAFE_INTEGER } : { page:0, size:Number.MAX_SAFE_INTEGER } : userId ? { userId, page, size } : { page, size };
			const { total: newTotal, products: newProducts } = await makeApiRequest("/api/getProducts", requestData);
			if (search) {
				const startIndex = page * size ;
				const endIndex = startIndex + size;
				const result = newProducts.filter(product => ((product.name).toLowerCase()).includes(search.toLowerCase()));
				const paginatedResult = result.slice(startIndex, endIndex);
				setTotal(result.length);
				setProducts(paginatedResult);
				setIsLoading(false);
			}
			else{
				setTotal(newTotal)
				setProducts(newProducts)
				setIsLoading(false)
			}
		} catch(e) {toast.error(e.message)}
	}
	useEffect(() => {handleFetch()}, [size, page, search])
	async function handleDelete(id) {
		try {
			const response = await makeApiRequest("/api/deleteProduct", {id})
			if(response?.warning) toast(response.warning, {icon: "⚠️"})
			handleFetch()
		} catch (error) {toast.error(error.message)}
	}
	return (
		<Box>
			<TableContainer>
				<Box sx={styles.headerBox}>
					{userId? <Typography color="primary" variant="h4">All products</Typography> :
					<Typography color="primary" variant="h2" sx={styles.title}>Products</Typography>}
					{userId? null :
					<Link href="/dashboard/products/create">
						<Button
							sx={styles.addButton}
							color="primary"
							variant="contained"
							startIcon={<AddIcon />}
						>
							Add Product
						</Button>
					</Link>}
				</Box>
				<Box sx={{ display: "flex", gap: '10px', alignItems: 'center' }}>
					{/* <FormControl sx={{maxWidth: '300px', width: '100%'}}>
						<InputLabel id="label-filter">Sort</InputLabel>
						<Select
							labelId="select-filter-label"
							id="select-filter-label"
							value={JSON.stringify(sort)}
							label="Sort"
							sx={{width: '100%'}}
							onChange={event => setSort(JSON.parse(event.target.value))}
						>
							<MenuItem value={JSON.stringify({createdAt: "desc"})}>Date</MenuItem>
							<MenuItem value={JSON.stringify({company: "asc"})}>A-Z</MenuItem>
							<MenuItem value={JSON.stringify({company: "desc"})}>Z-A</MenuItem>
						</Select>
					</FormControl> */}

					<TextField
						sx={{ width: '100%' }}
						label="Search"
						onChange={event => setSearch(() => {
							setPage(0)
							return event.target.value
						})}
					/>
				</Box>
				<Table>
					<TableHead>
						<TableRow>
							<TableCell />
							<TableCell>Image</TableCell>
							<TableCell>Name</TableCell>
							<TableCell>Width</TableCell>
							<TableCell>Height</TableCell>
							<TableCell>Price</TableCell>
							<TableCell>Actions</TableCell>
						</TableRow>
					</TableHead>
					<TableBody>
						{isLoading
							? (
								<TableRow>
									<TableCell colSpan={7} align="center">
										<CircularProgress/>
									</TableCell>
								</TableRow>
							)
							: products.map((product) => <Row product={product} key={product.id} onDelete={handleDelete} />)
						}
					</TableBody>
				</Table>
			</TableContainer>
			<TablePagination count={total} rowsPerPage={size} page={page} onPageChange={(event, newPage) => setPage(newPage)}
				onRowsPerPageChange={(event) => {setSize(event.target.value); setPage(0)}} component="div" rowsPerPageOptions={[10, 20, 30, 40]}/>
		</Box>
	)
}
