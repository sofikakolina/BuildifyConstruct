'use client'
import { useState } from 'react';
import Image from 'next/image';
import { TableCell, TableRow, IconButton, InputLabel, MenuItem } from '@mui/material';
import Button from '@mui/material/Button';
import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

import Box from '@mui/material/Box';
import TextField from '@mui/material/TextField';
import * as React from 'react';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';

export default function ProductInfoMain({ product, onDelete }) {
  const [isOpen, setIsOpen] = useState(false);

  const [id, setId] = useState(product.id);
  const [name, setName] = useState(product.name);
  const [taxable, setTaxable] = useState(product.taxable);
  const [jobComplexity, setJobComplexity] = useState(product.jobComplexity);
  const [image, setImage] = useState(product.image);
  const [description, setDescription] = useState(product.description);

  const toggleOpen = () => {
    setIsOpen(!isOpen);
  };

  const updateProduct = async () => {
    try {
      const response = await fetch("/api/editProduct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ id, name, taxable, jobComplexity, image, description })
      });

      if (!response.ok) {
        throw new Error("Network response was not okay");
      }

      // Обновите данные продукта в соответствии с изменениями
      // Например, если у вас есть массив products:

      return response.json();
    } catch (error) {
      console.error("Error:", error);
    }
  }



  const deleteProduct = async () => {
    fetch("/api/deleteProduct", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ id })
    }).then((response) => {
      if (!response.ok) throw new Error("Network response was not okay")
      return response.json()
    }).catch((error) => console.error("Error:", error))

    onDelete(id);
  }




  return (
    <>
      <TableRow
        key={product.name}
        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
      >
        <TableCell
          align="left"
          onClick={toggleOpen}
          sx={{
            borderLeft: isOpen ? '4px solid #F69220' : 'none', // Добавляем полоску слева при isOpen
          }}
        >
          <IconButton aria-label="delete">
            {isOpen ? <KeyboardArrowDownIcon /> : <KeyboardArrowRightIcon />}
          </IconButton>
        </TableCell>
        <TableCell align="left">{product.id}</TableCell>
        <TableCell
          component="th"
          scope="row"
          sx={{ alignItems: 'center' }}
        >
          <Image
            src={product.image}
            alt={product.name}
            width={80}
            height={80}
            className="rounded-lg"
          />
        </TableCell>
        <TableCell align="left">{product.name}</TableCell>
        <TableCell align="left">{product.description}</TableCell>
        <TableCell align="left">{product.jobComplexity}</TableCell>
        <TableCell align="left">{product.taxable ? 'True' : 'False'}</TableCell>
        <TableCell align="left">
          <IconButton
            size="large"
            aria-label="show more"
            aria-haspopup="true"
            color="inherit"
          >
            <MoreHorizIcon />
          </IconButton>
        </TableCell>
      </TableRow>
      {isOpen && (
        <TableRow
          sx={{
            borderLeft: isOpen ? '4px solid #F69220' : 'none', // Добавляем полоску слева при isOpen
          }}
        >
          <TableCell colSpan={7}>
            <Box
              component="form"
              sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch' },
              }}
              noValidate
              autoComplete="off"
            >
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="ID"
                  defaultValue={id}
                  onChange={(event) => { setId(event.target.value) }}
                />
                <TextField
                  required
                  id="outlined-required"
                  label="Name"
                  defaultValue={name}
                  onChange={(event) => { setName(event.target.value) }}
                />
                <TextField
                  required
                  id="outlined-required"
                  label="Description"
                  defaultValue={description}
                  onChange={(event) => { setDescription(event.target.value) }}
                />
                <TextField
                  required
                  id="outlined-required"
                  label="Job Complexity"
                  defaultValue={jobComplexity}
                  onChange={(event) => { setJobComplexity(event.target.value) }}
                />


                <FormControl sx={{ margin: '8px' }}>
                  <InputLabel id="demo-simple-select-label">Age</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={taxable}
                    label="Taxable"
                    onChange={(event) => { setTaxable(event.target.value) }}
                  >
                    <MenuItem value={true}>True</MenuItem>
                    <MenuItem value={false}>False</MenuItem>
                  </Select>
                </FormControl>


              </div>
            </Box>
          </TableCell>
        </TableRow>
      )}
      {isOpen && (
        <TableRow
          sx={{
            borderLeft: isOpen ? '4px solid #F69220' : 'none', // Добавляем полоску слева при isOpen
          }}
        >
          <TableCell colSpan={7}>
            <Box
              component="form"
              sx={{
                '& .MuiTextField-root': { m: 1, width: '25ch', },
              }}
              noValidate
              autoComplete="off"
            >
              <div className='flex justify-between'>
                <div className='flex gap-3'>
                  <Button variant="contained" onClick={updateProduct}>Update</Button>
                  <Button onClick={toggleOpen}>Cancel</Button>
                </div>
                <div>
                  <Button sx={{ color: 'red' }} onClick={deleteProduct}>Delete product</Button>
                </div>
              </div>

            </Box>
          </TableCell>
        </TableRow>
      )}
    </>
  );
}

