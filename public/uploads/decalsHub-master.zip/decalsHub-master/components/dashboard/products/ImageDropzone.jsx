import React, { useState, useCallback, useEffect } from "react"
import { useDropzone } from "react-dropzone"
import { Box, Avatar, Typography, CircularProgress } from "@mui/material"
import makeApiRequest from "@/libs/makeApiRequest"
export default function ImageDropzone({ onDrop, image, errors, red }) {
	const [isLoading, setIsLoading] = useState(false)
	const [error, setError] = useState(errors)
	const [thumbnail, setThumbnail] = useState(image)
	const [fileName, setFileName] = useState(image?.substring(image.lastIndexOf('/') + 1))
	useEffect(() => {setError(errors)}, [errors])
	const onDropCallback = useCallback(async (acceptedFiles) => {
		setIsLoading(true)
		const file = acceptedFiles[0]
		if (!file) {
			setIsLoading(false)
			return
		}

		setFileName(file.name)

		setThumbnail(URL.createObjectURL(file))
		const data = new FormData()
		data.append("file", file)

		try {
			const { path } = await makeApiRequest("/api/uploadFile", data)
			onDrop(path)
			setIsLoading(false)
		}
		catch (uploadError) {setError("An error occurred during file upload.")}
	}, [onDrop])

	const { getRootProps, getInputProps } = useDropzone({
		onDrop: onDropCallback,
		accept: { "image/*": [".jpeg", ".jpg", ".png"] },
		maxFiles: 1
	})

	return (
		<Box>
			<Box {...getRootProps({ className: "dropzone" })} sx={{
				p: 2,
				display: 'flex',
				alignItems: 'center',
				justifyContent: 'center',
				border: '2px dashed',
				borderColor: error ? 'error.main' : 'primary.light',
				borderRadius: 2,
				bgcolor: error ? red[100] : 'background.paper',
				textAlign: 'center',
				cursor: 'pointer',
				minHeight: '200px'
			}}>
				<input {...getInputProps()} />

				{!thumbnail && !isLoading && (
					<Typography sx={{ fontWeight: 'bold', color: error ? red[500] : 'primary.light' }}>
						Drag 'n' drop a photo here, or click to select a photo
					</Typography>
				)}

				{thumbnail && !isLoading && (
					<Box>
						<Avatar
							src={thumbnail}
							alt="Preview"
							sx={{ width: '150px', height: '150px', margin: '0 auto' }}
						/>

						<Typography variant="body2" sx={{ mt: 1 }}>
							{fileName}
						</Typography>
					</Box>
				)}



				{isLoading && <CircularProgress />}
			</Box>
			{error && (
				<Typography variant="caption" sx={{ color: 'error.main', mt: 2 }}>{error}</Typography>
			)}
		</Box>
	)
}