'use client'
import React, { useState } from 'react';
import {
  Modal,
  Box,
  Typography,
  TextField,
  Button,
} from '@mui/material';

const PhoneModal = ({ open, handleClose, handleSave }) => {
  const [phone, setPhone] = useState({
    phoneType: '',
    number: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPhone({ ...phone, [name]: value });
  };

  const savePhone = () => {
    handleSave(phone);
    setPhone({ phoneType: '', number: '' });
    handleClose();
  };

  return (
    <Modal open={open} onClose={handleClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 400,
          bgcolor: 'background.paper',
          boxShadow: 24,
          p: 4,
          outline: 'none',
        }}
      >
        <Typography variant="h6">Add New Phone</Typography>
        <TextField
          fullWidth
          label="Phone Type"
          name="phoneType"
          value={phone.phoneType}
          onChange={handleChange}
          margin="dense"
        />
        <TextField
          fullWidth
          label="Number"
          name="number"
          value={phone.number}
          onChange={handleChange}
          margin="dense"
        />
        <Button onClick={savePhone} color="primary" variant="contained" sx={{ mt: 2 }}>
          Save Phone
        </Button>
      </Box>
    </Modal>
  );
};

export default PhoneModal;
