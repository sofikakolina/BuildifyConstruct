'use client'
import React, { useState } from 'react';
import { signOut } from 'next-auth/react';
import { AppBar, Toolbar, IconButton, Typography, Menu, MenuItem, Divider, Box, ListItemIcon, Avatar } from '@mui/material';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import SettingsRoundedIcon from '@mui/icons-material/SettingsRounded';
import CreditCardRoundedIcon from '@mui/icons-material/CreditCardRounded';

const DashboardHeader = ({session}) => {
    const [anchorEl, setAnchorEl] = useState(null);
    const isMenuOpen = Boolean(anchorEl);

    const menuItems = [
        { title: 'Profile', icon: <PersonOutlineOutlinedIcon />, onClick: () => console.log('Profile clicked') },
        { title: 'Settings', icon: <SettingsRoundedIcon />, onClick: () => console.log('Settings clicked') },
        { title: 'Billing', icon: <CreditCardRoundedIcon />, onClick: () => console.log('Billing clicked') },
    ];

    const handleProfileMenuOpen = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleMenuClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = async () => {
      try {
          await signOut({ callbackUrl: '/auth/login', redirect: false });
          window.location.href = '/auth/login';
      } catch (error) {
          console.error('Ошибка при выходе:', error);
      }
  };
  

    const menuId = 'primary-search-account-menu';
    const renderMenu = (
        <Menu
            anchorEl={anchorEl}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            id={menuId}
            keepMounted
            open={isMenuOpen}
            onClose={handleMenuClose}
            slotProps={{
                paper: {
                    style: {
                        backgroundColor: 'white',
                        color: 'black',
                        borderRadius: '10px',
                        width: '200px',
                    },
                },
            }}
        >
            <Box px={2} py={1}>
                <Typography variant="subtitle1" noWrap>
                    {session?.user?.name || 'Username'}
                </Typography>
                <Typography variant="caption" noWrap style={{ color: 'grey' }}>
                    {session?.user?.email || 'user@example.com'}
                </Typography>
            </Box>
            <Divider />
            {menuItems.map((item) => (
                <MenuItem key={item.title} onClick={item.onClick}>
                    <ListItemIcon>
                        {item.icon}
                    </ListItemIcon>
                    <Typography variant="body2">
                        {item.title}
                    </Typography>
                </MenuItem>
            ))}
            <Divider />
            <MenuItem onClick={handleLogout}>
                <Typography variant="body2" align="center" width={'100%'}>
                    Logout
                </Typography>
            </MenuItem>
        </Menu>
    );

    return (
        <AppBar position="static" style={{ background: 'white', borderRadius: '10px' }}>
            <Toolbar style={{ justifyContent: 'flex-end' }}>
                <IconButton color="inherit">
                    <NotificationsIcon />
                </IconButton>
                <IconButton
                    edge="end"
                    aria-label="account of current user"
                    aria-controls={menuId}
                    aria-haspopup="true"
                    onClick={handleProfileMenuOpen}
                    color="inherit"
                >
                    <Avatar src={session?.user?.image} alt={session?.user?.name || 'U'}>
                        {!session?.user?.image && (session?.user?.name?.charAt(0) || 'U')}
                    </Avatar>
                </IconButton>
            </Toolbar>
            {renderMenu}
        </AppBar>
    );
};

export default DashboardHeader;

