"use client";
import React, { useState, useEffect } from "react";
import {
    Drawer,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    Collapse,
    Box,
    Divider,
    ButtonBase,
    Badge,
} from "@mui/material";
import Image from "next/image";
import Logo from "@/public/assets/logo.svg";
import { menuItems } from "./items";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import theme from "@/theme";
import { getRequestedProductRequestsCount } from "@/app/actions/productRequest";
import { usePathname, useRouter } from 'next/navigation';

const drawerWidth = 280;

const Sidebar = ({ session }) => {
    const [open, setOpen] = useState({});
    const [requestCount, setRequestCount] = useState(0); // Состояние для количества запросов
    const pathname = usePathname();
    const router = useRouter();

    useEffect(() => {
        async function fetchRequestCount() {
            const count = await getRequestedProductRequestsCount();
            setRequestCount(count);
        }
        fetchRequestCount();
    }, []);

    const handleMenuClick = (menu) => {
        setOpen((prevOpen) => ({ ...prevOpen, [menu]: !prevOpen[menu] }));
    };

    const navigateTo = (path) => {
        router.push(path);
    };

    const isMenuOpen = (menu) => Boolean(open[menu]);

    const getButtonStyle = (path) => ({
        width: "100%",
        justifyContent: "flex-start",
        backgroundColor: pathname === path ? "#F69220" : "",
        borderRadius: "10px",
    });

    const renderSubMenuItems = (subMenu, paddingLeft) =>
        subMenu.map((item) => (
            <ButtonBase
                sx={{ my: "2px" }}
                onClick={() => navigateTo(item.path)}
                key={item.text}
                style={getButtonStyle(item.path)}
            >
                <ListItem sx={{ pl: paddingLeft }}>
                    <ListItemIcon style={{ color: "white" }}>
                        {item.icon}
                    </ListItemIcon>
                    <ListItemText primary={item.text} />
                </ListItem>
            </ButtonBase>
        ));

    const renderMenuItems = () =>
        menuItems(session).map((item) => (
            <React.Fragment key={item.text}>
                <ButtonBase
                    sx={{ my: "2px" }}
                    onClick={() =>
                        item.subMenu ? handleMenuClick(item.text) : navigateTo(item.path)
                    }
                    style={getButtonStyle(item.path)}
                >
                    <ListItem>
                        <ListItemIcon style={{ color: "white" }}>
                            {item.text === "Products requests" ? (
                                <Badge
                                    badgeContent={requestCount}
                                    color="error"
                                    overlap="circular"
                                >
                                    {item.icon}
                                </Badge>
                            ) : (
                                item.icon
                            )}
                        </ListItemIcon>
                        <ListItemText primary={item.text} />
                        {item.subMenu &&
                            (isMenuOpen(item.text) ? (
                                <ExpandLessIcon style={{ color: "white" }} />
                            ) : (
                                <ExpandMoreIcon style={{ color: "white" }} />
                            ))}
                    </ListItem>
                </ButtonBase>
                {item.subMenu && (
                    <Collapse in={isMenuOpen(item.text)} timeout="auto" unmountOnExit>
                        <List component="div" disablePadding>
                            {renderSubMenuItems(item.subMenu, 4)}
                        </List>
                    </Collapse>
                )}
            </React.Fragment>
        ));

    return (
        <Drawer
            sx={{
                width: drawerWidth,
                flexShrink: 0,
                "& .MuiDrawer-paper": {
                    width: drawerWidth,
                    boxSizing: "border-box",
                    backgroundColor: theme.customColors.drawerBackground,
                    color: theme.customColors.drawerTextColor,
                },
                "& .MuiButtonBase-root:hover": {
                    backgroundColor: theme.customColors.hoverBackground,
                    transition: "background-color 0.3s ease",
                    borderRadius: theme.customRadius.buttonMedium,
                },
                "& .MuiListItem-root": {
                    transition: "background-color 0.3s ease",
                },
                "& .MuiCollapse-container": {
                    transition: "height 0.3s ease",
                },
            }}
            variant="permanent"
            anchor="left"
        >
            <Box
                sx={{ p: 4, display: "flex", flexDirection: "column", alignItems: "center" }}
            >
                <Image priority src={Logo} height={29} width={207} alt="Logo" />
            </Box>
            <Divider />
            <List>{renderMenuItems()}</List>
            <Divider />
        </Drawer>
    );
};

export default Sidebar;
