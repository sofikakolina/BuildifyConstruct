// menuItems.js
import DashboardIcon from "@mui/icons-material/Dashboard";
import PeopleIcon from "@mui/icons-material/People";
import LocalMallIcon from "@mui/icons-material/LocalMall";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import ConstructionIcon from "@mui/icons-material/Construction";
import PaymentsIcon from "@mui/icons-material/Payments";
import PaidIcon from "@mui/icons-material/Paid";
import CreditScoreIcon from "@mui/icons-material/CreditScore";
import ProductionQuantityLimitsIcon from "@mui/icons-material/ProductionQuantityLimits";
import ViewKanbanIcon from "@mui/icons-material/ViewKanban";
import EmailIcon from "@mui/icons-material/Email";
import { Role } from "@prisma/client";
export const menuItems = (session) => [
	{
		text: "Dashboard",
		icon: <DashboardIcon />,
		path: "/dashboard",
	},
	{
		text: "Jobs",
		icon: <ViewKanbanIcon />,
		path: "/dashboard/jobs",
	},
	{
		text: "Products requests",
		icon: <ProductionQuantityLimitsIcon />,
		path: "/dashboard/productsRequests",
	},
	...(() =>
		session?.user?.role == Role.Admin
			? [
					{
						text: "Users",
						icon: <PeopleIcon />,
						path: "/dashboard/users",
					},
					{
						text: "Taxes",
						icon: <PaidIcon />,
						path: "/dashboard/taxes",
					},
					{
						text: "Products",
						icon: <LocalMallIcon />,
						path: "/dashboard/products",
					},

					{
						text: "Materials",
						icon: <ConstructionIcon />,
						path: "/dashboard/materials",
					},
					{
						text: "Orders",
						icon: <ShoppingCartIcon />,
						path: "/dashboard/orders",
					},
					{
						text: "Delivery methods",
						icon: <LocalShippingIcon />,
						path: "/dashboard/deliveryMethods",
					},
					{
						text: "Email templates",
						icon: <EmailIcon />,
						path: "/dashboard/emailTemplates",
					},
					{
						text: "Invoices",
						icon: <CreditScoreIcon />,
						path: "/dashboard/invoices",
					},
					{
						text: "Payments",
						icon: <PaymentsIcon />,
						path: "/dashboard/payments",
					},
			  ]
			: [])(),
];
