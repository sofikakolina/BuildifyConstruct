"use client";
import * as React from "react";
import { useState, useEffect } from "react";
import { TablePagination } from "@mui/material";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import { CircularProgress } from "@mui/material";
import TableContainer from "@mui/material/TableContainer";
import { TableRow, TableCell, TableHead } from "@mui/material";
import Paper from "@mui/material/Paper";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import BeenhereIcon from "@mui/icons-material/Beenhere";
import { Box, TextField } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import Invoice from "./Invoice";
import ResultInvoice from "./ResultInvoice";
import makeApiRequest from "@/libs/makeApiRequest";
import { getOrderTaxFromInvoice, getInvoiceSubtotal } from "@/libs/calculations";

export default function Invoices({ company }) {
	const [invoices, setInvoices] = useState([]);
	const [total, setTotal] = useState(0);
	const [loading, setLoading] = useState(true);
	const [statusInvoices, setStatusInvoices] = useState({});
	const [search, setSearch] = useState("");
	const [page, setPage] = useState(0);
	const [size, setSize] = useState(10);
	const [startDate, setStartDate] = useState(null);
	const [endDate, setEndDate] = useState(null);

	useEffect(() => {
		(async () => {
			try {
				const fetchSize = size === -1 ? total || 1000 : size;

				const { invoices, total: newTotal } = await makeApiRequest(
					"/api/getInvoices",
					{
						page: size === -1 ? 0 : page,
						size: fetchSize,
						...(search.length ? { search } : {}),
						...(startDate
							? { startDate: startDate.toISOString() }
							: {}),
						...(endDate ? { endDate: endDate.toISOString() } : {}),
					}
				);

				if (size === -1 && total !== newTotal) {
					setTotal(newTotal);
					setSize(newTotal);
				}

				const totalAmount = invoices.reduce(
					(sum, invoice) => sum + invoice.order.payment.amount,
					0
				);
				const totalTaxes = invoices.reduce(
					(sum, invoice) => sum + getOrderTaxFromInvoice(invoice),
					0
				);

				const subTotalAmount = invoices.reduce(
					(sum, invoice) => sum + getInvoiceSubtotal(invoice),
					0
				);

				const statusInvoices = {
					name: "Total",
					totalResult: totalAmount,
					subTotal: subTotalAmount,
					taxes: totalTaxes,
					quantity: invoices.length,
				};

				setTotal(newTotal);
				setInvoices(invoices);
				setStatusInvoices(statusInvoices);
				setLoading(false);
			} catch (error) {
				console.error("Ошибка при получении данных:", error);
			}
		})();
	}, [page, size, search, startDate, endDate]);

	return (
		<div className="flex flex-col gap-10 m-4">
			{loading ? (
				<div className="w-full h-full flex items-center justify-center text-center">
					<CircularProgress />
				</div>
			) : (
				<>
					<div className="md:flex grid grid-cols-1 md:flex-wrap justify-center gap-3 md:gap-5 lg:gap-5 xl:gap-5">
						<ResultInvoice
							key="Total"
							Icon={BeenhereIcon}
							name="Total"
							amount={statusInvoices.totalResult / 100}
							count={statusInvoices.quantity}
						/>
						<ResultInvoice
							key="Subtotal"
							Icon={ReceiptOutlinedIcon}
							name="Subtotal"
							amount={statusInvoices.subTotal / 100}
							count={statusInvoices.quantity}
						/>
						<ResultInvoice
							key="Taxes"
							Icon={ReceiptOutlinedIcon}
							name="Taxes"
							amount={statusInvoices.taxes / 100}
							count={statusInvoices.quantity}
						/>
					</div>
					<Box
						sx={{
							display: "flex",
							gap: "10px",
							alignItems: "center",
						}}
					>
						<TextField
							sx={{ width: "100%" }}
							label="Search"
							onChange={(event) =>
								setSearch(() => {
									setPage(0);
									return event.target.value;
								})
							}
						/>
						<LocalizationProvider dateAdapter={AdapterDayjs}>
							<DatePicker
								label="Start Date"
								value={startDate}
								onChange={setStartDate}
							/>
							<DatePicker
								label="End Date"
								value={endDate}
								onChange={setEndDate}
							/>
						</LocalizationProvider>
					</Box>
					<div className="flex flex-col gap-5">
						<h3
							style={{
								color: "rgb(108, 115, 127)",
								fontWeight: "700",
								fontSize: "1.0417rem",
							}}
						>
							All({total})
						</h3>
						<TableContainer component={Paper}>
							<Table sx={{ minWidth: 650 }}>
								<TableHead>
									<TableRow>
										<TableCell>Id</TableCell>
										<TableCell>Total</TableCell>
										<TableCell>Created at</TableCell>
										<TableCell>Updated at</TableCell>
										<TableCell>Status</TableCell>
										<TableCell align="right">
											Details
										</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{invoices.map((invoice) => (
										<Invoice
											key={invoice.id}
											invoice={invoice}
											company={company}
										/>
									))}
									<TableRow>
										<TableCell colSpan={6} align="right">
											<TablePagination
												count={total}
												rowsPerPage={size}
												page={page}
												onPageChange={(
													event,
													newPage
												) => setPage(newPage)}
												onRowsPerPageChange={(
													event
												) => {
													const newSize = parseInt(
														event.target.value,
														10
													);
													setSize(
														newSize === -1
															? total
															: newSize
													);
													setPage(0);
												}}
												component="div"
												rowsPerPageOptions={[
													10,
													20,
													30,
													40,
													50,
													{ label: "All", value: -1 },
												]}
											/>
										</TableCell>
									</TableRow>
								</TableBody>
							</Table>
						</TableContainer>
					</div>
				</>
			)}
		</div>
	);
}
