const commonStyle = {
    fontWeight: "700",
    lineHeight: "1.2",
    fontSize: "1.0417rem",
    color: "rgb(17, 25, 39)",
};

const commonStyleMin = {
    fontWeight: "400",
    lineHeight: "1.57",
    fontSize: "0.875rem",
    color: "rgb(108, 115, 127)",
};

export default function ResultInvoice({Icon, name, statusInvoice, amount, count, backgroundRes, colorRes}){
    return(
        <div className="flex shadow-lg py-8 px-10 rounded-xl gap-5 items-center">
            <div style={{backgroundColor:backgroundRes, color:colorRes}} className="flex p-3 rounded-full items-center">
                <Icon/>
            </div>
            <div className="felx flex-col gap-5">
                <h3 className="font-bold">{name}</h3>
                <p style={{ ...commonStyleMin }}>{statusInvoice}</p>
                <h4 style={{ ...commonStyle }}>${amount}</h4>
                <p style={{ ...commonStyleMin }}>from {count} invoices</p>
            </div>
        </div>
    )
}