import React from 'react';
import { PDFDownloadLink, pdf } from '@react-pdf/renderer';
import { Button, Box } from "@mui/material";
import SendIcon from '@mui/icons-material/Send';
import makeApiRequest from "@/libs/makeApiRequest";
import toast from "react-hot-toast";
import { EmailTemplateType } from '@prisma/client';
import { fromOrder } from '@/libs/interpretEmailTemplate';
import InvoiceDocument from '@/components/invoicePdf';
const GeneratePdfButton = ({ order }) => {

  const sendInvoice = async () => {
	const [template, blob] = await Promise.all([
		makeApiRequest("/api/getEmailTemplates").then(({emailTemplates}) => emailTemplates.find(
			template => template.type == EmailTemplateType.Invoice
		)),
		pdf(<InvoiceDocument order={order} />).toBlob()
	])
    const formData = new FormData()
    formData.append('to', order.invoice.email)
    formData.append('subject', fromOrder(template.subject, order))
    formData.append('html', fromOrder(template.html, order))
    formData.append('attachments', blob, `invoice_${order.invoice.id}.pdf`)
    await makeApiRequest('/api/sendMail', formData)
  }

  const downloadButton = (
    <PDFDownloadLink document={<InvoiceDocument order={order} />} fileName={`invoice_${order.invoice.id}.pdf`}>
      {({ loading }) =>
        loading ? 'Preparing document...' : (
          <Button variant="contained" color="primary" sx={{ color: 'white' }}>
            Download PDF
          </Button>
        )
      }
    </PDFDownloadLink>
  );

  return (
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
      {downloadButton}
      <Button
        variant="contained"
        color="primary"
        sx={{ color: 'white' }}
        onClick={
			() => toast.promise(
				sendInvoice(), {
				loading: 'Sending invoice...',
				success: 'Invoice sent successfully!',
				error: 'Something went wrong...'
			})
		}
        endIcon={<SendIcon />}
      >
        Send to Email
      </Button>
    </Box>
  );
};

export default GeneratePdfButton;


