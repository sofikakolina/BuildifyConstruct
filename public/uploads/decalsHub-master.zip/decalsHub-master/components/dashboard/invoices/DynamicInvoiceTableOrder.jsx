import * as React from 'react';
import TableCell from '@mui/material/TableCell';
import TableRow from '@mui/material/TableRow';

export default function DynamicInvoiceTableOrder({orderItem, unitPrice}) {

  

  return (
        <TableRow
        key={orderItem.id}
        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
        >
        <TableCell colSpan={3} component="th" scope="row">
            <div className='flex flex-col gap-1'>
              <h5 style={{ fontWeight: "500", lineHeight: "1.57", fontSize: "0.875rem", color: "rgb(41, 50, 64)"}}>{orderItem.name}</h5>
              <h5 style={{ fontSize: "14px", fontWeight: "inherit"}}>W x H</h5>
              <h5 style={{ fontSize: "inherit", fontWeight: "inherit"}}>{orderItem.width}″ {orderItem.height}″</h5>
            </div>
        </TableCell>
        <TableCell align="left">{orderItem.quantity}</TableCell>
        <TableCell align="right">${(unitPrice/100).toFixed(2)}</TableCell>
        <TableCell align="right">${(unitPrice * orderItem.quantity/100).toFixed(2)}</TableCell>
        </TableRow>
  );
}
