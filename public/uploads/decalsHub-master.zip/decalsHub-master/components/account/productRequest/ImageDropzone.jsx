import React, { useState, useCallback, useEffect } from "react";
import { useDropzone } from "react-dropzone";
import {
	Box,
	CircularProgress,
	Card,
	CardActionArea,
	CardMedia,
	CardContent,
	Typography,
	IconButton,
} from "@mui/material";
import makeApiRequest from "@/libs/makeApiRequest";
import DeleteIcon from "@mui/icons-material/Delete";
import { AiOutlineClose } from "react-icons/ai";
export default function ImageDropzone({
	onDrop,
	image,
	paths,
	fileNames,
	onDeleteImage,
	errors,
}) {
	const [isLoading, setIsLoading] = useState(false);
	const [error, setError] = useState(errors);

	useEffect(() => {
		setError(errors);
	}, [errors]);

	const deleteImage = (image, deleteFileName) => {
		onDeleteImage(image, deleteFileName);
	};

	const onDropCallback = useCallback(async (acceptedFiles) => {
		setIsLoading(true);
		for (const file of acceptedFiles) {
			if (!file) {
				setIsLoading(false);
				return;
			}

			const data = new FormData();
			data.append("file", file);

			try {
				const response = await fetch("/api/uploadFile", {
					method: "POST",
					body: data,
				});

				if (!response.ok) {
					throw new Error("Failed to upload file");
				}

				const { path } = await response.json();
				onDrop(path, file.name);
			} catch (uploadError) {
				setError("An error occurred during file upload.");
				console.error(uploadError);
			} finally {
				setIsLoading(false);
			}
		}
	}, []);

	const { getRootProps, getInputProps } = useDropzone({
		onDrop: onDropCallback,
		accept: {
			"image/*": [".jpeg", ".jpg", ".png"],
			"application/pdf": [".pdf"],
			"application/postscript": [".eps"],
		},
		maxFiles: 10,
	});

	return (
		<Box>
			<Box
				{...getRootProps({ className: "dropzone" })}
				sx={{
					p: 2,
					display: "flex",
					alignItems: "center",
					justifyContent: "center",
					border: "2px dashed",
					borderColor: error ? "error.main" : "primary.light",
					borderRadius: 2,
					bgcolor: error ? "bg-red-100" : "background.paper",
					textAlign: "center",
					cursor: "pointer",
					minHeight: "200px",
				}}
			>
				<input {...getInputProps()} />
				{!isLoading && (
					<Typography
						sx={{
							fontWeight: "bold",
							color: error ? "text-red-500" : "primary.light",
						}}
					>
						Drag 'n' drop a file (images, PDF, EPS) here, or click to select a file
					</Typography>

				)}
				{isLoading && <CircularProgress />}
			</Box>
			{fileNames.length > 0 && (
				<div className="flex flex-wrap gap-4 border border-orange-400 p-4 rounded-xl bg-white shadow-sm mt-4">
					{paths.map((filePath, index) => (
						<div
							key={index}
							className="relative group w-32 h-32 border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300 bg-gray-50"
						>
							{filePath.match(/\.(jpeg|jpg|png)$/i) ? (
								<img
									src={filePath}
									alt={fileNames[index]}
									className="w-full h-full object-contain p-2"
								/>
							) : (
								<div className="w-full h-full flex items-center justify-center bg-gray-200">
									<Typography variant="caption">
										{fileNames[index]}
									</Typography>
								</div>
							)}

							<button
								onClick={() => deleteImage(filePath, fileNames[index])}
								className="absolute top-2 right-2 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 shadow-md hover:bg-red-600 p-2"
								aria-label="Delete File"
							>
								<AiOutlineClose size={20} />
							</button>
						</div>
					))}
				</div>
			)}

			{error && (
				<Typography
					variant="caption"
					sx={{ color: "error.main", mt: 2 }}
				>
					{error}
				</Typography>
			)}
		</Box>
	);
}
