import React from 'react';
import { TableCell, TableRow, useMediaQuery } from '@mui/material';

const commonStyle = {
  fontWeight: "500",
  lineHeight: "1.57",
  fontSize: "0.875rem",
  color: "rgb(17, 25, 39)",
};

export default function ProductRequestForm({ productRequest }) {
  const hideOnMd = useMediaQuery('(max-width:1140px)'); 

  return (
    <TableRow
      key={productRequest.id}
      sx={{ '&:last-child td, &:last-child th': { border: 0 }, 
      overflowX: hideOnMd ? 'hidden' : 'auto', 
      width: '100%',
    }}
    >
      <TableCell align="left" style={{ ...commonStyle, display: hideOnMd ? 'none' : '' }}>Product Request-{productRequest.id ? productRequest.id : "#"}</TableCell>
      <TableCell align="left" style={{ ...commonStyle, display: hideOnMd ? 'none' : '' }}>
        {productRequest.name}
      </TableCell>
      <TableCell align="left" style={{ ...commonStyle, display: hideOnMd ? 'none' : '' }}>
        {productRequest.description}
      </TableCell>
      <TableCell align="right" sx={{ flexDirection:"column", alignItems:"end", gap:"10px", display: hideOnMd ? 'none' : 'flex'}}>{productRequest.images?.map(image => <img width={150} height={150} src={image.src} alt={image}/>)}</TableCell>
    </TableRow>
  );
}
