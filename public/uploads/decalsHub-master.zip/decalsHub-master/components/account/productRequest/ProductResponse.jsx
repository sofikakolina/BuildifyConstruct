"use client";
import React, { useState, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import * as Yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import ImageDropzone from "./ImageDropzone";
import toast from "react-hot-toast";
import Image from "next/image";
import makeApiRequest from "@/libs/makeApiRequest";

const validationSchema = Yup.object().shape({
	companyName: Yup.string().required("Company Name is required"),
	description: Yup.string().nullable().notRequired(),
	usDotNumber: Yup.number()
		.typeError("US DOT Number must be a number")
		.required("US DOT Number is required"),
	mcNumber: Yup.number()
		.transform((value, originalValue) =>
			originalValue.trim() === "" ? null : value
		)
		.typeError("MC Number must be a number")
		.nullable()
		.notRequired(),
	kyuNumber: Yup.number()
		.transform((value, originalValue) =>
			originalValue.trim() === "" ? null : value
		)
		.typeError("KYU Number must be a number")
		.nullable()
		.notRequired(),
	grossWeight: Yup.number()
		.transform((value, originalValue) =>
			originalValue.trim() === "" ? null : value
		)
		.typeError("Gross Weight must be a number")
		.nullable()
		.notRequired(),
	stickerType: Yup.array()
		.of(Yup.string())
		.min(1, "You must select at least one sticker type")
		.required("Sticker type is required"),
	hasLogo: Yup.boolean(),
	stickerDetails: Yup.object().test(
		"sticker-details-validation",
		null,
		function (value) {
			const { stickerType } = this.parent;
			if (!stickerType || !stickerType.length) {
				return true;
			}
			let isValid = true;
			for (let type of stickerType) {
				const details = value ? value[type] : null;
				if (!details || !details.quantity) {
					isValid = false;
					this.path = `stickerDetails.${type}.quantity`;
					return this.createError({
						path: this.path,
						message: "Quantity is required",
					});
				}
				if (
					(type === "vinNumber" || type === "unitNumber") &&
					!details.data
				) {
					isValid = false;
					this.path = `stickerDetails.${type}.data`;
					return this.createError({
						path: this.path,
						message: "Data is required",
					});
				}
			}
			return isValid;
		}
	),
});

import OnePiece from "@/public/assets/onepiecesticker.png";
import DieCut from "@/public/assets/diecutsticker.png";
import RoofSticker from "@/public/assets/roofstickersample.png";
import VinNumber from "@/public/assets/vinnumbersample.png";
import Magnets from "@/public/assets/magnets.png";
import UnitNumber from "@/public/assets/unitnumbersample.png";

export default function ProductRequestForm() {
	const {
		register,
		handleSubmit,
		control,
		formState: { errors },
		setValue,
		watch,
		getValues,
	} = useForm({
		resolver: yupResolver(validationSchema),
		mode: "onChange",
		defaultValues: {
			companyName: "",
			description: "",
			usDotNumber: "",
			mcNumber: "",
			kyuNumber: "",
			grossWeight: "",
			stickerType: [],
			hasLogo: false,
			logo: null,
			stickerDetails: {},
		},
	});

	const [fileNames, setFileNames] = useState([]);
	const [paths, setPaths] = useState([]);
	const [isLoading, setIsLoading] = useState(false);
	const [newProductsRequests, setNewProductsRequests] = useState([]);

	useEffect(() => {
		if (paths.length > 0) {
			setValue("hasLogo", false);
		}
	}, [paths, setValue]);
	

	const deleteImage = (image, deleteFileName) => {
		setPaths((prev) => prev.filter((path) => path !== image));
		setFileNames((prev) =>
			prev.filter((fileName) => fileName !== deleteFileName)
		);
	};

	const onDrop = (newPath, newFileName) => {
		setPaths((prev) => [...prev, newPath]);
		setFileNames((prev) => [...prev, newFileName]);
	};

	const onSubmit = async (data) => {
		setIsLoading(true);
	  
		if (!data.hasLogo && !paths.length) {
		  toast.error("You didn't attach the photos");
		  setIsLoading(false);
		  return;
		}
	  
		const filteredStickerDetails = Object.fromEntries(
		  Object.entries(data.stickerDetails || {}).filter(([key]) =>
			data.stickerType.includes(key)
		  )
		);
	  
		const payload = {
		  companyName: data.companyName,
		  description: data.description,
		  usDotNumber: data.usDotNumber,
		  mcNumber: data.mcNumber || null,
		  kyuNumber: data.kyuNumber || null,
		  grossWeight: data.grossWeight || null,
		  stickerType: data.stickerType,
		  stickerDetails: filteredStickerDetails,
		  hasLogo: data.hasLogo,
		};
	  
		try {
		  const { productRequest } = await makeApiRequest(
			"/api/createProductRequest",
			payload
		  );
	  
		  for (const path of paths) {
			await makeApiRequest("/api/createProductRequestImage", {
			  requestId: productRequest.id,
			  src: path,
			});
		  }
	  
		  setNewProductsRequests((prevRequests) => [
			...prevRequests,
			{
			  ...productRequest,
			  images: paths.map((path) => ({ src: path })),
			},
		  ]);
	  
		  setFileNames([]);
		  setPaths([]);
		  resetForm();
		  toast.success("Your request has been sent successfully");
		} catch (error) {
		  toast.error(error.message);
		} finally {
		  setIsLoading(false);
		}
	  };
	  

	const resetForm = () => {
		setPaths([]);
		setFileNames([]);
		setValue("companyName", "");
		setValue("description", "");
		setValue("usDotNumber", "");
		setValue("mcNumber", "");
		setValue("kyuNumber", "");
		setValue("grossWeight", "");
		setValue("stickerType", []);
		setValue("hasLogo", false);
		setValue("stickerDetails", {});
	};

	const stickerType = watch("stickerType");

	return (
		<div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
			<h2 className="text-2xl font-bold text-gray-700 mb-4">
				Product Request
			</h2>
			<form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
				<div>
					<label className="block text-sm font-medium text-gray-700">
						Company Name *
					</label>
					<input
						type="text"
						className={`mt-1 block w-full py-2 px-3 rounded-md border ${
							errors.companyName
								? "border-red-500"
								: "border-gray-300"
						} shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm`}
						{...register("companyName")}
					/>
					{errors.companyName && (
						<p className="text-red-500 text-sm mt-1">
							{errors.companyName.message}
						</p>
					)}
				</div>

				<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
					<div>
						<label className="block text-sm font-medium text-gray-700">
							US DOT Number *
						</label>
						<input
							type="number"
							className={`mt-1 block w-full  py-2 px-3 rounded-md border ${
								errors.usDotNumber
									? "border-red-500"
									: "border-gray-300"
							} shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm`}
							{...register("usDotNumber")}
						/>
						{errors.usDotNumber && (
							<p className="text-red-500 text-sm mt-1">
								{errors.usDotNumber.message}
							</p>
						)}
					</div>
					<div>
						<label className="block text-sm font-medium text-gray-700">
							MC Number
						</label>
						<input
							type="number"
							className="mt-1 block w-full  py-2 px-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
							{...register("mcNumber")}
						/>
					</div>
				</div>

				<div className="grid grid-cols-1 md:grid-cols-2 gap-4">
					<div>
						<label className="block text-sm font-medium text-gray-700">
							KYU Number
						</label>
						<input
							type="number"
							className="mt-1 block w-full  py-2 px-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
							{...register("kyuNumber")}
						/>
					</div>
					<div>
						<label className="block text-sm font-medium text-gray-700">
							Gross Weight
						</label>
						<input
							type="number"
							className="mt-1 block w-full py-2 px-3 rounded-md border border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
							{...register("grossWeight")}
						/>
					</div>
				</div>

				{/* Logo Upload */}
				<div>
					<label className="block text-sm mb-2 font-medium text-gray-700">
						Logo / Image Upload
					</label>
					<Controller
						control={control}
						name="logo"
						render={({ field }) => (
							<ImageDropzone
								onDrop={onDrop}
								image={field.value}
								paths={paths}
								fileNames={fileNames}
								onDeleteImage={deleteImage}
							/>
						)}
					/>
					<div className="mt-2">
						<label className="flex items-center space-x-3">
							<input
								type="checkbox"
								className="h-4 w-4 text-indigo-600 border-gray-300 rounded"
								{...register("hasLogo")}
							/>
							<span className="text-sm text-gray-600">
								I don’t have a logo
							</span>
						</label>
					</div>
				</div>

				{/* Sticker Type Selection */}
				<div>
					<label className="block text-sm font-medium text-gray-700 mb-2">
						Sticker Type
					</label>
					<div className="mt-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
						{[
							{
								value: "Die-Cut Letters and Logo",
								label: "Die-Cut Letters and Logo",
								image: DieCut,
							},
							{
								value: "One-Piece Vinyl with Printed Design",
								label: "One-Piece Vinyl with Printed Design",
								image: OnePiece,
							},
							{
								value: "Roof Sticker",
								label: "Roof Sticker",
								image: RoofSticker,
							},
							{
								value: "VIN Number",
								label: "VIN Number",
								image: VinNumber,
							},
							{
								value: "Magnets",
								label: "Magnets",
								image: Magnets,
							},
							{
								value: "Unit Number",
								label: "Unit Number",
								image: UnitNumber,
							},
							{ value: "Other", label: "Other" },
						].map((option) => {
							const isSelected = stickerType?.includes(
								option.value
							);
							return (
								<div key={option.value} className="flex flex-col gap-2">
									<label
										className={`flex h-full flex-col items-start p-4 border rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer space-y-2 ${
											isSelected
												? "border-indigo-500 bg-indigo-50"
												: "bg-white"
										}`}
									>
										<div className="flex items-center space-x-3">
											<input
												type="checkbox"
												value={option.value}
												className="h-5 w-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
												{...register("stickerType")}
											/>
											<span className="text-xs font-medium text-gray-700">
												{option.label}
											</span>
										</div>
										{option.image && (
											<div className="flex items-center h-full">
												<Image
													src={option.image}
													alt={option.label}
													className="w-full rounded-md shadow-md hover:scale-105 transition-transform duration-300"
												/>
											</div>
										)}
									</label>
									{isSelected && (
										<div className="mt-2">
											<label className="block text-sm font-medium text-gray-700">
												Quantity
											</label>
											<input
												type="number"
												className={`mt-1 block w-full py-2 px-3 rounded-md border ${
													errors.stickerDetails?.[
														option.value
													]?.quantity
														? "border-red-500"
														: "border-gray-300"
												} shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm`}
												{...register(
													`stickerDetails.${option.value}.quantity`
												)}
											/>
											{errors.stickerDetails?.[
												option.value
											]?.quantity && (
												<p className="text-red-500 text-sm mt-1">
													{
														errors.stickerDetails[
															option.value
														].quantity.message
													}
												</p>
											)}
											{(option.value === "VIN Number" ||
												option.value ===
													"Unit Number") && (
												<>
													<label className="block text-sm font-medium text-gray-700 mt-2">
														Enter list of {option.value}s
													</label>
													<textarea
														className={`mt-1 block w-full py-2 px-3 rounded-md border ${
															errors
																.stickerDetails?.[
																option.value
															]?.data
																? "border-red-500"
																: "border-gray-300"
														} shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm`}
														{...register(
															`stickerDetails.${option.value}.data`
														)}
														placeholder="Enter data"
													/>
													{errors.stickerDetails?.[
														option.value
													]?.data && (
														<p className="text-red-500 text-sm mt-1">
															{
																errors
																	.stickerDetails[
																	option.value
																].data.message
															}
														</p>
													)}
												</>
											)}
										</div>
									)}
								</div>
							);
						})}
					</div>
					{errors.stickerType && (
						<p className="text-red-500 text-sm mt-1">
							{errors.stickerType.message}
						</p>
					)}
				</div>

				<div>
					<label className="block text-sm font-medium text-gray-700">
						Description
					</label>
					<textarea
						className={`mt-1 block w-full py-2 px-3  rounded-md border ${
							errors.description
								? "border-red-500"
								: "border-gray-300"
						} shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm`}
						{...register("description")}
						name="description"
						id="description"
						placeholder="Type your description"
					/>
					{errors.description && (
						<p className="text-red-500 text-sm mt-1">
							{errors.description.message}
						</p>
					)}
				</div>

				{/* Submit Button */}
				<div className="pt-6">
					<button
						type="submit"
						className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
						disabled={isLoading}
					>
						{isLoading ? "Submitting..." : "Submit Request"}
					</button>
				</div>
			</form>
		</div>
	);
}
