import Joi from "joi-browser"
import {TableRow, TableCell, IconButton, Grid, TextField, Button} from "@mui/material"
import CloseIcon from '@mui/icons-material/Close'
import {useState} from "react"
import toast from "react-hot-toast"

const validationSchema = Joi.object({name: Joi.string().max(50).required()})

export default function ProductForm({onSubmit, onCancel, defaultValue, makeApiRequest}) {
	const [form, setForm] = useState(defaultValue ? defaultValue : {})
	const [errors, setErrors] = useState({})
	const handleFormChange = (event) => setForm(form => ({...form, [event.target.name]: event.target.value.trim()}))
	async function handleSubmit() {
		try {
			const {error, value} = validationSchema.validate(form, {abortEarly: false, stripUnknown: true})
			if(error) {setErrors(error.details.reduce((newErrors, detail) => ({...newErrors, [detail.path[0]]: detail.message}), {})); return}
			const response = await makeApiRequest(value)
			onSubmit(response ? response.product : value)
		}
		catch(e) {toast.error(e.message)}
	}
	
	return (
		<TableRow sx={{'& > *': {borderBottom: 'unset'}}}>
			<TableCell>
				<IconButton size="small" onClick={onCancel}>
					<CloseIcon />
				</IconButton>
			</TableCell>
			<TableCell>
				<Grid container>
					<TextField
						margin="normal"
						label="Name"
						variant="outlined"
						name="name"
						error={Boolean(errors.name)}
						helperText={errors.name}
						onChange={handleFormChange}
						defaultValue={form.name}
					/>
					<Button type="button" onClick={handleSubmit} variant="contained" color="primary">
						Save
					</Button>
				</Grid>
			</TableCell>
		</TableRow>
	)
}