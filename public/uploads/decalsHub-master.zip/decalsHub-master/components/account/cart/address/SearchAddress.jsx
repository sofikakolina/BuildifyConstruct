import React, { useState, useEffect } from 'react';
import { Autocomplete, TextField } from '@mui/material';

const SearchAddress = ({ setFullAddress }) => {
    const [inputValue, setInputValue] = useState('');
    const [options, setOptions] = useState([]);
    const [autocompleteService, setAutocompleteService] = useState(null);

    useEffect(() => {
        const handleScriptLoad = () => {
            if (window.google && window.google.maps.places) {
                setAutocompleteService(new window.google.maps.places.AutocompleteService());
            }
        };

        if (window.google && window.google.maps.places) {
            handleScriptLoad();
        } else {
            const script = document.createElement("script");
            script.src = `https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&language=en&region=en&libraries=places`;
            script.async = true;
            script.defer = true;
            document.body.appendChild(script);
            script.onload = () => handleScriptLoad();
        }
    }, []);

    const handleInputChange = (_, newInputValue) => {
        setInputValue(newInputValue); // Сохраняем введенное значение
        setFullAddress(newInputValue); // Возвращаем введенное значение как полный адрес
        if (!autocompleteService || newInputValue.length < 3) {
            setOptions([]);
            return;
        }

        autocompleteService.getPlacePredictions({
            input: newInputValue,
            componentRestrictions: { country: ["us", "ca"] }
        }, (predictions, status) => {
            if (status === window.google.maps.places.PlacesServiceStatus.OK && predictions) {
                setOptions(predictions.map(prediction => prediction.description));
            } else {
                setOptions([]);
            }
        });
    };

    const handlePlaceSelect = async (address) => {
        const geocoder = new window.google.maps.Geocoder();
        geocoder.geocode({ address }, (results, status) => {
            if (status === 'OK' && results[0]) {
                const place = results[0];
                setFullAddress(place.formatted_address); // Устанавливаем полный адрес через геокодер
            }
        });
    };

    return (
        <Autocomplete
            freeSolo
            disableClearable
            options={options}
            inputValue={inputValue}
            onInputChange={handleInputChange}
            onChange={(event, newValue) => {
                if (newValue) {
                    handlePlaceSelect(newValue); // Только если выбран адрес из автокомплита
                }
            }}
            renderInput={(params) => (
                <TextField
                    {...params}
                    size="small"
                    label="Full address"
                    variant="outlined"
                    InputLabelProps={{
                        sx: {
                            fontSize: '12px',
                            fontWeight: 'bold',
                        }
                    }}
                    InputProps={{
                        ...params.InputProps,
                        inputProps: {
                            ...params.inputProps,
                            sx: {
                                fontSize: '12px',
                                fontWeight: 'bold',
                            }
                        }
                    }}
                />
            )}
        />
    );
};

export default SearchAddress;
