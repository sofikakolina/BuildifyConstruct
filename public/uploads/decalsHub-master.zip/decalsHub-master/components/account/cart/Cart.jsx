"use client";
import { useState, useEffect, useRef } from "react";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import CartOrder from "./CartOrder";
import CloseIcon from "@mui/icons-material/Close";
import {
	CircularProgress,
	Dialog,
	DialogTitle,
	DialogContent,
	Button,
	FormControl,
	FormLabel,
	RadioGroup,
	FormControlLabel,
	Radio,
	IconButton,
	useMediaQuery,
	Typography,
	Box,
	TextField,
	Alert,
	Backdrop,
} from "@mui/material";
import { PaymentForm, CreditCard } from "react-square-web-payments-sdk";
import makeApiRequest from "@/libs/makeApiRequest";
import { useRouter } from "next/navigation";
import { ThemeProvider } from "@mui/material/styles";
import theme from "@/theme";
import { getCartSubtotal, getCartTax, getCartTotal } from "@/libs/calculations";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import { AddressType } from "@prisma/client";
import SearchAddress from "./address/SearchAddress";

// Валидация адреса
const newAddressSchema = Yup.object().shape({
	fullAddress: Yup.string().required("Full address is required"),
	apartment: Yup.string().nullable(),
});

// Валидация доставки
const deliverySchema = Yup.object().shape({
	shipTo: Yup.string().required("Full name is required"),
	phoneShip: Yup.string()
		.required("Phone number is required")
		.matches(/^\+?[1-9]\d{1,14}$/, "Phone number is invalid"),
	shipToCompany: Yup.string().nullable(),
});

// Валидация самовывоза
const pickupSchema = Yup.object().shape({
	shipTo: Yup.string().nullable(),
	phoneShip: Yup.string().nullable(),
	shipToCompany: Yup.string().nullable(),
});

export default function Cart() {
	const hideOnMd = useMediaQuery("(max-width:600px)");
	const [order, setOrder] = useState([]);
	const [deliveryMethods, setDeliveryMethods] = useState([]);
	const [deliveryMethodsIdChoice, setDeliveryMethodsIdChoice] =
		useState(null);
	const [loading, setLoading] = useState(true);
	const [subTotal, setSubTotal] = useState(0);
	const [total, setTotal] = useState(0);
	const [taxes, setTaxes] = useState(0);
	const [addresses, setAddresses] = useState({ loaded: [], created: [] });
	const [addressIdChoice, setAddressIdChoice] = useState("");
	const [shipTo, setShipTo] = useState("");
	const [phoneShip, setPhoneShip] = useState("");
	const [shipToCompany, setShipToCompany] = useState("");
	const [comments, setComments] = useState([]);
	const [isCheckoutModalOpen, setCheckoutModalOpen] = useState(false);
	const [shippingMethod, setShippingMethod] = useState("Pickup");
	const [showNewAddressForm, setShowNewAddressForm] = useState(false);
	const [fullAddress, setFullAddress] = useState("");
	const [apartment, setApartment] = useState("");
	const [formError, setFormError] = useState("");
	const [isProcessingPayment, setIsProcessingPayment] = useState(false);


	// Получаем правильную схему валидации в зависимости от метода доставки
	const getPaymentSchema = () => {
		return shippingMethod === "Delivery" ? deliverySchema : pickupSchema;
	};

	const {
		register,
		handleSubmit,
		setValue,
		reset,
		formState: { errors },
	} = useForm({
		resolver: yupResolver(newAddressSchema),
	});

	const {
		register: registerPayment,
		handleSubmit: handleSubmitPayment,
		setValue: setValuePayment,
		formState: { errors: paymentErrors },
	} = useForm({
		resolver: yupResolver(getPaymentSchema()),
	});

	useEffect(() => {
		(async () => {
			try {
				const { order } = await makeApiRequest("/api/getCart", {});
				const { deliveryMethods } = await makeApiRequest(
					"/api/getDeliveryMethods"
				);
				setOrder(order);
				setSubTotal(getCartSubtotal(order));
				setTaxes(getCartTax(order));
				setTotal(getCartTotal(order));
				setDeliveryMethods(deliveryMethods);
				setShipTo(order.user.name || "");
				setPhoneShip(order.user.phones?.[0]?.number || "");
				setShipToCompany(order.user.company || "");
				setAddresses((prevState) => ({
					...prevState,
					loaded: order.user.addresses,
				}));
				ref.current = order;
				setLoading(false);
			} catch (error) {
				setFormErrorAndScroll(`Error loading data: ${error.message}`);
			}
		})();
	}, []);

	useEffect(() => {
		setValuePayment("shipTo", shipTo);
		setValuePayment("phoneShip", phoneShip);
		setValuePayment("shipToCompany", shipToCompany);
	}, [shippingMethod, setValuePayment, shipTo, phoneShip, shipToCompany]);

	const handleAddressChange = (event) => {
		const selectedAddressId = parseInt(event.target.value, 10);
		const selectedAddress = addresses.created
			.concat(addresses.loaded)
			.find((address) => address.id === selectedAddressId);
		setAddressIdChoice(selectedAddressId);

		if (selectedAddress) {
			const fullAddress = [
				selectedAddress.street,
				selectedAddress.building,
				selectedAddress.city,
				selectedAddress.state,
				selectedAddress.zip,
				selectedAddress.country,
			]
				.filter(Boolean)
				.join(", ");

			setFullAddress(fullAddress);
			setApartment(selectedAddress.apartment || "");
			setShowNewAddressForm(false); // Скрыть форму добавления нового адреса при выборе существующего адреса
		} else {
			setFullAddress("");
			setApartment("");
		}
	};

	const updateOrder = (id, newQuantity) => {
		const newOrder = ref.current;
		newOrder.orderItems.forEach((orderItem) => {
			if (orderItem.id == id) {
				orderItem.quantity = newQuantity;
			}
		});
		ref.current = newOrder;
		setOrder(newOrder);
		setSubTotal(getCartSubtotal(newOrder));
		setTaxes(getCartTax(newOrder));
		setTotal(getCartTotal(newOrder));
	};

	const onDelete = (index) => {
		const newOrder = ref.current;
		newOrder.orderItems = newOrder.orderItems.filter(
			(orderItems) => orderItems.id != index
		);
		ref.current = newOrder;
		setOrder(newOrder);
		setSubTotal(getCartSubtotal(newOrder));
		setTaxes(getCartTax(newOrder));
		setTotal(getCartTotal(newOrder));
	};

	const updateProductComment = async (id, comment) => {
		const existingCommentIndex = comments.findIndex(
			(item) => item.id === id
		);

		if (existingCommentIndex !== -1) {
			setComments((prev) => {
				const updatedComments = [...prev];
				updatedComments[existingCommentIndex] = { id, comment };
				return updatedComments;
			});
		} else {
			setComments((prev) => [...prev, { id, comment }]);
		}
	};

	const dialogContentRef = useRef(null);

	const scrollToTop = () => {
		if (dialogContentRef.current) {
			dialogContentRef.current.scrollTo({ top: 0, behavior: "smooth" });
		}
	};

	const setFormErrorAndScroll = (message) => {
		setFormError(message);
		scrollToTop();
	};

	const handleOpenCheckoutModal = () => {
		setCheckoutModalOpen(true);
	};

	const handleCloseCheckoutModal = () => {
		setCheckoutModalOpen(false);
	};

	const handleDeleteAddress = async () => {
		try {
			await makeApiRequest("/api/deleteAddress", {
				id: parseInt(addressIdChoice, 10),
			});

			setAddresses((prevState) => {
				const updatedLoaded = prevState.loaded.filter(
					(addr) => addr.id !== parseInt(addressIdChoice, 10)
				);
				const updatedCreated = prevState.created.filter(
					(addr) => addr.id !== parseInt(addressIdChoice, 10)
				);

				return {
					loaded: updatedLoaded,
					created: updatedCreated,
				};
			});

			setAddressIdChoice("");
			setFullAddress("");
			setApartment("");
			reset();
		} catch (error) {
			setFormErrorAndScroll(`Failed to delete address: ${error.message}`);
		}
	};

	let ref = useRef(null);
	const router = useRouter();

	const handleShippingChange = (event) => {
		setShippingMethod(event.target.value);
	};

	const handleSaveNewAddress = async (data) => {
		try {
			const requestData = {
				userId: order.user.id,
				address: data.fullAddress,
				type: AddressType.Shipping,
				label: "New Shipping Address",
			};

			if (data.apartment) {
				requestData.apartment = data.apartment;
			}

			const response = await makeApiRequest(
				"/api/createAddress",
				requestData
			);

			const newAddress = response.address;

			if (newAddress && newAddress.id) {
				setAddresses((prevState) => ({
					...prevState,
					created: [...prevState.created, newAddress],
				}));
				setShowNewAddressForm(false);
				setAddressIdChoice(newAddress.id.toString());
				setFullAddress("");
				setApartment("");
				reset(); // сброс формы после успешного добавления
			} else {
				setFormErrorAndScroll(
					"Failed to save address: Invalid address ID"
				);
			}
		} catch (error) {
			setFormErrorAndScroll(`Failed to save address: ${error.message}`);
		}
	};

	const handleChangeAddress = async () => {
		try {
			const requestData = {
				id: parseInt(addressIdChoice, 10),
				address: fullAddress,
			};

			if (apartment) {
				requestData.apartment = apartment;
			}

			await makeApiRequest("/api/editAddress", requestData);

			setAddresses((prevState) => {
				const updatedAddresses = prevState.loaded
					.concat(prevState.created)
					.map((addr) =>
						addr.id === parseInt(addressIdChoice, 10)
							? {
									...addr,
									street: fullAddress.split(", ")[0],
									building: fullAddress.split(", ")[1],
									city: fullAddress.split(", ")[2],
									state: fullAddress.split(", ")[3],
									zip: fullAddress.split(", ")[4],
									country: fullAddress.split(", ")[5],
									apartment: apartment,
							  }
							: addr
					);

				const loaded = updatedAddresses.filter((addr) =>
					prevState.loaded.some((oldAddr) => oldAddr.id === addr.id)
				);
				const created = updatedAddresses.filter((addr) =>
					prevState.created.some((oldAddr) => oldAddr.id === addr.id)
				);

				return {
					loaded,
					created,
				};
			});
		} catch (error) {
			setFormErrorAndScroll(`Failed to change address: ${error.message}`);
		}
	};

	const onSubmitPayment = async (data) => {
		if (isProcessingPayment) return; // Prevent multiple submissions
		setIsProcessingPayment(true);
		try {
			if (shippingMethod === "Delivery") {
				if (!addressIdChoice) {
					setFormErrorAndScroll(
						"You didn't specify the shipping address"
					);
					return;
				}
				if (!deliveryMethodsIdChoice) {
					setFormErrorAndScroll(
						"You didn't specify the delivery method"
					);
					return;
				}
				await makeApiRequest("/api/editOrder", {
					id: order.id,
					addressId: addressIdChoice,
					deliveryMethodId: deliveryMethodsIdChoice,
				});
			}
			for (const commentItem of comments) {
				await makeApiRequest("/api/editOrderItem", {
					id: commentItem.id,
					comment: commentItem.comment,
				});
			}

			const requestData = {
				orderId: order.id,
				sourceId: data.token,
			};

			if (data.shipTo) {
				requestData.shipToName = data.shipTo;
			}

			if (data.phoneShip) {
				requestData.shipToPhone = data.phoneShip;
			}

			if (data.shipToCompany) {
				requestData.shipToCompany = data.shipToCompany;
			}

			await makeApiRequest("/api/createPayment", requestData);

			router.push("/account/orders");
		} catch (error) {
			setFormErrorAndScroll(`Payment failed: ${error.message}`);
		} finally {
			setIsProcessingPayment(false);
		}
	};

	const handlePaymentResponse = async (token, buyer) => {
		if (isProcessingPayment) return; // Prevent multiple submissions
		handleSubmitPayment(async (data) => {
			data.token = token.token;
			await onSubmitPayment(data);
		})();
	};

	return (
		<>
			{loading ? (
				<div className="w-full h-full flex items-center justify-center text-center">
					<CircularProgress />
				</div>
			) : subTotal ? (
				<ThemeProvider theme={theme}>
					<div className="md:grid grid-cols-4">
						<div className="flex flex-col my-4 mx-2 gap-5 shadow-2xl rounded-lg md:col-span-3">
							{order.orderItems.map((orderItem) => (
								<CartOrder
									key={orderItem.id}
									orderItem={orderItem}
									onDelete={onDelete}
									taxRate={
										order.user.tax ? order.user.tax.rate : 0
									}
									index={orderItem.id}
									updateOrder={updateOrder}
									updateProductComment={updateProductComment}
								/>
							))}
						</div>

						<div className="hidden md:flex my-4 mx-2 shadow-2xl rounded-lg h-[300px]">
							<div className="flex flex-col justify-center gap-4 w-full rounded-2xl bg-white p-3">
								<h2 className="text-lg font-bold">
									Order Summary
								</h2>
								<div className="flex flex-col gap-3">
									<div className="flex justify-between items-center">
										<h4 className="text-sm">Sub Total</h4>
										<h5 className="text-sm font-medium">
											${" "}
											<span>
												{(subTotal / 100).toFixed(2)}
											</span>
										</h5>
									</div>
									<div className="flex justify-between items-center">
										<h4 className="text-sm">Taxes</h4>
										<h5 className="text-sm font-medium">
											${" "}
											<span>
												{(Number(taxes) / 100).toFixed(
													2
												)}
											</span>
										</h5>
									</div>
								</div>
								<div className="flex justify-between">
									<h2 className="text-xl font-bold">Total</h2>
									<div className="flex items-center">
										<AttachMoneyIcon
											sx={{ color: "#F69220" }}
										/>
										<h3 className="text-xl text-primary font-bold">
											{(total / 100).toFixed(2)}
										</h3>
									</div>
								</div>
								<Button
									variant="contained"
									onClick={handleOpenCheckoutModal}
									disabled={isProcessingPayment}
									sx={{
										bgcolor: "#F69220",
										fontSize: "20px",
										color: "white",
										borderRadius: "10px",
									}}
								>
									Check Out
								</Button>
							</div>
						</div>

						<div className="md:hidden w-full flex justify-center items-center p-4">
							<div className="flex flex-col justify-center gap-4 w-full rounded-2xl bg-white p-3">
								<h2 className="text-lg font-bold">
									Order Summary
								</h2>
								<div className="flex flex-col gap-3">
									<div className="flex justify-between items-center">
										<h4 className="text-sm">Sub Total</h4>
										<h5 className="text-sm font-medium">
											${" "}
											<span>
												{(subTotal / 100).toFixed(2)}
											</span>
										</h5>
									</div>
									<div className="flex justify-between items-center">
										<h4 className="text-sm">Taxes</h4>
										<h5 className="text-sm font-medium">
											${" "}
											<span>
												{(
													(((100 +
														(order.user.tax
															? order.user.tax
																	.rate
															: 0)) /
														100) *
														subTotal -
														subTotal) /
													100
												).toFixed(2)}
											</span>
										</h5>
									</div>
								</div>
								<div className="flex justify-between">
									<h4 className="text-xl font-bold">Total</h4>
									<div className="flex items-center">
										<AttachMoneyIcon
											sx={{ color: "#F69220" }}
										/>
										<h3 className="text-xl text-primary font-bold">
											{Math.ceil(
												((100 +
													(order.user.tax
														? order.user.tax.rate
														: 0)) /
													100) *
													subTotal
											) / 100}
										</h3>
									</div>
								</div>
								<Button
									onClick={handleOpenCheckoutModal}
									variant="contained"
									sx={{
										bgcolor: "#F69220",
										fontSize: "20px",
										color: "white",
										borderRadius: "10px",
									}}
								>
									Check Out
								</Button>
							</div>
						</div>
						<Dialog
							sx={{
								"& .MuiDialog-paper": {
									borderRadius: "16px",
									padding: hideOnMd ? 0 : "20px",
									width: "fit-content",
									maxWidth: "none",
								},
							}}
							open={isCheckoutModalOpen}
							onClose={handleCloseCheckoutModal}
						>
							<DialogTitle
								sx={{
									display: "flex",
									justifyContent: "space-between",
									alignItems: "center",
								}}
							>
								Checkout
								<IconButton
									onClick={() => setCheckoutModalOpen(false)}
									aria-label="close"
								>
									<CloseIcon />
								</IconButton>
							</DialogTitle>
							<DialogContent ref={dialogContentRef}>
								{formError && (
									<Alert sx={{ mb: "20px" }} severity="error">
										{formError}
									</Alert>
								)}
								{isProcessingPayment && (
									<Backdrop
										open={true}
										sx={{
											zIndex: (theme) =>
												theme.zIndex.drawer + 1,
											color: "#fff",
										}}
									>
										<CircularProgress color="inherit" />
									</Backdrop>
								)}
								<FormControl
									component="fieldset"
									sx={{ width: "100%" }}
									disabled={isProcessingPayment}
								>
									<FormLabel
										component="legend"
										sx={{
											marginBottom: "20px",
											fontWeight: "bold",
										}}
									>
										Shipping Method
									</FormLabel>
									<RadioGroup
										aria-label="shipping-method"
										name="shipping-method-group"
										value={shippingMethod}
										onChange={handleShippingChange}
									>
										{["Pickup", "Delivery"].map(
											(option) => (
												<FormControlLabel
													key={option}
													value={option}
													control={<Radio />}
													label={option}
													sx={{
														".MuiTypography-root": {
															fontWeight:
																"medium",
														},
													}}
												/>
											)
										)}
									</RadioGroup>

									{shippingMethod === "Delivery" && (
										<>
											<Box
												sx={{
													display: "flex",
													flexDirection: "column",
													gap: "10px",
													mb: "10px",
												}}
											>
												<RadioGroup
													sx={{
														padding: hideOnMd
															? "5px 10px 0px"
															: "5px 50px 10px 50px",
													}}
													aria-label="address"
													name="address"
													value={addressIdChoice}
													onChange={
														handleAddressChange
													}
												>
													{[
														...addresses.created,
														...addresses.loaded,
													].map((option) => {
														const fullAddress =
															option.apartment
																? `${option.street} ${option.building}, ${option.apartment}, ${option.city}, ${option.state} ${option.zip}`
																: `${option.street} ${option.building}, ${option.city}, ${option.state} ${option.zip}`;

														return (
															<FormControlLabel
																key={option.id}
																value={
																	option.id
																}
																control={
																	<Radio />
																}
																label={`${fullAddress}${option.apartment
																	? ", " +
																	option.apartment
																	: ""
																	}`}
																sx={{
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																}}
															/>
														);
													})}
												</RadioGroup>

												{addressIdChoice && (
													<Box
														sx={{
															display: "flex",
															flexDirection:
																"column",
															gap: "10px",
														}}
													>
														<Typography
															variant="body1"
															component="h2"
															sx={{
																fontWeight:
																	"bold",
															}}
														>
															Ship to
														</Typography>
														<TextField
															label="Full name (First and Last name)"
															value={shipTo}
															size="small"
															{...registerPayment(
																"shipTo"
															)}
															error={
																!!paymentErrors.shipTo
															}
															helperText={
																paymentErrors
																	.shipTo
																	?.message
															}
															onChange={(e) =>
																setShipTo(
																	e.target
																		.value
																)
															}
															InputLabelProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
															InputProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
														/>
														<TextField
															label="Phone number"
															value={phoneShip}
															size="small"
															{...registerPayment(
																"phoneShip"
															)}
															error={
																!!paymentErrors.phoneShip
															}
															helperText={
																paymentErrors
																	.phoneShip
																	?.message
															}
															onChange={(e) =>
																setPhoneShip(
																	e.target
																		.value
																)
															}
															InputLabelProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
															InputProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
														/>
														<TextField
															label="Company"
															value={
																shipToCompany
															}
															size="small"
															{...registerPayment(
																"shipToCompany"
															)}
															error={
																!!paymentErrors.shipToCompany
															}
															helperText={
																paymentErrors
																	.shipToCompany
																	?.message
															}
															onChange={(e) =>
																setShipToCompany(
																	e.target
																		.value
																)
															}
															InputLabelProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
															InputProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
														/>
														<Typography
															variant="body1"
															component="h2"
															sx={{
																fontWeight:
																	"bold",
															}}
														>
															Address
														</Typography>
														<TextField
															label="Full address"
															value={fullAddress}
															size="small"
															{...register(
																"fullAddress"
															)}
															error={
																!!errors.fullAddress
															}
															helperText={
																errors
																	.fullAddress
																	?.message
															}
															onChange={(e) =>
																setFullAddress(
																	e.target
																		.value
																)
															}
															InputLabelProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
															InputProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
														/>
														<TextField
															label="Apt, Suite, building, floor, etc"
															value={apartment}
															size="small"
															{...register(
																"apartment"
															)}
															error={
																!!errors.apartment
															}
															helperText={
																errors.apartment
																	?.message
															}
															onChange={(e) =>
																setApartment(
																	e.target
																		.value
																)
															}
															InputLabelProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
															InputProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
														/>
														<Button
															variant="contained"
															color="success"
															sx={{
																color: "white",
															}}
															onClick={handleSubmit(
																handleChangeAddress
															)}
														>
															Change Address
														</Button>
														<Button
															variant="contained"
															color="error"
															sx={{
																color: "white",
																mt: 1,
															}}
															onClick={
																handleDeleteAddress
															}
														>
															Delete Address
														</Button>
													</Box>
												)}
												{!showNewAddressForm && (
													<Button
														variant="contained"
														color="primary"
														sx={{ color: "white" }}
														onClick={() => {
															setShowNewAddressForm(
																true
															);
															setAddressIdChoice(
																""
															);
															setFullAddress("");
															setApartment("");
														}}
													>
														Add new address
													</Button>
												)}

												{showNewAddressForm && (
													<Box
														sx={{
															display: "flex",
															flexDirection:
																"column",
															gap: "10px",
															mb: "10px",
														}}
													>
														<Typography
															variant="body1"
															component="h2"
															sx={{
																fontWeight:
																	"bold",
															}}
														>
															Address
														</Typography>
														<SearchAddress
															setFullAddress={(
																address
															) =>
																setValue(
																	"fullAddress",
																	address,
																	{
																		shouldValidate: true,
																	}
																)
															}
														/>
														<TextField
															label="Apt, Suite, building, floor, etc"
															{...register(
																"apartment"
															)}
															error={
																!!errors.apartment
															}
															helperText={
																errors.apartment
																	?.message
															}
															size="small"
															InputLabelProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
															inputProps={{
																sx: {
																	fontSize:
																		"12px",
																	fontWeight:
																		"bold",
																},
															}}
														/>
														<Button
															variant="contained"
															color="success"
															sx={{
																color: "white",
															}}
															onClick={handleSubmit(
																handleSaveNewAddress
															)}
														>
															Save new address
														</Button>
													</Box>
												)}
											</Box>

											<Box
												sx={{
													display: "flex",
													flexDirection: "column",
													gap: "10px",
												}}
											>
												<Typography
													variant="body1"
													component="h2"
													sx={{ fontWeight: "bold" }}
												>
													Delivery method
												</Typography>
												<RadioGroup
													sx={{
														padding: hideOnMd ? "5px 10px 0px" : "5px 50px 10px 50px",
													}}
													aria-label="delivery method"
													name="delivery method"
													value={deliveryMethodsIdChoice}
													onChange={(event) => setDeliveryMethodsIdChoice(event.target.value)}
												>
													{deliveryMethods
														.filter((method) => {
															if (method.name === "Free Shipping" || method.cost === 0) {
																return subTotal / 100 >= 150;
															}
															return true;
														})
														.map((option) => (
															<FormControlLabel
																key={option.id}
																value={
																	option.id
																}
																control={
																	<Radio />
																}
																label={`${
																	option.name
																}: $${
																	option.cost /
																	100
																}`}
															/>
														)
													)}
												</RadioGroup>
											</Box>
										</>
									)}
								</FormControl>
								<div style={{ marginTop: "20px" }}>
									<PaymentForm
										applicationId="sq0idp-SbRowbUZPmuBmrq722MP2g"
										locationId="L2SGRZEVRW0BC"
										cardTokenizeResponseReceived={
											handlePaymentResponse
										}
									>
										<CreditCard />
									</PaymentForm>
								</div>
							</DialogContent>
						</Dialog>
					</div>
				</ThemeProvider>
			) : (
				<div className="w-full text-center">
					<h3>Your cart is empty!</h3>
				</div>
			)}
		</>
	);
}
