import Image from "next/image";
import * as React from 'react';
import { useState, useRef, useCallback } from "react";
import { IconButton, Typography, TextField, Box } from '@mui/material';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import makeApiRequest from "@/libs/makeApiRequest";
import toast from "react-hot-toast";
import { getCartItemPrice } from "@/libs/calculations";

const commonStyle = {
    fontWeight: "500",
    lineHeight: "1.57",
    fontSize: "0.875rem",
    color: "rgb(17, 25, 39)",
};

export default function CardOrder({ orderItem, onDelete, taxRate, index, updateOrder, updateProductComment }) {
    const [quantity, setQuantity] = useState(orderItem.quantity);
    const [manualQuantity, setManualQuantity] = useState(orderItem.quantity);

    const costRef = useRef(Math.ceil(getCartItemPrice(orderItem)) * orderItem.quantity)

    const cost = costRef.current;

    const updateComment = (id, comment) => {
        updateProductComment(id, comment)
    }

    const deleteFromCart = async (id, cost) => {
        try {
            await makeApiRequest("/api/deleteOrderItem", { id });
            onDelete(index)
        } catch (error) {
            toast.error(error.message);
        }
    }

    const onSubmit = (data) => {
        handleSaveProductComment(orderItem.id, data);
    };

    const quantityChange = useCallback(async (id, newQuantity, orderItem) => {
        try {
            if (newQuantity >= 1) {
                await makeApiRequest("/api/editOrderItem", { id, quantity: newQuantity });

                const oldCost = parseFloat(costRef.current)
                const newCost = getCartItemPrice(orderItem) * newQuantity

                updateOrder(id, newQuantity);

                costRef.current = newCost;

                setManualQuantity(newQuantity);
                setQuantity(newQuantity);
            }
        } catch (error) {
            toast.error(error.message);
        }
    }, [costRef]);

    const handleManualQuantityChange = (event) => {
        const newManualQuantity = event.target.value;
        setManualQuantity(newManualQuantity);
        setQuantity(newManualQuantity);
    };

    const handleManualQuantityBlur = () => {
        const newQuantity = parseInt(manualQuantity, 10);
        if (!isNaN(newQuantity) && newQuantity >= 1) {
            quantityChange(orderItem.id, newQuantity, orderItem, taxRate);
        }
    };

    return (
        <div className="flex flex-col justify-between gap-2 rounded-lg p-3">
            <div className="flex flex-col lg:flex-row justify-between gap-4">
                <div className="flex gap-2 flex-col lg:flex-row lg:w-full">
                    <Box sx={{ display: 'flex', alignItems: 'center', position: 'relative', height: '200px', width: '100%', borderRadius: '10px', maxWidth: '250px' }}>
                        <Image loading="lazy" layout="fill" objectFit="contain" src={orderItem.product.image} alt={orderItem.product.name} className="rounded-lg" />
                    </Box>
                    <div className="flex flex-col gap-4 p-4 justify-between">
                        <div className="flex gap-4 flex-col">
                            <Typography variant="h3" component="h2" sx={{ fontSize: '24px' }}>
                                {orderItem.product.name}
                            </Typography>
                            <Typography variant="body1" component="p" sx={{ fontSize: '14px' }}>
                                {orderItem.product.description}
                            </Typography>
                        </div>
                        <div className="flex gap-2">
                            <Typography variant="body1" component="h6">
                                w: <Typography variant="span" component="span" sx={{ fontWeight: '600' }}>{orderItem.width}</Typography>
                                ″
                            </Typography>
                            <Typography variant="body1" component="h6">
                                h: <Typography variant="span" component="span" sx={{ fontWeight: '600' }}>{orderItem.height}</Typography>
                                ″
                            </Typography>

                        </div>
                    </div>
                </div>
                <div className="flex flex-col p-4 justify-between gap-2">
                    <div className="flex  justify-between items-center">
                        <Typography variant="body1" component="h6">
                            $ <Typography variant="span" component="span" sx={{ fontWeight: '500' }}>{(cost / 100).toFixed(2)}</Typography>
                        </Typography>

                        <IconButton onClick={() => deleteFromCart(orderItem.id, cost)}>
                            <DeleteOutlineOutlinedIcon />
                        </IconButton>
                    </div>

                    <div className="flex justify-between items-center border rounded-xl">
                        <IconButton onClick={() => quantityChange(orderItem.id, quantity - 1, orderItem, taxRate)}>
                            <RemoveIcon />
                        </IconButton>
                        <input
                            type="number"
                            value={manualQuantity}
                            onChange={handleManualQuantityChange}
                            onBlur={handleManualQuantityBlur}
                            onKeyDown={(e) => e.key === 'Enter' && handleManualQuantityBlur()}
                            className="w-16 text-center border-none outline-none focus:ring-0"
                        />
                        <IconButton onClick={() => quantityChange(orderItem.id, quantity + 1, orderItem, taxRate)}>
                            <AddIcon />
                        </IconButton>
                    </div>
                </div>
            </div>
            <div className="flex gap-3 p-4">
                <TextField
                    fullWidth
                    multiline
                    label="Your Comment..."
                    rows={3}
                    onChange={(event) => updateComment(orderItem.id, event.target.value)}
                />
            </div>
        </div>
    )
}
