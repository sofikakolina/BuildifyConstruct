// CartItems.js
import CartOrder from "./CartOrder";

function CartItems({
  orderItems,
  updateOrder,
  onDelete,
  updateProductComment,
  taxRate,
}) {
  return (
    <div className="flex flex-col my-4 mx-2 gap-5 shadow-2xl rounded-lg md:col-span-3">
      {orderItems.map((orderItem) => (
        <CartOrder
          key={orderItem.id}
          orderItem={orderItem}
          onDelete={onDelete}
          taxRate={taxRate}
          index={orderItem.id}
          updateOrder={updateOrder}
          updateProductComment={updateProductComment}
        />
      ))}
    </div>
  );
}

export default CartItems;
