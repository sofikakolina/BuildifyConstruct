import { Button } from "@mui/material";
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';

export default function SidebarCartMobile({totalCost}){
    
    return(
        <div className="md:hidden w-full flex justify-center items-center p-4">
            <div className="flex flex-col justify-center gap-4 w-full rounded-2xl bg-white p-3">
            <h2 className='text-lg font-bold'>Order Summary</h2>
            <div  className="flex flex-col gap-3">
                <div className="flex justify-between items-center">
                    <h4 className="text-sm">Sub Total</h4>
                    <h5 className="text-sm font-medium">$ <span>{totalCost}</span></h5>
                </div>
                <div className="flex justify-between items-center">
                    <h4 className="text-sm">Discount</h4>
                    <h5 className="text-sm font-medium">$ <span>0</span></h5>
                </div>
                <div className="flex justify-between items-center">
                    <h4 className="text-sm">Taxes</h4>
                    <h5 className="text-sm font-medium">$ <span>0</span></h5>
                </div>
                <div className="flex justify-between items-center">
                    <h4 className="text-sm">Shipping</h4>
                    <h5 className="text-sm font-medium"><span>Free</span></h5>
                </div>
            </div>
            <div className='flex justify-between'>
                <h2 className='text-xl font-bold'>Total</h2>
                <div className='flex items-center'>
                    <AttachMoneyIcon sx={{color:"#F69220"}}/>
                    <h3 className='text-xl text-primary font-bold'>{totalCost}</h3>
                </div>
            </div>
            <Button variant="contained" sx={{bgcolor:"#F69220", fontSize:"20px", color:"white", borderRadius:"10px"}}>Check Out</Button>

        </div>
        </div>
    )
}