import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import { Button } from '@mui/material';

const commonStyle = {
    fontWeight: "500",
    lineHeight: "1.57",
    fontSize: "0.875rem",
    color: "rgb(17, 25, 39)",
  };

export default function SidebarCart({subTotal, totalCost, taxes}){
    return(
        <div className="flex flex-col justify-center gap-4 m-2 mx-4 w-full">
            <h2 className='text-xl font-bold'>Order Summary</h2>
            <div  style={{ ...commonStyle }} className="flex flex-col gap-3">
                <div className="flex justify-between">
                    <h4>Sub Total</h4>
                    <div className='flex items-center'>
                        $
                        <h3>{(subTotal/100).toFixed(2)}</h3>
                    </div>
                </div>

                <div className="flex justify-between">
                    <h4>Taxes</h4>
                    <div className='flex items-center'>
                        $
                        <h3>{taxes.toFixed(2)}</h3>
                    </div>
                </div>
            </div>
            <div className='flex justify-between'>
                <h2 className='text-xl font-bold'>Total</h2>
                <div className='flex items-center'>
                    <AttachMoneyIcon sx={{color:"#F69220"}}/>
                    <h3 className='text-xl text-primary font-bold'>{totalCost}</h3>
                </div>
            </div>
            <Button variant="contained" sx={{bgcolor:"#F69220", fontSize:"20px", color:"white", borderRadius:"10px"}}>Check Out</Button>

        </div>
    )
}