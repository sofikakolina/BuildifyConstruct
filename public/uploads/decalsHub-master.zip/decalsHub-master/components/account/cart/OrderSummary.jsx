// OrderSummary.js
import { Button } from "@mui/material";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";

function OrderSummary({
  subTotal,
  taxes,
  total,
  handleOpenCheckoutModal,
  hideOnMd,
}) {
  return (
    <div
      className={`${
        hideOnMd
          ? "flex md:hidden w-full justify-center items-center p-4"
          : "hidden md:flex my-4 mx-2 shadow-2xl rounded-lg h-[300px]"
      }`}
    >
      <div className="flex flex-col justify-center gap-4 w-full rounded-2xl bg-white p-3">
        <h2 className="text-lg font-bold">Order Summary</h2>
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <h4 className="text-sm">Sub Total</h4>
            <h5 className="text-sm font-medium">
              $ {(subTotal / 100).toFixed(2)}
            </h5>
          </div>
          <div className="flex justify-between items-center">
            <h4 className="text-sm">Taxes</h4>
            <h5 className="text-sm font-medium">
              $ {(taxes / 100).toFixed(2)}
            </h5>
          </div>
        </div>
        <div className="flex justify-between">
          <h2 className="text-xl font-bold">Total</h2>
          <div className="flex items-center">
            <AttachMoneyIcon sx={{ color: "#F69220" }} />
            <h3 className="text-xl text-primary font-bold">
              {(total / 100).toFixed(2)}
            </h3>
          </div>
        </div>
        <Button
          onClick={handleOpenCheckoutModal}
          variant="contained"
          sx={{
            bgcolor: "#F69220",
            fontSize: "20px",
            color: "white",
            borderRadius: "10px",
          }}
        >
          Check Out
        </Button>
      </div>
    </div>
  );
}

export default OrderSummary;
