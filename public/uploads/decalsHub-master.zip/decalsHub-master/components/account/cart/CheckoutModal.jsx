// CheckoutModal.js
import {
	Dialog,
	DialogTitle,
	DialogContent,
	FormControl,
	FormLabel,
	RadioGroup,
	FormControlLabel,
	Radio,
	IconButton,
	Alert,
	Box,
	Typography,
	TextField,
	Button,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { PaymentForm, CreditCard } from "react-square-web-payments-sdk";
import SearchAddress from "./address/SearchAddress";

function CheckoutModal({
	isCheckoutModalOpen,
	handleCloseCheckoutModal,
	formError,
	hideOnMd,
	shippingMethod,
	handleShippingChange,
	addresses,
	addressIdChoice,
	setAddressIdChoice, // Добавьте эту строку
	handleAddressChange,
	shipTo,
	setShipTo,
	phoneShip,
	setPhoneShip,
	shipToCompany,
	setShipToCompany,
	registerPayment,
	paymentErrors,
	fullAddress,
	setFullAddress,
	apartment,
	setApartment,
	register,
	errors,
	handleSubmit,
	handleChangeAddress,
	handleDeleteAddress,
	showNewAddressForm,
	setShowNewAddressForm,
	handleSaveNewAddress,
	deliveryMethods,
	deliveryMethodsIdChoice,
	setDeliveryMethodsIdChoice,
	handlePaymentResponse,
	dialogContentRef,
}) {
	return (
		<Dialog
			sx={{
				"& .MuiDialog-paper": {
					borderRadius: "16px",
					padding: hideOnMd ? 0 : "20px",
					width: "fit-content",
					maxWidth: "none",
				},
			}}
			open={isCheckoutModalOpen}
			onClose={handleCloseCheckoutModal}
		>
			<DialogTitle
				sx={{
					display: "flex",
					justifyContent: "space-between",
					alignItems: "center",
				}}
			>
				Checkout
				<IconButton
					onClick={handleCloseCheckoutModal}
					aria-label="close"
				>
					<CloseIcon />
				</IconButton>
			</DialogTitle>
			<DialogContent ref={dialogContentRef}>
				{formError && (
					<Alert sx={{ mb: "20px" }} severity="error">
						{formError}
					</Alert>
				)}
				<FormControl component="fieldset" sx={{ width: "100%" }}>
					<FormLabel
						component="legend"
						sx={{
							marginBottom: "20px",
							fontWeight: "bold",
						}}
					>
						Shipping Method
					</FormLabel>
					<RadioGroup
						aria-label="shipping-method"
						name="shipping-method-group"
						value={shippingMethod}
						onChange={handleShippingChange}
					>
						{["Pickup", "Delivery"].map((option) => (
							<FormControlLabel
								key={option}
								value={option}
								control={<Radio />}
								label={option}
								sx={{
									".MuiTypography-root": {
										fontWeight: "medium",
									},
								}}
							/>
						))}
					</RadioGroup>

					{shippingMethod === "Delivery" && (
						<>
							{/* Выбор адреса и форма добавления нового адреса */}
							<Box
								sx={{
									display: "flex",
									flexDirection: "column",
									gap: "10px",
									mb: "10px",
								}}
							>
								<RadioGroup
									sx={{
										padding: hideOnMd
											? "5px 10px 0px"
											: "5px 50px 10px 50px",
									}}
									aria-label="address"
									name="address"
									value={addressIdChoice}
									onChange={handleAddressChange}
								>
									{[
										...addresses.created,
										...addresses.loaded,
									].map((option) => {
										const formattedAddress = `
${option.firstName} ${option.lastName}
${option.street}${option.building ? " " + option.building : ""}
${option.apartment ? option.apartment + "\n" : ""}
${option.city}, ${option.state} ${option.zip}

`.trim();

										return (
											<FormControlLabel
												key={option.id}
												value={option.id}
												control={<Radio />}
												label={formattedAddress}
												sx={{
													fontSize: "12px",
													fontWeight: "bold",
												}}
											/>
										);
									})}
								</RadioGroup>
							</Box>
						</>
					)}
				</FormControl>
				<div style={{ marginTop: "20px" }}>
					<PaymentForm
						applicationId="sq0idp-SbRowbUZPmuBmrq722MP2g"
						locationId="L2SGRZEVRW0BC"
						cardTokenizeResponseReceived={handlePaymentResponse}
					>
						<CreditCard />
					</PaymentForm>
				</div>
			</DialogContent>
		</Dialog>
	);
}

export default CheckoutModal;
