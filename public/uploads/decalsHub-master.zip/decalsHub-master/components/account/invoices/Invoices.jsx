'use client'
import * as React from 'react';
import { useState, useEffect } from 'react';
import { TablePagination } from "@mui/material"
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import { CircularProgress } from "@mui/material"
import TableContainer from '@mui/material/TableContainer';
import { TableRow, TableCell, Typography } from "@mui/material";
import Paper from '@mui/material/Paper';
import ReceiptOutlinedIcon from '@mui/icons-material/ReceiptOutlined';
import BeenhereIcon from '@mui/icons-material/Beenhere';
import WatchLaterOutlinedIcon from '@mui/icons-material/WatchLaterOutlined';
import Invoice from './Invoice';
import ResultInvoice from './ResultInvoice';
import makeApiRequest from "@/libs/makeApiRequest"
import toast from 'react-hot-toast';

export default function Invoices({ userId, company }) {
  const [invoices, setInvoices] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [statusInvoices, setStatusInvoices] = useState({});
  const [page, setPage] = useState(0)
  const [size, setSize] = useState(10)

  const statusColors = {
    PendingPayment: {
      backgroundColor: "rgba(181, 71, 8, 0.12)",
      color: "rgb(181, 71, 8)",
    },
    Paid: {
      backgroundColor: "rgba(16, 185, 129, 0.12)",
      color: "rgb(16, 185, 129)",
    },
    Design: {
      backgroundColor: "rgba(0, 123, 255, 0.12)",
      color: "rgb(0, 123, 255)",
    },
    Proofing: {
      backgroundColor: "rgba(23, 162, 184, 0.12)",
      color: "rgb(23, 162, 184)",
    },
    Prepress: {
      backgroundColor: "rgba(108, 117, 125, 0.12)",
      color: "rgb(108, 117, 125)",
    },
    Production: {
      backgroundColor: "rgba(148, 0, 211, 0.12)", // Фиолетовый цвет для Processed
      color: "rgb(148, 0, 211)",
    },
    Hold: {
      backgroundColor: "rgba(255, 40, 0, 0.12)",
      color: "rgb(255, 40, 0)",
    },
    Complete: {
      backgroundColor: "rgba(64, 224, 208, 0.12)",
      color: "rgb(64, 224, 208)",
    },
    Delivered: {
      backgroundColor: "rgba(64, 224, 208, 0.12)",
      color: "rgb(64, 224, 208)",
    },
    Cancelled: {
      backgroundColor: "rgba(255, 40, 0, 0.12)",
      color: "rgb(255, 40, 0)",
    },
  };
  
  useEffect(() => {
    (async () => {
      try {
        const { invoices, total } = await makeApiRequest("/api/getInvoices", { userId, page, size });
        const statusInvoices = {};
        invoices.forEach((invoice) => {
          const status = invoice.order.status;
          const totalResult = invoice.order.payment.amount
          if (!statusInvoices[status]) {
            statusInvoices[status] = { name: status, totalResult: 0, quantity: 0 };
          }
          statusInvoices[status].totalResult += totalResult;
          statusInvoices[status].quantity += 1;
        });
        setTotal(total);
        setInvoices(invoices);
        setStatusInvoices(statusInvoices);
        setLoading(false);
      } catch (error) {toast.error(error.message)}
    })();
  }, [page, size, userId]);

  return (
    <div className='flex flex-col gap-10 m-4'>
      {loading ? (
        <div className="w-full h-full flex items-center justify-center text-center">
          <CircularProgress />
        </div>
      ) : (total ? (
        <>
          <div className='md:flex grid grid-cols-1 md:flex-wrap justify-center gap-3 md:gap-5 lg:gap-5 xl:gap-5'>
            {Object.values(statusInvoices).map((statusInvoice) => (
              <ResultInvoice
                key={statusInvoice.name}
                Icon={statusInvoice.name === "Paid" ? BeenhereIcon : statusInvoice.name === "PendingPayment" ? ReceiptOutlinedIcon : WatchLaterOutlinedIcon}
                name={statusInvoice.name}
                amount={(statusInvoice.totalResult/100)}
                count={statusInvoice.quantity}
                backgroundRes={statusColors[statusInvoice.name].backgroundColor}
                colorRes={statusColors[statusInvoice.name].color}
              />
            ))}
          </div>
          <div className='flex flex-col gap-5'>
            <h3 style={{ color: "rgb(108, 115, 127)", fontWeight: "700", fontSize: "1.0417rem" }}>All({total})</h3>
            <TableContainer component={Paper}>
              <Table sx={{ minWidth: 650 }}>
                <TableBody>
                  {invoices.map((invoice) => (
                    <Invoice
                      key={invoice.id}
                      userId={userId}
                      invoice={invoice}
                      company={company}
                      backgroundColorInvoice={statusColors[invoice.order.status].backgroundColor}
                      colorInvoiceStatus={statusColors[invoice.order.status].color}
                    />
                  ))}
                  <TableRow>
                    <TableCell colSpan={6} align="right">
                      <TablePagination
                        count={total}
                        rowsPerPage={size}
                        page={page}
                        onPageChange={(event, newPage) => setPage(newPage)}
                        onRowsPerPageChange={(event) => { setSize(event.target.value); setPage(0) }}
                        component="div"
                        rowsPerPageOptions={[10, 20, 30, 40]}
                      />
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </>
      ) : (
        <div>
          <Typography color="primary" variant="h4">All invoices</Typography>
          <div className='w-full text-center'>
            <h3>You don't have any invoices!</h3>
          </div>
        </div>
      )
      )}
    </div>
  );
}
