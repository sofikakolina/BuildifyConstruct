'use client'
import TableHead from '@mui/material/TableHead';
import TableContainer from '@mui/material/TableContainer';
import Table from '@mui/material/Table';
import TableRow from '@mui/material/TableRow';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import { Box } from '@mui/material';
import Image from 'next/image';
import Link from 'next/link';
import { useEffect } from 'react';
import { useState } from 'react';
import Logo from '@/public/assets/Adwrap.png';
import DynamicInvoiceTableOrder from "./DynamicInvoiceTableOrder";
import GeneratePdf from "./GeneratePdf";
import makeApiRequest from '@/libs/makeApiRequest';
import { CircularProgress } from "@mui/material"
import { getOrderSubtotal, getOrderItemPrice, getOrderTax } from '@/libs/calculations';
import toast from 'react-hot-toast';

const commonStyle = {
  fontWeight: "500",
  lineHeight: "1.57",
  fontSize: "0.875rem",
  color: "rgb(17, 25, 39)",
};

const commonStyleMin = {
  fontWeight: "400",
  lineHeight: "1.57",
  fontSize: "0.875rem",
  color: "rgb(108, 115, 127)",
};

export default function DynamicInvoice({ orderId }) {
  const [order, setOrder] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    (async () => {
      try {
        const { order } = await makeApiRequest(
          "/api/getOrder",
          { id: orderId }
        );
        setOrder(order)
        setLoading(false)
      } catch (error) {
        toast.error(error.message);
      }
    })();
  }, []);

  return (
    <>
      {loading ? (
        <div className="w-full h-full flex items-center justify-center text-center">
          <CircularProgress />
        </div>
      ) : (
        <TableContainer sx={{ padding: "12px" }}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <GeneratePdf order={order} />
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableBody>
              <TableRow>
                <TableCell colSpan={4}>
                  <Box sx={{ width: '200px' }}> <Image priority src={Logo} width={2810} height={804} alt="Logo" /></Box>
                </TableCell>
                <TableCell colSpan={2} align="right" style={{ ...commonStyle }}>
                  <h3 style={{}} className="text-3xl">INVOICE-{order.invoice.id}</h3>
                </TableCell>
              </TableRow>
              <TableRow>
                <TableCell colSpan={4}>
                  <h3 style={{ ...commonStyle }}>Invoice from</h3>
                  <div className='flex flex-col gap-3'>
                    <div className="flex flex-col">
                      <h4 style={{ ...commonStyleMin }}>AdWrap Graphics INC</h4>
                      <h4 style={{ ...commonStyleMin }}>1337, Industrial Dr Itasca, Illinois 60143</h4>
                      <h4 style={{ ...commonStyleMin }}>info@adwrapinc.com</h4>
                      <h4 style={{ ...commonStyleMin }}>(847) 637-0009</h4>
                    </div>
                  </div>
                </TableCell>
                <TableCell colSpan={4}>
                  <h3 style={{ ...commonStyle }}>Invoice to</h3>
                  <div className='flex flex-col gap-3'>
                    <div className="flex flex-col">
                      <h4 style={{ ...commonStyleMin }}>{order.invoice.company}</h4>
                      {
                        order.invoice?.adresses?.map(adress =>
                          <div>
                            <h4 style={{ ...commonStyleMin }}>{adress}</h4>
                          </div>
                        )
                      }
                      <h4 style={{ ...commonStyleMin }}>{order.invoice.email}</h4>
                      {
                        order.invoice?.phones?.map(phone =>
                          <div>
                            <h4 style={{ ...commonStyleMin }}>{phone.number}</h4>
                          </div>
                        )
                      }
                    </div>
                    <div>
                      <Link href="https://adwrapgraphics.com/" style={{ ...commonStyleMin }}>adwrapgraphics.com</Link>
                    </div>
                  </div>
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell colSpan={4}>
                  <h3 style={{ ...commonStyle }}>Date of issue</h3>
                  <p style={{ ...commonStyleMin }}>{order.invoice.createdAt}</p>
                </TableCell>
                <TableCell align="left" style={{ ...commonStyle }}>
                  <h3 style={{ ...commonStyle }}>Due date</h3>
                  <p style={{ ...commonStyleMin }}>{order.invoice.dueDate}</p>
                </TableCell>
                <TableCell align="right" style={{ ...commonStyle }}>
                  <h3 style={{ color: order.invoice.status === 'Paid' ? 'rgb(16, 185, 129)' : 'rgb(181, 71, 8)' }} className="text-3xl">{order.invoice.status}</h3>
                </TableCell>
              </TableRow>

            </TableBody>
          </Table>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell colSpan={3} style={{ ...commonStyle }}>Description</TableCell>
            <TableCell align="left" style={{ ...commonStyle }}>QTY</TableCell>
            <TableCell align="right" style={{ ...commonStyle }}>Unit price</TableCell>
            <TableCell align="right" style={{ ...commonStyle }}>Total</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {order.orderItems.map((orderItem) => (
            <DynamicInvoiceTableOrder
              unitPrice={getOrderItemPrice(orderItem)}
              key={orderItem.id}
              orderItem={orderItem}
            />
          ))}
        </TableBody>
        <TableHead>
          <TableRow>
              <TableCell colSpan={4}></TableCell>
              <TableCell align="right" style={{ ...commonStyle }}>Subtotal</TableCell>
              <TableCell align="right" style={{ ...commonStyle }}>${(getOrderSubtotal(order) / 100).toFixed(2)}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell colSpan={4}></TableCell>
            <TableCell align="right" style={{ ...commonStyle }}>{order.deliveryMethod?.name ? order.deliveryMethod.name : "Pickup"}</TableCell>
            <TableCell align="right" style={{ ...commonStyle }}>${((order.deliveryMethod?.cost ? order.deliveryMethod.cost : 0) / 100).toFixed(2)}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell colSpan={4}></TableCell>
            <TableCell align="right" style={{ ...commonStyle }}>Taxes</TableCell>
            <TableCell align="right" style={{ ...commonStyle }}>${(getOrderTax(order) / 100).toFixed(2)}</TableCell>
          </TableRow>
          <TableRow>
              <TableCell colSpan={4}></TableCell>
              <TableCell align="right" style={{ ...commonStyle }}>Total</TableCell>
              <TableCell align="right" style={{ ...commonStyle }}>${(order.payment.amount/100).toFixed(2)}</TableCell>
          </TableRow>
        </TableHead>
      </Table>
    </TableContainer>)
  }
    </>
)}