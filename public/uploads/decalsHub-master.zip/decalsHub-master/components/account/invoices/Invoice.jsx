import Link from "next/link";
import { TableRow, TableCell, IconButton } from "@mui/material";
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';

const commonStyle = {
  fontWeight: "500",
  lineHeight: "1.57",
  fontSize: "0.875rem",
  color: "rgb(17, 25, 39)",
};

const statusColors = {
  PendingPayment: {
    backgroundColor: "rgba(181, 71, 8, 0.12)",
    color: "rgb(181, 71, 8)",
  },
  Paid: {
    backgroundColor: "rgba(16, 185, 129, 0.12)",
    color: "rgb(16, 185, 129)",
  },
  Design: {
    backgroundColor: "rgba(0, 123, 255, 0.12)",
    color: "rgb(0, 123, 255)",
  },
  Proofing: {
    backgroundColor: "rgba(23, 162, 184, 0.12)",
    color: "rgb(23, 162, 184)",
  },
  Prepress: {
    backgroundColor: "rgba(108, 117, 125, 0.12)",
    color: "rgb(108, 117, 125)",
  },
  Production: {
    backgroundColor: "rgba(148, 0, 211, 0.12)",
    color: "rgb(148, 0, 211)",
  },
  Hold: {
    backgroundColor: "rgba(255, 40, 0, 0.12)",
    color: "rgb(255, 40, 0)",
  },
  Complete: {
    backgroundColor: "rgba(64, 224, 208, 0.12)",
    color: "rgb(64, 224, 208)",
  },
  Delivered: {
    backgroundColor: "rgba(64, 224, 208, 0.12)",
    color: "rgb(64, 224, 208)",
  },
  Cancelled: {
    backgroundColor: "rgba(255, 40, 0, 0.12)",
    color: "rgb(255, 40, 0)",
  },
};

export default function Invoice({ userId, invoice, company,  }) {
  const { backgroundColor, color } = statusColors[invoice.order.status] || {};

  return (
    <TableRow
      key={company}
      sx={{ '&:last-child td, &:last-child th': { border: 0 }, }}
    >
      <TableCell align="left" style={{ ...commonStyle }}>INV-{invoice.id}</TableCell>
      <TableCell align="left" style={{ ...commonStyle }}>
        ${invoice.order.payment.amount/100}
      </TableCell>
      <TableCell align="left">
        <div className="flex flex-col">
          <h5 style={{ ...commonStyle }}>Issued</h5>
          <span>{invoice.createdAt}</span>
        </div>
      </TableCell>
      <TableCell align="left">
        <div className="flex flex-col">
          <h5 style={{ ...commonStyle }}>Due</h5>
          <span>{invoice.dueDate}</span>
        </div>
      </TableCell>
      <TableCell align="left">
        <span style={{  backgroundColor,color, fontWeight: "600", lineHeight: "2", fontSize: "0.75rem" }} className='rounded-[12px] inline-flex color uppercase px-3'>{invoice.order.status}</span>
      </TableCell>
      <TableCell align="right">
        <Link
          href={{
            pathname: `/account/invoices/${invoice.name}`,
            query: {
              orderId: invoice.order.id
            }
          }}
        >
          <IconButton>
            <ArrowForwardIcon />
          </IconButton>
        </Link>
      </TableCell>
    </TableRow>
  );
}
