"use client";
import React, { useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { signOut } from "next-auth/react";
import {
	AppBar,
	Toolbar,
	IconButton,
	Typography,
	Menu,
	MenuItem,
	Divider,
	Box,
	ListItemIcon,
	Avatar,
	Drawer,
	List,
	ListItem,
	ListItemText,
	Collapse,
	ButtonBase,
} from "@mui/material";
import NotificationsIcon from "@mui/icons-material/Notifications";
import PersonOutlineOutlinedIcon from "@mui/icons-material/PersonOutlineOutlined";
import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";
import CreditCardRoundedIcon from "@mui/icons-material/CreditCardRounded";
import MenuIcon from "@mui/icons-material/Menu";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import Image from "next/image";
import Logo from "@/public/assets/logo.svg";
import { menuItems as sidebarMenuItems } from "./menu/menuItems";
import theme from "@/theme";

const drawerWidth = 280;

const DashboardNavigation = ({ session }) => {
	const [anchorEl, setAnchorEl] = useState(null);
	const [open, setOpen] = useState({});
	const [mobileOpen, setMobileOpen] = useState(false);
	const router = useRouter();
	const isMenuOpen = Boolean(anchorEl);
	const pathname = usePathname();

	// Обработчики событий для DashboardHeader
	const handleProfileMenuOpen = (event) => {
		setAnchorEl(event.currentTarget);
	};

	const handleMenuClose = () => {
		setAnchorEl(null);
	};

	const handleLogout = async () => {
		try {
			await signOut({ callbackUrl: "/auth/login", redirect: false });
			window.location.href = "/auth/login";
		} catch (error) {
			console.error("Ошибка при выходе:", error);
		}
	};

	const handleDrawerToggle = () => {
		setMobileOpen(!mobileOpen);
	};

	const handleSidebarMenuClick = (menu) => {
		setOpen((prevOpen) => ({ ...prevOpen, [menu]: !prevOpen[menu] }));
	};

	const navigateTo = (path) => {
		router.push(path);
	};

	const renderMenuItems = (menuItems, paddingLeft = 0) =>
		menuItems.map((item) => (
			<React.Fragment key={item.text}>
				<ButtonBase
					sx={{ my: "2px" }}
					onClick={() =>
						item.subMenu
							? handleSidebarMenuClick(item.text)
							: navigateTo(item.path)
					}
					style={getButtonStyle(item.path)}
				>
					<ListItem>
						<ListItemIcon style={{ color: "white" }}>
							{item.icon}
						</ListItemIcon>
						<ListItemText primary={item.text} />
						{item.subMenu &&
							(isSidebarMenuOpen(item.text) ? (
								<ExpandLessIcon style={{ color: "white" }} />
							) : (
								<ExpandMoreIcon style={{ color: "white" }} />
							))}
					</ListItem>
				</ButtonBase>
				{item.subMenu && (
					<Collapse
						in={isSidebarMenuOpen(item.text)}
						timeout="auto"
						unmountOnExit
					>
						<List component="div" disablePadding>
							{renderSubMenuItems(item.subMenu, paddingLeft + 4)}
						</List>
					</Collapse>
				)}
			</React.Fragment>
		));

	const isSidebarMenuOpen = (menu) => Boolean(open[menu]);
	const getButtonStyle = (path) => ({
		width: "100%",
		justifyContent: "flex-start",
		backgroundColor: pathname === path ? "#F69220" : "",
		borderRadius: "10px",
	});

	const renderSubMenuItems = (subMenu, paddingLeft) =>
		subMenu.map((item) => (
			<ButtonBase
				sx={{ my: "2px" }}
				onClick={() => navigateTo(item.path)}
				key={item.text}
				style={getButtonStyle(item.path)}
			>
				<ListItem sx={{ pl: paddingLeft }}>
					<ListItemIcon style={{ color: "white" }}>
						{item.icon}
					</ListItemIcon>
					<ListItemText primary={item.text} />
				</ListItem>
			</ButtonBase>
		));

	// DashboardHeader menuItems
	const dashboardMenuItems = [
		{
			title: "Profile",
			icon: <PersonOutlineOutlinedIcon />,
			link: "/account/profile",
		},
	];

	const menuId = "primary-search-account-menu";
	const pageTitle = pathname || "Home";

	return (
		<Box sx={{ display: "flex" }}>
			<AppBar
				position="fixed"
				sx={{
					width: { sm: `calc(100% - ${drawerWidth}px)` },
					ml: { sm: `${drawerWidth}px` },
				}}
			>
				<Toolbar
					sx={{
						justifyContent: "space-between",
						"@media (min-width: 600px)": {
							justifyContent: "flex-end",
						},
					}}
				>
					<IconButton
						color="inherit"
						aria-label="open drawer"
						edge="start"
						onClick={handleDrawerToggle}
						sx={{ mr: 2, display: { sm: "none" } }}
					>
						<MenuIcon />
					</IconButton>
					<div>
						<IconButton color="inherit">
							<NotificationsIcon />
						</IconButton>
						<IconButton
							edge="end"
							aria-label="account of current user"
							aria-controls={menuId}
							aria-haspopup="true"
							onClick={handleProfileMenuOpen}
							color="inherit"
						>
							<Avatar
								src={session?.user?.image}
								alt={session?.user?.name || "U"}
							>
								{!session?.user?.image &&
									(session?.user?.name?.charAt(0) || "U")}
							</Avatar>
						</IconButton>
					</div>
				</Toolbar>
			</AppBar>

			<Box
				component="nav"
				sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
				aria-label="mailbox folders"
			>
				<Drawer
					variant="temporary"
					open={mobileOpen}
					onClose={handleDrawerToggle}
					ModalProps={{ keepMounted: true }} // Better open performance on mobile.
					sx={{
						display: { xs: "block", sm: "none" },
						"& .MuiDrawer-paper": {
							boxSizing: "border-box",
							width: drawerWidth,
							backgroundColor:
								theme.customColors.drawerBackground,
							color: theme.customColors.drawerTextColor,
						},
					}}
				>
					<Box
						sx={{
							p: 4,
							display: "flex",
							flexDirection: "column",
							alignItems: "center",
						}}
					>
						<Image
							priority
							src={Logo}
							height={29}
							width={207}
							alt="Logo"
						/>
					</Box>
					<Divider />
					<List>{renderMenuItems(sidebarMenuItems)}</List>
				</Drawer>
				<Drawer
					variant="permanent"
					sx={{
						display: { xs: "none", sm: "block" },
						"& .MuiDrawer-paper": {
							boxSizing: "border-box",
							width: drawerWidth,
							backgroundColor:
								theme.customColors.drawerBackground,
							color: theme.customColors.drawerTextColor,
						},
					}}
					open
				>
					<Box
						sx={{
							p: 4,
							display: "flex",
							flexDirection: "column",
							alignItems: "center",
						}}
					>
						<Image
							priority
							src={Logo}
							height={29}
							width={207}
							alt="Logo"
						/>
					</Box>
					<Divider />
					<List>{renderMenuItems(sidebarMenuItems)}</List>
				</Drawer>
			</Box>
			<Menu
				anchorEl={anchorEl}
				anchorOrigin={{
					vertical: "top",
					horizontal: "right",
				}}
				id={menuId}
				keepMounted
				transformOrigin={{
					vertical: "top",
					horizontal: "right",
				}}
				open={isMenuOpen}
				onClose={handleMenuClose}
			>
				<Box px={2} py={1}>
					<Typography variant="subtitle1" noWrap>
						{session?.user?.name || "Username"}
					</Typography>
					<Typography
						variant="caption"
						noWrap
						style={{ color: "grey" }}
					>
						{session?.user?.email || "user@example.com"}
					</Typography>
				</Box>
				<Divider />
				{dashboardMenuItems.map((item) => (
					<MenuItem
						key={item.title}
						onClick={() => {
							handleMenuClose();
							if (item.link) router.push(item.link);
						}}
					>
						<ListItemIcon>{item.icon}</ListItemIcon>
						<Typography variant="body2">{item.title}</Typography>
					</MenuItem>
				))}
				<Divider />
				<MenuItem onClick={handleLogout}>
					<Typography variant="body2" align="center" width={"100%"}>
						Logout
					</Typography>
				</MenuItem>
			</Menu>
		</Box>
	);
};

export default DashboardNavigation;
