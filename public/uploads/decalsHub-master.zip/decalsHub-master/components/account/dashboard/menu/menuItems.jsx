// menuItems.js
import LocalMallIcon from '@mui/icons-material/LocalMall';
import ShoppingCartCheckoutIcon from '@mui/icons-material/ShoppingCartCheckout';
import CreditScoreIcon from '@mui/icons-material/CreditScore';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import ProductionQuantityLimitsIcon from '@mui/icons-material/ProductionQuantityLimits';

export const menuItems = [
	
	{
		text: 'Products',
		icon: <LocalMallIcon />,
		path: '/account/products'
	},
	{
		text: 'Orders',
		icon: <ShoppingCartCheckoutIcon />,
		path: '/account/orders'
	},
	{
		text: 'Invoices',
		icon: <CreditScoreIcon />,
		path: '/account/invoices'
	},
	{
		text: 'Cart',
		icon: <ShoppingCartIcon />,
		path: '/account/cart'
	},
	{
		text: 'Product Request',
		icon: <ProductionQuantityLimitsIcon />,
		path: '/account/productRequest'
	},
];