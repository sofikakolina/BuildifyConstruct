import React from 'react';
import {
  Accordion, AccordionSummary, AccordionDetails, Typography, Box, Chip, Grid, Button, useTheme
} from '@mui/material';
import { format } from 'date-fns';
import Link from 'next/link';
import { styled } from '@mui/material/styles';
import { getOrderTotal, getOrderItemPrice } from '@/libs/calculations';
const CustomAccordion = styled(Accordion)(({ theme }) => ({
  marginBottom: theme.spacing(2),
  border: `1px solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[1],
}));

const CustomAccordionSummary = styled(AccordionSummary)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  borderBottom: `1px solid ${theme.palette.divider}`,
}));

const CustomAccordionDetails = styled(AccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
}));
const statusColors = {
  PendingPayment: {
    backgroundColor: "rgba(181, 71, 8, 0.12)",
    color: "rgb(181, 71, 8)",
  },
  Paid: {
    backgroundColor: "rgba(16, 185, 129, 0.12)",
    color: "rgb(16, 185, 129)",
  },
  Design: {
    backgroundColor: "rgba(0, 123, 255, 0.12)",
    color: "rgb(0, 123, 255)",
  },
  Proofing: {
    backgroundColor: "rgba(23, 162, 184, 0.12)",
    color: "rgb(23, 162, 184)",
  },
  Prepress: {
    backgroundColor: "rgba(108, 117, 125, 0.12)",
    color: "rgb(108, 117, 125)",
  },
  Production: {
    backgroundColor: "rgba(148, 0, 211, 0.12)", // Фиолетовый цвет для Processed
    color: "rgb(148, 0, 211)",
  },
  Hold: {
    backgroundColor: "rgba(255, 40, 0, 0.12)",
    color: "rgb(255, 40, 0)",
  },
  Complete: {
    backgroundColor: "rgba(64, 224, 208, 0.12)",
    color: "rgb(64, 224, 208)",
  },
  Delivered: {
    backgroundColor: "rgba(64, 224, 208, 0.12)",
    color: "rgb(64, 224, 208)",
  },
  Cancelled: {
    backgroundColor: "rgba(255, 40, 0, 0.12)",
    color: "rgb(255, 40, 0)",
  },
};

export default function OrderAccordion({ order }) {
  const theme = useTheme();
  const formatDate = (timestamp) => format(new Date(timestamp), "MMM dd, yyyy");
  
  return (
    <div style={{border:"1px solid #F69220"}} className='flex flex-col rounded-lg p-3'>
        <Typography sx={{ fontWeight: 'bold', color: theme.palette.text.primary }}>ORDER-{order.id}</Typography>
        <div className='flex flex-col gap-3'>
          <Typography gutterBottom variant="body2" sx={{ color: theme.palette.text.secondary }}>
            Total cost: <strong>${order.payment?.amount/100}</strong>
          </Typography>
          <div className='flex flex-col gap-4'>
            {order.orderItems.map((item, index) => (
              <Grid item xs={12} sm={6} key={index} sx={{display:"flex", flexDirection:"column", gap: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }} className="gap-1 md:gap-3">
                  <img src={item.image} width={80} height={80} alt={item.name} style={{ borderRadius: theme.shape.borderRadius }} layout="intrinsic" />
                  <Box sx={{ flexGrow: 1 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 'medium', color: theme.palette.text.primary }}>
                      {item.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">Total: ${getOrderItemPrice(item) * item.quantity / 100}</Typography>
                    <Typography variant="body2" color="text.secondary">Quantity: {item.quantity}</Typography>
                    <Typography variant="body2" color="text.secondary">Size: {item.width} x {item.height}</Typography>
                  </Box>
                  <Chip label={order.status} sx={{
                    ml: 'auto',
                    color: statusColors[order.status]?.color,
                    bgcolor: statusColors[order.status]?.backgroundColor,
                    fontWeight: 'bold',
                  }} />
                </Box>
              </Grid>
            ))}
          </div>
          {/* ВОТ СЮДА В БЛОК НИЖЕ ЕБАШИШЬ PROOF */}
          {
            (order.proofs) && (
              order.proofs.map(proof => (
                <div className='flex flex-col items-end sm:items-start pt-3'>
                  <Link href={`/account/orders/proof/${proof.id}`}>
                    <Button variant="contained" sx={{bgcolor:"#F69220", fontSize:"15px", color:"white", borderRadius:"10px",padding:"5px 30px 5px 30px" }}>
                      Proof-{proof.id}
                    </Button>
                  </Link>
                  <Typography variant="body2" sx={{ mt: 2, color: theme.palette.text.secondary }}>
                    Date: {formatDate(order?.payment?.createdAt || order.createdAt)}
                  </Typography>
                </div>
              ))
            )  
          }
        </div>
    </div>
  );
};