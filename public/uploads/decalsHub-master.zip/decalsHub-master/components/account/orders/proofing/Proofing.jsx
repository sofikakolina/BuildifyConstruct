"use client";
import React, { useState, useEffect } from "react";
import {
  Box, Typography, Paper, Grid, Button, TextField, Stepper, StepLabel,
  Avatar, StepContent, Step, colors, CircularProgress
} from "@mui/material";
import ThumbUpOffAltIcon from '@mui/icons-material/ThumbUpOffAlt';
import ThumbDownOffAltIcon from '@mui/icons-material/ThumbDownOffAlt';
import DownloadIcon from '@mui/icons-material/Download';
import toast from "react-hot-toast";
import makeApiRequest from "@/libs/makeApiRequest";

export default function Proofing({ session, params }) {
	const [proof, setProof] = useState(null)
	const [message, setMessage] = useState("");
	const [messages, setMessages] = useState([]);

	const handleRequestChanges = async () => {
		if(!message.trim()) return
		const {proofMessage} = await makeApiRequest("/api/createProofMessage", {
			proofId: proof.id, userId: session.user.id, content: message
		}).catch(error => toast.error(error.message))
		setMessages(prevMessages => [...prevMessages, proofMessage]);
		setMessage("");
	};

  	const handleApproval = () => toast.promise(
		makeApiRequest("/api/editProof", {id: proof.id, accepted: true}),
		{
			loading: "Proofing... Wait a sec!",
			success: "Done!",
			error: error => error.message
		}
	)


	const handleDownload = (url) => {
		if (!url) return;
		window.open(url, "_blank");
	  };
	  

  	useEffect(() => {
		makeApiRequest("/api/getProof", { id: params.id })
			.then(({ proof }) => {
				makeApiRequest("/api/editProof", {id: proof.id, views: proof.views + 1})
					.catch(error => toast.error(error.message))
				setProof(proof)
				setMessages(proof.messages)
			})
			.catch(error => toast.error(error.message))
	}, [])

	return !proof ? (
		<div className="h-full w-full flex justify-center items-center">
			<CircularProgress />
		</div>
	) : (
		<Paper square={false} elevation={1} sx={{ padding: 4 }}>
			<Box sx={{ mb: 4 }}>
				<Typography color="primary" variant="h2" sx={{ fontSize: "32px" }}>{"Proofing"}</Typography>
			</Box>
			<Box>
				<form className="grid grid-cols-1 lg:grid-cols-2 gap-10">
				<Grid container spacing={2} sx={{ mb: 4 }}>
					<Grid item xs={12} md={12}>
					<Paper elevation={1} sx={{ padding: 3 }}>
						{proof.assets.map((img, index) => (
						<img key={index} className="w-full" src={img.src} alt="Proof Image" />
						))}
					</Paper>
					</Grid>
				</Grid>
				<Box sx={{ display: "flex", flexDirection: "column" }}>

					<Paper elevation={1} sx={{ padding: 3, display: "flex", flexDirection: "column", gap: "10px" }}>
					<Button sx={{
						background: "rgb(255, 255, 255)",
						maxWidth: "200px",
						border: "1px solid rgb(212, 217, 222)",
						color: "rgb(15, 20, 26)",
						display: "flex",
						alignItems: "center",
						gap: "4px"
					}}   onClick={() => handleDownload(proof.assets[0]?.src)}>
						<DownloadIcon />
						Download Proof
					</Button>
					<Typography color="" variant="h6" sx={{ fontSize: "18px" }}>{"If everything looks right:"}</Typography>
					<Button
						sx={{
						background: "rgb(38, 192, 90)",
						maxWidth: "200px",
						border: "1px solid rgb(34, 171, 80)",
						color: "white",
						display: "flex",
						alignItems: "center",
						gap: "4px",
						'&:hover': {
							background: "rgb(12 151 59)"
						},
						}}
						onClick={() => handleApproval()}
					>
						<ThumbUpOffAltIcon />
						Approve
					</Button>
					<Typography color="" variant="h6" sx={{ fontSize: "18px" }}>{"Otherwise, specify and request changes:"}</Typography>
					<Stepper orientation="vertical">
						{messages.map((message, index) => (
						<Step key={index} active={true}>
							<StepLabel
							StepIconComponent={() => message.user.image ? (
								<Avatar alt={message.user.name} src={message.user.image} />
							) : (
								<Avatar sx={{ bgcolor: colors.grey[500] }}>{message.user.name[0]}</Avatar>
							)}
							>
							<Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
								<Typography sx={{ fontWeight: 'bold' }} variant="body1">{message.user.name}</Typography> 
								<Typography sx={{ color: 'grey' }} variant="caption">{message.date}</Typography>
							</Box>
							</StepLabel>
							<StepContent sx={{ pl: 4 }}>
							<Typography variant='body1' sx={{ fontWeight: 'medium' }}>{message.content}</Typography>
							</StepContent>
						</Step>
						))}
					</Stepper>
					<TextField
						id="textarea-product"
						value={message}
						onChange={(event) => setMessage(event.target.value)}
						label="* Message"
						multiline
						sx={{ width: "100%" }}
						rows={4}
					/>
					<Button
						sx={{ background: "rgb(255, 236, 236)", maxWidth: "200px", border: "1px solid rgb(255, 211, 211)", color: "red", display: "flex", alignItems: "center", gap: "4px" }}
						onClick={handleRequestChanges}
						disabled={!message}
					>
						<ThumbDownOffAltIcon />
						Request Changes
					</Button>
					</Paper>
				</Box>
				</form>
			</Box>
		</Paper>
	)
}