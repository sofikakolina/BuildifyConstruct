// 'use client' directive is used for client-side components in Next.js 13+
'use client';
import React, { useState, useEffect } from 'react';
import { Box, Typography, Paper, LinearProgress, TableContainer, Table, TableBody, Pagination } from '@mui/material';
import Order from './Order';
import { styled } from '@mui/material/styles';

const OrdersContainer = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: theme.shape.borderRadius,
  boxShadow: theme.shadows[1],
}));

const HeaderTypography = styled(Typography)(({ theme }) => ({
  fontWeight: 600,
  fontSize: '1.2rem',
  color: theme.palette.primary.main,
  marginBottom: theme.spacing(2),
}));

export default function Orders({ userId }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1); // Pagination starts from 1 for user interface
  const [size, setSize] = useState(10);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/getOrders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ userId, page: page - 1, size }),
    })
      .then(response => {
        if (!response.ok) throw new Error("Network response was not okay");
        return response.json();
      })
      .then(data => {
        const { orders, total } = data;
        setOrders(orders.filter(order => order.status !== 'PendingPayment'));
        setTotal(total);
      })
      .catch(error => console.error("Error fetching data:", error))
      .finally(() => setLoading(false));
  }, [userId, page, size]);

  const handleChangePage = (event, value) => setPage(value);

  return (
    <OrdersContainer elevation={3}>
      {loading && <LinearProgress />}
      <HeaderTypography>All Orders</HeaderTypography>
      {!loading && orders.length > 0 ? (
        <>
          <div className='flex flex-col gap-5'>
                {orders.map(order => (
                  <Order key={order.id} order={order} status={order.status} />
                ))}
          </div>
          <Pagination
            count={Math.ceil(total / size)}
            page={page}
            onChange={handleChangePage}
            color="primary"
            showFirstButton
            showLastButton
            sx={{ mt: 2, display: 'flex', justifyContent: 'center' }}
          />
        </>
      ) : (
        <Typography textAlign="center" color="text.secondary">
          You don't have any orders!
        </Typography>
      )}
    </OrdersContainer>
  );
}
