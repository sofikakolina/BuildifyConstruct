import * as React from 'react';
import { useState, useCallback } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import { IconButton, Button, CardActionArea, CardActions, Box } from '@mui/material';
import makeApiRequest from "@/libs/makeApiRequest";
import { getProductPrice } from '@/libs/calculations';
import toast from "react-hot-toast"
import Image from 'next/image';

export default function CardProducts({ product, width, height, activeOrderId, activeOrder, productFlag, orderItemStart }) {
  const [orderItem, setOrderItem] = useState(orderItemStart)
  // console.log(orderItem)
  const [flag, setFlag] = useState(!productFlag)
  const amount = (getProductPrice(product) / 100).toFixed(2)
  const [quantity, setQuantity] = useState(1);
  const [quantityProduct, setQuantityProduct] = useState(orderItem.quantity ? orderItem.quantity : 0)
  // console.log(quantityStart)
  const [manualQuantity, setManualQuantity] = useState(1);
  
  const addToCart = async (orderId, productId, quantity, width, height, activeOrder, orderItem, manualQuantity, productName) => {
    try {
      if (flag) {
        const data = await makeApiRequest("/api/createOrderItem", { orderId, productId, quantity, width, height });
        toast.success(`The ${productName} has been added to the cart in the amount of ${data.orderItem.quantity}`)
        setQuantity(1)
        setManualQuantity(1)
        setQuantityProduct(data.orderItem.quantity)
        setOrderItem(data.orderItem)
        setFlag(!flag);
      } else {
        const quantityResult = quantityProduct + manualQuantity
        await makeApiRequest("/api/editOrderItem", { id: orderItem.id, quantity: quantityResult });
        toast.success(`The ${productName} has been added to the cart in the amount of ${manualQuantity}`)
        setQuantity(1)
        setManualQuantity(1)
        setQuantityProduct(quantityResult)
      }
    } catch (error) {
      toast.error(`${error.message}`)
    }
  };

  const quantityChange = useCallback(async (id, newQuantity, orderItem) => {
        if (newQuantity >= 1) {
            setManualQuantity(newQuantity);
            setQuantity(newQuantity);
        }
}, []);

const handleManualQuantityChange = (event) => {
    const newManualQuantity = parseInt(event.target.value) <= 0 ? 1 : parseInt(event.target.value)
    setManualQuantity(newManualQuantity);
    setQuantity(newManualQuantity);
};

const handleManualQuantityBlur = () => {
    const newQuantity = parseInt(manualQuantity, 10);
    if (!isNaN(newQuantity) && newQuantity >= 1) {
        quantityChange(orderItem.id, newQuantity, orderItem);
    }
};

  return (
    <Card sx={{
      borderRadius: "20px",
      border: "1px solid #e0e0e0",
      boxShadow: "0px 8px 20px rgba(0, 0, 0, 0.06)",
      transition: "transform 0.3s ease-in-out",
      "&:hover": {
        transform: "translateY(-10px)",
        boxShadow: "0px 16px 40px rgba(0, 0, 0, 0.1)",
      },
      display: "flex"
    }}>
      <CardActionArea sx={{ borderRadius: "20px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
        <Box sx={{ position: 'relative', height: '200px', width: '100%' }}>
          <Image className="object-contain" loading="lazy" fill={true} src={product.image} alt={product.name} />
        </Box>
        <CardContent sx={{
          display: "flex",
          flexDirection: "column",
          gap: "20px",
          padding: "24px",
        }}>
          <Typography gutterBottom variant="h6" component="div" sx={{ fontWeight: "bold" }}>
            {product.name}
            <Typography variant="body2" color="text.secondary" sx={{ mt: "4px" }}>
              {product.description}
            </Typography>
          </Typography>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="body2" color="text.secondary" sx={{ display: "flex", flexDirection: "column", gap: "8px" }}>
              <span>Dimensions</span>
              <span className='text-lg'>{`${width}″ × ${height}″`}</span>
            </Typography>   
            <div className="flex justify-between items-center border rounded-xl">
              <IconButton onClick={() => quantityChange(orderItem.id, quantity - 1, orderItem)}>
                  <RemoveIcon />
              </IconButton>
              <input
                  type="number"
                  value={parseInt(manualQuantity)}
                  onChange={handleManualQuantityChange}
                  onBlur={handleManualQuantityBlur}
                  onKeyDown={(e) => e.key === 'Enter' && handleManualQuantityBlur()}
                  className="w-16 text-center border-none outline-none focus:ring-0"
              />
              <IconButton onClick={() => quantityChange(orderItem.id, quantity + 1, orderItem)}>
                  <AddIcon />
              </IconButton>
          </div>
          </Box>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Button
              sx={{
                borderRadius: "8px",
                backgroundColor: '#F69220',
                color: 'white',
                padding: "8px 16px",
                '&:hover': {
                  backgroundColor: "#F69220",
                },
                textTransform: "none",
              }}
              onClick={() => addToCart(activeOrderId, product.id, quantity+quantityProduct, width, height, activeOrder, orderItem, manualQuantity, product.name)}
            >
              Add to Cart
            </Button>
              
          
            <Typography variant="h6" component="div" sx={{ fontWeight: "medium" }}>
              ${amount * (quantity ? quantity : 1)}
            </Typography>
          </Box>
        </CardContent>
      </CardActionArea>
    </Card>


  )
}