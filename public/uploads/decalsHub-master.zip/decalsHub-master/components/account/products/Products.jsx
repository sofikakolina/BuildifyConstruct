'use client'
import { useEffect, useState } from "react";
import { TablePagination } from "@mui/material";
import CardProducts from "./CardProducts";
import makeApiRequest from "@/libs/makeApiRequest";
import { CircularProgress } from "@mui/material"
import toast from "react-hot-toast";

const commonStyleHead = {
  fontWeight: "700",
  lineHeight: "1.2",
  fontSize: "1.38rem",
};

export default function Products() {
  const [activeOrder, setActiveOrder] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(12);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    (async () => {
      try {
        const { products: newProducts, total: newTotal } = await makeApiRequest(
          "/api/getProducts",
          { page, size }
        );
        setProducts(products);
        const { order: activeOrder } = await makeApiRequest("/api/getCart");
        setActiveOrder(activeOrder);
        setProducts(newProducts);
        setTotal(newTotal)
        setLoading(false);
      } catch (error) {
        toast.error(error.message);
      }
    })();
  }, [page, size]);

  return (
    <>
      {loading ? (
        <div className="w-full h-full flex items-center justify-center text-center">
          <CircularProgress />
        </div>
      ) : (
        <div className="m-4 flex flex-col gap-8">
          <div className="flex flex-col gap-3">
            <h3 style={{ ...commonStyleHead }}>All Products</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-5">
              {products.map((template) => (
                <CardProducts
                  product={template}
                  key={template.id}
                  width={template.width}
                  height={template.height}
                  activeOrderId={activeOrder.id}
                  activeOrder={activeOrder}
                  productFlag={(activeOrder.orderItems &&
                    activeOrder.orderItems.some((item) => item.product.id === template.id))}
                  discount={template.discount}
                  orderItemStart={activeOrder.orderItems && activeOrder.orderItems.reduce((acc, item) => (
                    item.product.id === template.id ? item : acc ), 0)}

                />
              ))}
            </div>
            <div className="w-full">
              <TablePagination
                component="div"
                count={total}
                page={page}
                onPageChange={(_event, newPage) => setPage(newPage)}
                rowsPerPage={size}
                onRowsPerPageChange={(event) => {
                  setSize(parseInt(event.target.value, 10))
                  setPage(0)
                }}
                rowsPerPageOptions={[12, 16, 20, 40]}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
