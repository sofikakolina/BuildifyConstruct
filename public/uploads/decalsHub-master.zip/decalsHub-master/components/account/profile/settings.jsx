'use client';

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as Yup from "yup";
import toast from "react-hot-toast";
import { updateUser } from "@/app/actions/updateUser";
import { signOut, useSession } from "next-auth/react";

export default function EditProfile({ user }) {
  const { data: session, update: updateSession } = useSession();
  const [isNameLoading, setIsNameLoading] = useState(false);
  const [isPasswordLoading, setIsPasswordLoading] = useState(false);

  // Валидация для имени
  const nameSchema = Yup.object().shape({
    name: Yup.string()
      .required("Name is required")
      .min(2, "Name must be at least 2 characters"),
  });

  const passwordSchema = Yup.object().shape({
    password: Yup.string()
      .required("Password is required")
      .min(6, "Password must be at least 6 characters"),
  });

  const {
    register: nameRegister,
    handleSubmit: handleNameSubmit,
    formState: { errors: nameErrors },
    reset: resetNameForm,
  } = useForm({
    resolver: yupResolver(nameSchema),
    defaultValues: { name: user.name },
  });

  const {
    register: passwordRegister,
    handleSubmit: handlePasswordSubmit,
    formState: { errors: passwordErrors },
    reset: resetPasswordForm,
  } = useForm({
    resolver: yupResolver(passwordSchema),
  });

  // Синхронизация имени с обновленной сессией
  useEffect(() => {
    if (session?.user?.name) {
      resetNameForm({ name: session.user.name });
    }
  }, [session?.user?.name, resetNameForm]);

  // Функция для изменения имени
  const onSubmitName = async ({ name }) => {
    setIsNameLoading(true);
    try {
      await updateUser({ userId: user.id, name });
      toast.success("Name updated successfully!");
      resetNameForm();

      // Обновление сессии
      await updateSession({
        ...session,
        user: { ...session.user, name },
      });
    } catch (error) {
      toast.error(error.message || "Failed to update name.");
    } finally {
      setIsNameLoading(false);
    }
  };

  // Функция для изменения пароля
  const onSubmitPassword = async ({ password }) => {
    setIsPasswordLoading(true);
    try {
      await updateUser({ userId: user.id, password });
      toast.success("Password updated successfully!");
      resetPasswordForm();
    } catch (error) {
      toast.error(error.message || "Failed to update password.");
    } finally {
      setIsPasswordLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto space-y-8">
      {/* Форма изменения имени */}
      <form
        onSubmit={handleNameSubmit(onSubmitName)}
        className="p-4 bg-white shadow-md rounded-md space-y-4"
      >
        <h2 className="text-lg font-semibold">Update Name</h2>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Name
          </label>
          <input
            type="text"
            {...nameRegister("name")}
            className={`mt-1 block w-full px-4 py-2 border rounded-md ${
              nameErrors.name ? "border-red-500" : "border-gray-300"
            }`}
          />
          {nameErrors.name && (
            <p className="text-red-500 text-sm mt-1">{nameErrors.name.message}</p>
          )}
        </div>
        <button
          type="submit"
          disabled={isNameLoading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
        >
          {isNameLoading ? "Updating..." : "Update Name"}
        </button>
      </form>

      {/* Форма изменения пароля */}
      <form
        onSubmit={handlePasswordSubmit(onSubmitPassword)}
        className="p-4 bg-white shadow-md rounded-md space-y-4"
      >
        <h2 className="text-lg font-semibold">Update Password</h2>
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Password
          </label>
          <input
            type="password"
            {...passwordRegister("password")}
            className={`mt-1 block w-full px-4 py-2 border rounded-md ${
              passwordErrors.password ? "border-red-500" : "border-gray-300"
            }`}
          />
          {passwordErrors.password && (
            <p className="text-red-500 text-sm mt-1">
              {passwordErrors.password.message}
            </p>
          )}
        </div>
        <button
          type="submit"
          disabled={isPasswordLoading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
        >
          {isPasswordLoading ? "Updating..." : "Update Password"}
        </button>
      </form>
    </div>
  );
}
