import {
    Body,
    Container,
    Head,
    Heading,
    Html,
    Preview,
    Text,
    Link,
    Hr,
    Img,
  } from '@react-email/components';
  import * as React from 'react';
  
  const ProofCreateEmail = ({ name, link, proofDetails, imageUrl }) => {
    const isImage = /\.(jpeg|jpg|png|gif)$/i.test(imageUrl); // Проверяем, является ли файл изображением
  
    return (
      <Html>
        <Head />
        <Preview>New Proof Created - Review Required</Preview>
        <Body style={main}>
          <Container style={container}>
            <Heading style={h1}>New Proof Created for Review</Heading>
            <Text style={text}>Hello {name},</Text>
            <Text style={text}>
              A new proof has been created and is awaiting your review. Here are the details:
            </Text>
            <Text style={detailsText}>{proofDetails}</Text>
            <Hr style={divider} />
            <Text style={text}>
              Please review the file below and click the link to view or take further actions:
            </Text>
            {isImage ? (
              <Img src={imageUrl} alt="Proof Image" style={imageStyle} />
            ) : (
              <Text style={text}>
                <a href={imageUrl} style={button} target="_blank" rel="noopener noreferrer">
                  View the uploaded file
                </a>
              </Text>
            )}
            <Link href={link} style={button}>
              View Proof
            </Link>
            <Hr style={divider} />
            <Text style={footerText}>
              If you have any questions, please feel free to reach out to our support team.
            </Text>
          </Container>
        </Body>
      </Html>
    );
  };
  
  
  export default ProofCreateEmail;
  
  const main = {
    backgroundColor: '#f5f5f5',
    margin: '0 auto',
    fontFamily:
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  };
  
  const container = {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    margin: '40px auto',
    padding: '40px 20px',
    maxWidth: '600px',
    textAlign: 'center',
  };
  
  const h1 = {
    color: '#333333',
    fontSize: '22px',
    fontWeight: '600',
    lineHeight: '32px',
    margin: '0 0 24px',
  };
  
  const text = {
    color: '#666666',
    fontSize: '16px',
    lineHeight: '24px',
    margin: '0 0 20px',
  };
  
  const detailsText = {
    color: '#333333',
    fontSize: '16px',
    fontWeight: '400',
    lineHeight: '24px',
    backgroundColor: '#f0f0f0',
    padding: '15px',
    borderRadius: '5px',
    margin: '0 0 20px',
    textAlign: 'left',
  };
  
  const divider = {
    border: 'none',
    borderTop: '1px solid #dddddd',
    margin: '20px 0',
  };
  
  const button = {
    display: 'inline-block',
    padding: '12px 24px',
    backgroundColor: '#28a745',
    color: '#ffffff',
    fontSize: '16px',
    fontWeight: 'bold',
    textDecoration: 'none',
    borderRadius: '6px',
    margin: '20px 0',
  };
  
  const imageStyle = {
    maxWidth: '100%',
    height: 'auto',
    borderRadius: '8px',
    margin: '20px 0',
  };
  
  const footerText = {
    color: '#999999',
    fontSize: '14px',
    lineHeight: '20px',
  };
  