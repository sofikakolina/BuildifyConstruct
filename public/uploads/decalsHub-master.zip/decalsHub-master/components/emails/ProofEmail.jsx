import {
    Body,
    Container,
    Head,
    Heading,
    Html,
    Preview,
    Text,
    Link,
    Hr,
  } from '@react-email/components';
  import * as React from 'react';
  
  const ProofEmail = ({ name, link, message }) => (
    <Html>
      <Head />
      <Preview>Approval Request - Action Required</Preview>
      <Body style={main}>
        <Container style={container}>
          <Heading style={h1}>Approval Needed for Your Request</Heading>
          <Text style={text}>
            Hi {name},
          </Text>
          <Text style={messageText}>
            {message}
          </Text>
          <Hr style={divider} />
          <Text style={text}>
            Please review the details above and approve your request by clicking the link below:
          </Text>
          <Link href={link} style={button}>
            Approve Request
          </Link>
          <Hr style={divider} />
          <Text style={footerText}>
            If you have any questions, please contact our support team.
          </Text>
        </Container>
      </Body>
    </Html>
  );
  
  export default ProofEmail;
  
  const main = {
    backgroundColor: '#f9f9f9',
    margin: '0 auto',
    fontFamily:
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  };
  
  const container = {
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
    margin: '40px auto',
    padding: '40px 20px',
    maxWidth: '600px',
    textAlign: 'center',
  };
  
  const h1 = {
    color: '#333333',
    fontSize: '22px',
    fontWeight: '600',
    lineHeight: '32px',
    margin: '0 0 24px',
  };
  
  const text = {
    color: '#666666',
    fontSize: '16px',
    lineHeight: '24px',
    margin: '0 0 20px',
  };
  
  const messageText = {
    color: '#333333',
    fontSize: '16px',
    fontWeight: '400',
    lineHeight: '24px',
    backgroundColor: '#f1f1f1',
    padding: '15px',
    borderRadius: '5px',
    margin: '0 0 20px',
    textAlign: 'left',
  };
  
  const divider = {
    border: 'none',
    borderTop: '1px solid #dddddd',
    margin: '20px 0',
  };
  
  const button = {
    display: 'inline-block',
    padding: '12px 24px',
    backgroundColor: '#007bff',
    color: '#ffffff',
    fontSize: '16px',
    fontWeight: 'bold',
    textDecoration: 'none',
    borderRadius: '6px',
    margin: '20px 0',
  };
  
  const footerText = {
    color: '#999999',
    fontSize: '14px',
    lineHeight: '20px',
  };
  