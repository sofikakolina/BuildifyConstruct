import React from 'react';
import { Html, Head, Body, Container, Heading, Text, Button } from '@react-email/components';

export const VerificationEmail = ({ verificationUrl, name }) => (
  <Html>
    <Head />
    <Body style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      <Container style={{ textAlign: 'center' }}>
        <Heading style={{ color: '#333', fontSize: '24px' }}>Verify Your Email</Heading>
        <Text style={{ margin: '20px 0', fontSize: '16px', color: '#555' }}>
          Hi {name},
        </Text>
        <Text style={{ margin: '20px 0', fontSize: '16px', color: '#555' }}>
          Click the button below to verify your email address:
        </Text>
        <Button
          href={verificationUrl}
          style={{
            backgroundColor: '#007bff',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '5px',
            textDecoration: 'none',
            fontSize: '16px',
          }}
        >
          Verify Email
        </Button>
        <Text style={{ marginTop: '20px', fontSize: '14px', color: '#999' }}>
          If you didn’t create an account with us, please ignore this email.
        </Text>
      </Container>
    </Body>
  </Html>
);
