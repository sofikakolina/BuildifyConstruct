import React from 'react';
import { Html } from '@react-email/html';
import { Container } from '@react-email/container';
import { Section } from '@react-email/section';
import { Text } from '@react-email/text';
import { Img } from '@react-email/img';
import { Button } from '@react-email/button';
import { getOrderItemPrice, getOrderTax } from "@/libs/calculations";

const formatCurrency = (amount) => `$${amount.toFixed(2)}`;

const StatusChangeEmail = ({ order, newStatus }) => {
  return (
    <Html>
      <Container style={styles.container}>
        <Section style={styles.headerSection}>
          <Text style={styles.header}>Order Completed</Text>
        </Section>
        <Section>
          <Text>Dear {order.user.name},</Text>
          <Text>Your order with ID {order.id} is now ready. The current status is: <strong>{newStatus}</strong></Text>
          <Text><strong>Order Details:</strong></Text>
          <ul style={styles.list}>
            <li><strong>Order ID:</strong> {order.id}</li>
            <li><strong>New Status:</strong> {newStatus}</li>
            <li><strong>Delivery Method:</strong> {order.invoice.address ? 'Delivery: ' + order.invoice.address : 'Pickup'}</li>
            <li><strong>Tax:</strong> ({order.invoice.taxRate}%): {formatCurrency(getOrderTax(order) / 100)}</li>
            <li><strong>Total:</strong> {formatCurrency(order.payment.amount / 100)}</li>
          </ul>
        </Section>
        <Section>
          <Text><strong>Items:</strong></Text>
          <ul style={styles.itemList}>
            {order.orderItems.map(item => (
              <li key={item.id} style={styles.item}>
                {item.image && <Img src={item.image} alt={item.name} style={styles.image} />}
                <div>
                  <Text style={styles.itemName}><strong>{item.name}</strong></Text>
                  <Text>Dimensions: w: {item.width} x h: {item.height}</Text>
                  <Text>Quantity: {item.quantity}</Text>
                  <Text>Price: {formatCurrency(getOrderItemPrice(item) * item.quantity / 100)}</Text>
                </div>
              </li>
            ))}
          </ul>
        </Section>
        <Section>
          <Text>Thank you for shopping with us!</Text>
          <Button href="https://decalshub.com/account/orders" style={styles.button}>
            View Order
          </Button>
        </Section>
      </Container>
    </Html>
  );
};

const styles = {
  container: {
    fontFamily: 'Arial, sans-serif',
    lineHeight: '1.6',
    color: '#333',
    maxWidth: '600px',
    margin: '0 auto',
    padding: '20px',
    border: '1px solid #ddd',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9'
  },
  headerSection: {
    backgroundColor: '#000',
    padding: '10px',
    borderRadius: '10px 10px 0 0',
  },
  header: {
    fontSize: '24px',
    color: '#fff',
    textAlign: 'center'
  },
  list: {
    listStyleType: 'none',
    padding: 0
  },
  itemList: {
    listStyleType: 'none',
    padding: 0,
    margin: 0
  },
  item: {
    borderBottom: '1px solid #ddd',
    padding: '10px 0',
    display: 'flex',
    alignItems: 'center'
  },
  image: {
    width: '50px',
    height: '50px',
    marginRight: '10px',
    objectFit: 'cover',
    borderRadius: '5px'
  },
  itemName: {
    margin: 0,
    padding: 0,
  },
  button: {
    background: "#000",
    color: "#fff",
    padding: "12px 20px",
    textDecoration: "none",
    display: "inline-block",
    marginTop: "20px",
    borderRadius: '5px'
  }
};

export default StatusChangeEmail;
