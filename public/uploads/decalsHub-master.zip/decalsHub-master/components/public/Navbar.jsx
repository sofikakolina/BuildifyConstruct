import React from 'react'

const Navbar = () => {
  return (
    <div>NavBar</div>
  )
}

export default Navbar