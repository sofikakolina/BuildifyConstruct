import { Resend } from "resend";
import { VerificationEmail } from "@/components/emails/VerifyEmail";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendVerificationEmail(email, name, token) {
  try {
    const verificationUrl = `${process.env.NEXT_PUBLIC_BASE_URL}/auth/verify-email?token=${token}`;

    await resend.emails.send({
      from: process.env.RESEND_FROM,
      to: email,
      subject: `Dear ${name}, please verify your email for DecasHub`,
      react: VerificationEmail({ verificationUrl, name }),
    });
    
  } catch (error) {
    console.error('Error sending email:', error);
    throw new Error('Failed to send verification email.');
  }
}
