import React from "react";
import { Html, Head, Preview, Body, Container, Heading, Text, Link } from "@react-email/components";



const ProductCreationEmail = ({ productName }) => {
  return (
    <Html>
      <Head />
      <Preview>Product created successfully on DecalsHub</Preview>
      <Body style={{ fontFamily: "Arial, sans-serif", backgroundColor: "#f9f9f9", padding: "20px" }}>
        <Container style={{ maxWidth: "600px", margin: "0 auto", backgroundColor: "#fff", padding: "20px", borderRadius: "8px" }}>
          <Heading style={{ color: "#333", marginBottom: "20px" }}>
            Great News! 🎉
          </Heading>
          <Text style={{ color: "#555", fontSize: "16px", lineHeight: "24px" }}>
            We've successfully created your product <strong>{productName}</strong> as per your approved artwork.
          </Text>
          <Text style={{ color: "#555", fontSize: "16px", lineHeight: "24px", marginTop: "20px" }}>
            You can now log in on <Link href="https://www.decalshub.com/auth/login">DecalsHub</Link> to place your order.
          </Text>
          <Text style={{ color: "#555", fontSize: "16px", lineHeight: "24px", marginTop: "20px" }}>
            Feel free to contact us if you need any help during the process.
          </Text>
          <Text style={{ color: "#999", fontSize: "14px", marginTop: "40px" }}>
            Thanks, <br />
            The DecalsHub Team
          </Text>
        </Container>
      </Body>
    </Html>
  );
};

export default ProductCreationEmail;
