import { useState } from 'react';

const useValidation = () => {
  const [errors, setErrors] = useState({});

  const validateLogin = (login, password) => {
    const tempErrors = {};
    tempErrors.login = login ? '' : 'This field is required';
    tempErrors.password = password ? '' : 'This field is required';

    // Проверка на email
    if (login.includes('@')) {
      tempErrors.login = /$^|.+@.+..+/.test(login) ? '' : 'Email is not valid';
    }

    setErrors(tempErrors);
    return Object.values(tempErrors).every((x) => x === '');
  };

  return { validateLogin, errors };
};

export default useValidation;
