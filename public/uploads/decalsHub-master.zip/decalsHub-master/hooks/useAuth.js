import { useState } from 'react';
import { signIn } from 'next-auth/react';

const useAuth = () => {
  const [error, setError] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  const login = async (username, userPassword) => {
    setError(null);
    setIsAuthenticated(false);
    setUser(null);
    const credentials = { login: username, password: userPassword };

    const response = await signIn('credentials', {
      ...credentials,
      redirect: false,
    });

    if (response.error) {
      setError(response.error);
    } else if (response.ok) {
      setIsAuthenticated(true);
      setUser(response.user);
    }
  };

  return {
    login, error, isAuthenticated, user,
  };
};

export default useAuth;
