// hooks/useFetch.js
import { useState, useCallback, useRef } from 'react';

const useFetch = () => {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const abortController = useRef(null);

  const fetchData = useCallback(async (url, method = 'GET', body = null, headers = {}) => {
    setIsLoading(true);
    abortController.current = new AbortController();
    const { signal } = abortController.current;

    try {
      const requestOptions = {
        method,
        headers: { 'Content-Type': 'application/json', ...headers },
        body: body ? JSON.stringify(body) : null,
        signal,
      };

      const response = await fetch(url, requestOptions);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const responseData = await response.json();
      setData(responseData);
    } catch (error) {
      if (error.name !== 'AbortError') {
        setError(error.message);
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  const cancelFetch = useCallback(() => {
    if (abortController.current) {
      abortController.current.abort();
    }
  }, []);

  return { data, error, isLoading, fetchData, cancelFetch };
};

export default useFetch;
