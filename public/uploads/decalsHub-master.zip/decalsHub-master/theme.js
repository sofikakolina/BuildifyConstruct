import { createTheme } from '@mui/material/styles';
import { Manrope } from 'next/font/google';
import { grey, blueGrey, white } from '@mui/material/colors';


const manrope = Manrope({
    subsets: ['latin'],
    weights: ['300', '500', '700']
});

const theme = createTheme({
    typography: {
        fontFamily: manrope,
        h1: {
            fontWeight: 500
        },
        h2: {
            fontWeight: 500
        },
        h3: {
            fontWeight: 500
        },
        h4: {
            fontWeight: 500
        },
        h5: {
            fontWeight: 500
        },
        h6: {
            fontWeight: 500
        },
        subtitle1: {
            fontWeight: 300
        },
        subtitle2: {
            fontWeight: 300
        },
        body1: {
            fontWeight: 300
        },
        body2: {
            fontWeight: 300
        }
    },
    palette: {
        primary: {
            main: '#F69220', // убедитесь, что это корректный HEX-код цвета
        },
        secondary: {
            main: '#005B96', // убедитесь, что это корректный HEX-код цвета
        },
        background: {
            default: '#F4F6F8',
            paper: '#FFFFFF',
            primary: grey[900],
        },
        text: {
            primary: grey[900],
            secondary: grey[600]
        }
    },
    customColors: {
        drawerBackground: blueGrey[900],
        drawerTextColor: grey[200],
        hoverBackground: '#F69220',
        activeListItemBackground: '#F69220'
    },
    customRadius: {
        buttonMedium: '8px'
    },
    components: {
        MuiTable: {
            styleOverrides: {
                root: {
                    minWidth: '750px',
                    borderRadius: '12px',
                    borderCollapse: 'separate',
                    borderSpacing: '0',
                    overflow: 'hidden',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.05)', // Softer shadow for a lighter feel
                    backgroundColor: '#ffffff', // Keeping the background white for cleanliness
                    '& thead': {
                        '& th': {
                            fontWeight: 500, // Slightly lighter weight for a modern look
                            color: '#606060', // Softened color for text
                            backgroundColor: '#f7f7f7', // Lighter header background for a subtle contrast
                            textTransform: 'none', // Removed uppercase for a more relaxed feel
                            letterSpacing: 'normal', // Normal letter spacing for readability
                            borderBottom: '1px solid #e0e0e0', // Lighter and thinner border
                            padding: '16px', // Slightly increased padding for spaciousness
                        },
                    },
                    '& tbody': {
                        '& tr': {
                            transition: 'background-color 0.3s',
                            '&:hover': {
                                backgroundColor: `rgba(0, 0, 0, 0.02)`, // Very light hover effect for subtlety
                            },
                        },
                        '& td': {
                            borderBottom: `1px solid #e0e0e0`, // Consistent with the header border
                            padding: '16px', // Consistent padding with the header for uniformity
                        },
                        '&:last-child td': {
                            borderBottom: 'none', // Remove the bottom border for the last row
                        },
                    },
                },
            },
        },
        MuiTableCell: {
            styleOverrides: {
                root: {
                    padding: '16px', // Unified padding with the rest of the table for consistency
                    borderBottom: `1px solid #e0e0e0`, // Light and subtle border
                },
                head: {
                    fontSize: '0.95rem', // Slightly larger for prominence
                    fontWeight: 500, // Consistency in font weight with the table header
                    color: '#606060', // Harmonized color palette
                },
                body: {
                    fontSize: '0.875rem', // Slightly larger for readability
                    color: '#606060', // Softened color for text for ease of reading
                },
            },
        },

        MuiAppBar: {
            styleOverrides: {
                root: {
                    backgroundColor: '#FFFFFF',
                    color: grey[800],
                    boxShadow: 'none'
                }
            }
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    borderRadius: '12px',
                    color: grey[700],
                    textTransform: 'none',
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                root: {
                    '&:hover': {
                        backgroundColor: grey[100],
                        borderRadius: '8px'
                    },
                    '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: grey[300],
                        borderWidth: '1px',
                        borderRadius: '8px'
                    },
                    '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: grey[400]
                    },
                    '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                        borderColor: '#F69220',
                        borderWidth: '2px'
                    },
                    '&.Mui-focused .MuiInputLabel-outlined': {
                        color: '#F69220'
                    }
                }
            }
        },
        MuiDrawer: {
            styleOverrides: {
                paper: {
                    backgroundColor: blueGrey[800],
                    color: grey[300]
                }
            }
        },
        MuiList: {
            styleOverrides: {
                root: {
                    padding: '8px',
                    backgroundColor: 'transparent'
                },
                item: {
                    borderRadius: '6px',
                    '&:hover': {
                        backgroundColor: grey[200]
                    }
                }
            }
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    boxShadow: 'none',
                    borderRadius: '8px',
                    backgroundColor: '#FFFFFF',
                    overflow: 'hidden'
                }
            },
            MuiCardContent: {
                styleOverrides: {
                    root: {
                        padding: '16px',
                        '&:last-child': {
                            paddingBottom: '16px'
                        }
                    }
                }
            },
            MuiAvatar: {
                styleOverrides: {
                    root: {
                        backgroundColor: grey[300],
                        color: grey[800]
                    }
                }
            }
        }
    }
});

export default theme;