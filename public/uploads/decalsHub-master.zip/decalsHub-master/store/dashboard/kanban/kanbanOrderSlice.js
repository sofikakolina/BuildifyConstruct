import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  kanbanOrderCart: [],
};

export const kanbanOrderCartSlice = createSlice({
  name: 'kanbanOrderCart',
  initialState,
  reducers: {
    addProduct: (state, action) => {
      state.kanbanOrderCart.push(action.payload);
    },
    removeProduct: (state, action) => {
      state.kanbanOrderCart = state.kanbanOrderCart.filter(product => product.id !== action.payload);
    },
  },
});

export const { addProduct, removeProduct } = productSlice.actions;

export default productSlice.reducer;
