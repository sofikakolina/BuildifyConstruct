'use client'
import { decrement, increment } from "./kanbanOrderSlice";
import { useDispatch, useSelector } from "react-redux";
import { store } from "./kanbanOrderCartStore";

export default function HowToUse () {

    const count = useSelector((store) => store.counter.value)
    const dispatch = useDispatch()

    return (

        <div className="flex gap-4">
        <button onClick={() => dispatch(decrement())}>decr</button>
        {count}
        <button onClick={() => dispatch(increment())}>incr</button>
        </div>
    );
}
