/** @type {import('next').NextConfig} */
const nextConfig = {
	reactStrictMode: false,
	experimental: {
		serverMinification: false,
	},
	images: {
		remotePatterns: [
		  {
			protocol: 'https',
			hostname: 'storage.googleapis.com',
			port: '', // Google Cloud Storage обычно использует стандартный HTTPS порт, оставьте пустым
			pathname: '/decalshub/**', // Укажите путь к вашему бакету и дальше
		  },
		],
	  },
};

module.exports = nextConfig;
