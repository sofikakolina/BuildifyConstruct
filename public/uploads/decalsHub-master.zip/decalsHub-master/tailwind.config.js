/** @type {import('tailwindcss').Config} */
const colors = require('tailwindcss/colors');

module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    container: {
      center: 'true',
      padding: {
        DEFAULT: '1rem',
        sm: '2rem',
        lg: '4rem',
        xl: '5rem',
        '2xl': '6rem',
      },
    },
    colors: {
      primary: {
        DEFAULT: '#F69220',
        light: '#F8A542',
        dark: '#E57C1D',
      },
      secondary: {
        DEFAULT: '#294751',
        light: '#3b5b65', // светлый оттенок
        dark: '#1e363d', // темный оттенок
      },
      black: colors.black,
      white: colors.white,
      gray: colors.slate,
      green: colors.emerald,
      purple: colors.violet,
      yellow: colors.amber,
      pink: colors.fuchsia,
      red: colors.red,
      blue: colors.blue,
      indigo: colors.indigo,
      transparent: "transparent"
    },
    fontFamily: {
      sans: ['Manrope', 'sans-serif'],
      serif: ['Jost', 'serif'],
    },

    extend: {
      backgroundImage: (theme) => ({
        'secondary-gradient': `linear-gradient(to right, ${theme(
          'colors.secondary.light',
        )}, ${theme('colors.secondary.DEFAULT')}, ${theme(
          'colors.secondary.dark',
        )})`,
      }),
    },
  },
  plugins: [],
};
