//  измененно
"use client";
import theme from "@/theme";
import { SessionProvider } from "next-auth/react";
import ThemeProvider from "@mui/material/styles/ThemeProvider";
import "@/styles/globals.css";
import { Manrope } from "next/font/google";
import { AppRouterCacheProvider } from "@mui/material-nextjs/v14-appRouter";
import { Toaster } from "react-hot-toast";
// redux-toolkit
import { store } from "../store/example/store";
import { Provider } from "react-redux";

const manrope = Manrope({
	subsets: ["latin"],
	weight: ["300", "500", "700"],
});

export default function RootLayout(props) {
	const { children } = props;
	return (
		<html lang="en">
			<Provider store={store}>
				<ThemeProvider theme={theme}>
					<SessionProvider>
						<body className={manrope.className + " h-full"}>
							<Toaster />
							<AppRouterCacheProvider>
								{children}
							</AppRouterCacheProvider>
						</body>
					</SessionProvider>
				</ThemeProvider>
			</Provider>
		</html>
	);
}
