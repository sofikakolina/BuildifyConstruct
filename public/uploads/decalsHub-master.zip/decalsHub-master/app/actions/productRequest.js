"use server";

import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import prisma from "@/libs/prisma";
import { Role } from "@prisma/client";
import Joi from "joi";

const validationSchema = Joi.object({
	proofId: Joi.number().integer().min(1).required(),
});

export async function getProductRequestById(proofId) {
	const session = await getServerSession(authOptions);

	if (!session || !session.user) {
		throw new Error("Not authorized");
	}

	const { error, value } = validationSchema.validate({ proofId });
	if (error) {
		throw new Error(error.details[0].message);
	}

	const productRequest = await prisma.productRequest.findUnique({
		where: { id: value.proofId },
		include: {
			images: true,
			user: true,
			proofs: {
				include: {
					assets: true,
					messages: {
						include: {
							user: true,
						},
					},
				},
			},
			stickerDetails: true, // Включаем детали стикеров
		},
	});

	if (!productRequest) {
		throw new Error("Product request not found");
	}

	if (
		productRequest.userId !== session.user.id &&
		session.user.role !== Role.Admin && session.user.role != Role.Designer
	) {
		throw new Error("Not authorized for action");
	}

	return productRequest;
}

/**
 * Получает количество запросов со статусом REQUESTED
 * @returns {Promise<number>} Количество запросов со статусом REQUESTED
 */
export async function getRequestedProductRequestsCount() {
	try {
		const count = await prisma.productRequest.count({
			where: {
				status: "REQUESTED", // Указываем фильтр по статусу
			},
		});
		return count;
	} catch (error) {
		console.error(
			"Error fetching requested product requests count:",
			error
		);
		return 0; // Возвращаем 0 в случае ошибки
	}
}
