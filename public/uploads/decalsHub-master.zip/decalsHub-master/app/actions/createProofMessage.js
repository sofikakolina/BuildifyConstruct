"use server";

import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import prisma from "@/libs/prisma";
import { Resend } from "resend";
import ProofEmail from "@/components/emails/ProofEmail";
import { Role } from "@prisma/client";
import Joi from "joi";

const resend = new Resend(process.env.RESEND_API_KEY);

const validationSchema = Joi.object({
	proofId: Joi.number().integer().min(1).required(),
	content: Joi.string().max(1000).required(),
	userId: Joi.number().integer().min(1).required(),
});

export async function createProofMessage({ proofId, content, userId }) {
	const session = await getServerSession(authOptions);

	if (!session || !session.user) {
		throw new Error("Not authorized");
	}

	const { error, value } = validationSchema.validate({
		proofId,
		content,
		userId,
	});
	if (error) {
		throw new Error(error.details[0].message);
	}

	const proof = await prisma.proof.findUnique({
		where: { id: value.proofId },
		include: {
			productRequest: {
				include: { user: true },
			},
		},
	});

	if (!proof) {
		throw new Error("Proof not found");
	}

	if (
		proof.productRequest.userId !== session.user.id &&
		session.user.role !== Role.Admin &&
		session.user.role !== Role.Designer &&
		session.user.role !== Role.Manager
	) {
		throw new Error("Not authorized for action");
	}

	const proofMessage = await prisma.proofMessage.create({
		data: {
			proofId: value.proofId,
			userId: value.userId,
			content: value.content,
		},
		include: {
			user: true,
		},
	});

	// Отправка email
	try {
		const recipient = proof.productRequest.user;

		if (!recipient) {
			throw new Error("No valid recipient found for the proof message.");
		}

		await resend.emails.send({
			to: recipient.email,
			from: process.env.RESEND_FROM,
			subject: "New Proof Message",
			react: (
				<ProofEmail
					name={recipient.name || "User"}
					link={`${process.env.NEXT_PUBLIC_BASE_URL}/account/orders/proof/${proof.id}`} 
					message={proofMessage.content}
				/>
			),
		});
	} catch (emailError) {
		console.error("Failed to send email:", emailError.message);
	}

	return proofMessage;
}
