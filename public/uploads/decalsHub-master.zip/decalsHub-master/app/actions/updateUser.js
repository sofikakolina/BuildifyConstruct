'use server';

import prisma from "@/libs/prisma"; // Подключение Prisma клиента
import bcrypt from "bcrypt";
import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";

export async function updateUser({ userId, name, password }) {
  const session = await getServerSession(authOptions);

  if (!session || session.user.id !== userId) {
    throw new Error("Unauthorized");
  }

  const data = {};

  if (name) {
    data.name = name;
  }

  if (password) {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    data.hashedPassword = hashedPassword;
  }

  if (Object.keys(data).length === 0) {
    throw new Error("No data to update");
  }

  await prisma.user.update({
    where: { id: userId },
    data,
  });

  revalidatePath("/account/profile");
}
