import { Storage } from "@google-cloud/storage";
import { NextResponse } from "next/server";

const storage = new Storage();
const bucketName = process.env.GCP_BUCKET_NAME;

export async function downloadFile(fileName){
  try {

    const [contents] = await storage.bucket(bucketName).file(fileName).download();

    return new NextResponse(contents, {
      headers: {
        "Content-Disposition": `attachment; filename="${fileName}"`,
        "Content-Type": "application/octet-stream",
      },
    });
  } catch (error) {
    console.error("Error downloading file:", error);
    return NextResponse.json({ error: "Failed to download file" }, { status: 500 });
  }
}
