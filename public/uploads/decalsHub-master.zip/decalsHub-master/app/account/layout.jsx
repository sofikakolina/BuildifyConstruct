import Box from '@mui/material/Box';
import { Manrope } from 'next/font/google';
import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter';
import { getServerSession } from 'next-auth';
import { authOptions } from '../api/auth/[...nextauth]/route';
import DashboardNavigation from '@/components/account/dashboard/DashboardNavigation';
import { Toolbar } from '@mui/material';

const manrope = Manrope({
  subsets: ['latin'],
  weight: ['300', '500', '700'],
});

export default async function DashboardLayout({ children }) {
  const session = await getServerSession(authOptions)
  const drawerWidth = 280;
  return (
    <Box className={manrope.className} sx={{display: { sm: 'flex' }}}>
      <DashboardNavigation session={session} />
      <Box
        component="main"
        sx={{ flexGrow: 1, p: 2, width: { sm: `calc(100% - ${drawerWidth}px)` } }}
      >
        <Toolbar />
        <AppRouterCacheProvider session={session}>{children}</AppRouterCacheProvider>
      </Box>
    </Box>
  );
}
