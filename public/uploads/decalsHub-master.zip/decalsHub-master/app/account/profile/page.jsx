import { getServerSession } from 'next-auth';
import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import EditProfile from '@/components/account/profile/settings';
export const metadata = {title: 'Profile'}
export default async function Profile() {
 const session = await getServerSession(authOptions)

  return (
    <div className='max-w-2xl'>
      <EditProfile user={session.user} />
    </div>
  );
}
