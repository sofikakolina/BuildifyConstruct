import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';
export const metadata = {title: 'Product Request'}
import ProductResponse from '@/components/account/productRequest/ProductResponse';

export default async function ListPage() {

    const session = await getServerSession(authOptions);
    return (
        <div>
            <ProductResponse userId={session.user.id} />
        </div>
    );
}
