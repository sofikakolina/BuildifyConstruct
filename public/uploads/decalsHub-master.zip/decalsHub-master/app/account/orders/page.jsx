import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';
export const metadata = {title: 'Orders'}
import Orders from "@/components/account/orders/Orders"

export default async function OrdersMain() {
    const session = await getServerSession(authOptions);
    return(
        <Orders userId={session?.user.id}/>
        )
}
