import {getServerSession} from "next-auth"
import {authOptions} from "@/app/api/auth/[...nextauth]/route"
import Proofing from "@/components/account/orders/proofing/Proofing"
const page = async ({params}) => <Proofing session={await getServerSession(authOptions)} params={params} />
export default page