import { Box } from "@mui/material";
export const metadata = {title: 'Account'}
export default function Account({ session }) {


  return (
    <div>
      <h2>
        Hello! {session?.user.name}
      </h2>
    </div>
  );
}
