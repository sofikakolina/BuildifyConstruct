import DynamicInvoice from "@/components/account/invoices/DynamicInvoice";
export const metadata = {title: 'Invoice'}
export default function InvoiceDetails({searchParams}) {
  const { orderId } = searchParams

  return (
      <DynamicInvoice orderId={orderId}/>
  );
}
