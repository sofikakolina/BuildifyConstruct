import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';
export const metadata = {title: 'Products'}
import Products from "@/components/account/products/Products";

export default async function ListPage() {

    const session = await getServerSession(authOptions);
    return (
        <div>
            <Products userId={session.user.id} />
        </div>
    );
}
