import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';
export const metadata = {title: 'Cart'}
import Cart from "@/components/account/cart/Cart";

export default async function ListPage() {
    const session = await getServerSession(authOptions);
    return (
        <div>
            <Cart userId={session?.user.id}/>
        </div>
    );
}
