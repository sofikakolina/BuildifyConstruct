import DeliveryMethodsTable from "@/components/dashboard/deliveryMethods/DeliveryMethodsTable"
export default function Deliveries() {
	return <DeliveryMethodsTable />
}