"use client"
import makeApiRequest from "@/libs/makeApiRequest"
import {CircularProgress} from "@mui/material"
import {useState, useEffect} from "react"
import EditOrder from "@/components/dashboard/kanban/EditOrder"
import toast from "react-hot-toast"

export default function User({params}) {
	const [order, setOrder] = useState(null)
	useEffect(() => {
		makeApiRequest("/api/getOrder", {id: params.id})
			.then(({order}) => setOrder(order))
			.catch(error => toast.error(error.message))
	}, [])
	return order ? <EditOrder order={order} /> : (
		<div className="h-full w-full flex justify-center items-center">
			<CircularProgress />
		</div>
	)
}