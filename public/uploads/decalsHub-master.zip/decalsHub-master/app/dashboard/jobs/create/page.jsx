import CreateOrder from "@/components/dashboard/kanban/CreateOrder"
export const metadata = { title: 'Create Order' }
export default async function ProductCreate() {
    return <CreateOrder />
}