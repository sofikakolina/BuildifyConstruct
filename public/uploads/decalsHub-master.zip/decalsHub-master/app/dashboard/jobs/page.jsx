import KanbanBoard from "@/components/dashboard/kanban/Kanban"
import { getServerSession } from 'next-auth'
import { authOptions } from '@/app/api/auth/[...nextauth]/route'

export const metadata = { title: 'Jobs' }
export default async function ListPage() {
    const session = await getServerSession(authOptions)
    return <KanbanBoard session={session} />
}