import ProductsTable from "@/components/dashboard/products/ProductsTable"
export const metadata = { title: 'Products' }
export default async function ListPage() {
    return <ProductsTable />
}