import CreateProduct from "@/components/dashboard/products/Form"
export const metadata = { title: 'Create Product' }
export default async function ProductCreate() {
    return <CreateProduct />
}