import TaxesTable from "@/components/dashboard/taxes/TaxesTable"
export const metadata = { title: 'Taxes' }
export default function Taxes() {
	return <TaxesTable />
}