import Sidebar from '@/components/dashboard/sidebar/Sidebar'
import Box from '@mui/material/Box'
import { Manrope } from 'next/font/google'
import { AppRouterCacheProvider } from '@mui/material-nextjs/v14-appRouter'
import { getServerSession } from 'next-auth'
import { authOptions } from '../api/auth/[...nextauth]/route'
import DashboardHeader from '@/components/dashboard/Header'

const manrope = Manrope({
	subsets: ['latin'],
	weight: ['300', '500', '700']
})
export default async function DashboardLayout({ children }) {
	const session = await getServerSession(authOptions)

	if (!session) {
		redirect('/auth/login');
	}
	
	return (
		<Box className={manrope.className} sx={{ display: 'flex' }}>
			<Sidebar session={session} />
			<Box
				component="main"
				sx={{ p: 2, height: '100vh', width: '100%', display: 'flex', flexDirection: 'column', overflowX: 'auto' }}
			>
				<DashboardHeader session={session} />
				<AppRouterCacheProvider>{children}</AppRouterCacheProvider>
			</Box>
		</Box>
	)
}
