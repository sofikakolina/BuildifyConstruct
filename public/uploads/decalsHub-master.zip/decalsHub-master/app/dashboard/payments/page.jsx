import PaymentsTable from "@/components/dashboard/payments/PaymentsTable"
export const metadata = { title: 'Payments' }
export default function Payments() {
	return <PaymentsTable />
}