import OrdersTable from "@/components/dashboard/orders/OrdersTable"
export const metadata = { title: 'Orders' }
export default function Orders() {
	return <OrdersTable />
}