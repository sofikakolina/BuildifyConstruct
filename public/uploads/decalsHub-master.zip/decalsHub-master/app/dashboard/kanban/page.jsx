import Kanban from "@/components/dashboard/kanban/Kanban"

export const metadata = { title: 'Kanban' }
export default async function ListPage() {
    return <Kanban />
}