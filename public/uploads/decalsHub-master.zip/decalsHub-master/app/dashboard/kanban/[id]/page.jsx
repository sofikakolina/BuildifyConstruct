"use client"
import Form from "@/components/dashboard/products/Form"
import makeApiRequest from "@/libs/makeApiRequest"
import {CircularProgress} from "@mui/material"
import {useState, useEffect} from "react"
import toast from "react-hot-toast"
export default function User({params}) {
	const [product, setProduct] = useState(null)
	useEffect(() => {
		makeApiRequest("/api/getProduct", {id: params.id})
			.then(({product}) => setProduct(product))
			.catch(error => toast.error(error.message))
	}, [])
	return product ? <Form product={product} /> : (
		<div className="h-full w-full flex justify-center items-center">
			<CircularProgress />
		</div>
	)
}