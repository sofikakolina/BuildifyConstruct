import MaterialsCategoriesTable from "@/components/dashboard/materials/categories/MaterialsCategoriesTable"
import {Box} from "@mui/material"
export const metadata = { title: 'Materials' }
export default function Materials() {
	return ( 
		<Box sx={{px: 3}}>
			<MaterialsCategoriesTable />
		</Box>
	)
}