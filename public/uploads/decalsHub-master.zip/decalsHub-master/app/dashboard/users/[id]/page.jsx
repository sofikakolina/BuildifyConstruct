"use client"
import Form from "@/components/dashboard/users/Form"
import makeApiRequest from "@/libs/makeApiRequest"
import { CircularProgress } from "@mui/material"
import { useState, useEffect } from "react"
import toast from "react-hot-toast"
export default function User({ params }) {
	const [user, setUser] = useState(null)
	useEffect(() => {
		makeApiRequest("/api/getUser", {id: params.id})
			.then(({user}) => setUser(user))
			.catch(error => toast.error(error.message))
	}, [])
	return user ? <Form user={user} /> : (
		<div className="h-full w-full flex justify-center items-center">
			<CircularProgress />
		</div>
	)
}