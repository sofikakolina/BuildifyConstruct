import UsersTable from "@/components/dashboard/users/UsersTable"
import {Box} from "@mui/material"
export const metadata = {title: 'Customers'}
export default async function ListPage() {
    return (
		<Box sx={{px: 3}}>
			<UsersTable/>
		</Box>
	)
}