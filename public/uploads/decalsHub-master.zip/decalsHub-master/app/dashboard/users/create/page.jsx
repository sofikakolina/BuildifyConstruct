import Form from "@/components/dashboard/users/Form"
export const metadata = {title: 'Create User'}
const CreateUser = () => <Form />
export default CreateUser