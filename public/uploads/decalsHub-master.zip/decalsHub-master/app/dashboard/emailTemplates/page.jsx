import EmailTemplatesTable from "@/components/dashboard/emailTemplates/EmailTemplatesTable"
export default EmailTemplatesTable