import Dashboard from "@/components/dashboard/Analytics"
import {Box} from "@mui/material"
import { getServerSession } from 'next-auth';
import { authOptions } from '../api/auth/[...nextauth]/route';
export const metadata = { title: 'Dashboard' }
export default async function Analytics() {
	const session = await getServerSession(authOptions)
	return (
		<Box>
			<Dashboard userRole={session?.user.role}/>
		</Box>
	)
}