import { getProductRequestById } from "@/app/actions/productRequest";
import ProductRequestDetails from "@/components/dashboard/productsRequests/ProductRequestDetails";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";

export async function generateMetadata({ params }) {
  const { id } = params;

  return {
    title: `Products Request ${id}`,
  };
}

export default async function ProductRequest({ params }) {
	const { id } = params;
	const session = await getServerSession(authOptions);

	try {
		const request = await getProductRequestById(Number(id));

		return (
			<div>
				{request ? (
					<ProductRequestDetails
						productRequest={request}
						session={session}
					/>
				) : (
					<div className="h-full w-full flex justify-center items-center">
						<h2>No proof found</h2>
					</div>
				)}
			</div>
		);
	} catch (error) {
		console.error("Failed to load proof:", error);
		return (
			<div className="h-full w-full flex justify-center items-center">
				<h2>Error loading proof</h2>
			</div>
		);
	}
}
