import ProductsTable from "@/components/dashboard/productsRequests/ProductsTable"
export const metadata = { title: 'Products Requests' }
export default async function ListPage() {
    return <ProductsTable />
}