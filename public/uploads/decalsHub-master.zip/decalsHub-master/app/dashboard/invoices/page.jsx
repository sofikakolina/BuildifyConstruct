import { authOptions } from '@/app/api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth';
export const metadata = {title: 'Invoices'}
import Invoices from "@/components/dashboard/invoices/Invoices"

export default async function OrdersMain() {
    const session = await getServerSession(authOptions);
    return(
        <Invoices userId={session?.user.id} company={session?.user.company}/>
    )
}
