import DynamicInvoice from "@/components/dashboard/invoices/DynamicInvoice";
export const metadata = {title: 'Invoice'}
export default async function InvoiceDetails({searchParams}) {
  const { orderId } = await searchParams

  return (
      <DynamicInvoice orderId={orderId}/>
  );
}
