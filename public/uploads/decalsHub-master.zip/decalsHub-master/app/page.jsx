export default function Home() {
  return <h3>hi</h3>;
}
