import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
	title: Joi.string().max(100),
	description: Joi.string().max(10000).allow(null),
	assigneeId: Joi.number().integer().min(0),
	dueDate: Joi.string().isoDate(),
	done: Joi.bool()
}).or("title", "description", "assigneeId", "dueDate", "done")
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		if(!session || session.role != Role.Admin && session.role != Role.Manager)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {id, ...value}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		await prisma.task.update({where: {id}, data: value})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}