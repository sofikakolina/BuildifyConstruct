import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/libs/prisma";
import { OrderStatus, Role } from "@prisma/client";
import { orderInclude as include } from "@/prisma/includes";
import Joi from "joi";
import makeApiRequest from "@/libs/makeApiRequest";

export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET })
		]);

		if (!session) return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });

		const validationSchema = Joi.object({
			id: Joi.number().integer().min(0).required(),
			...(() => session.role !== Role.Customer ? {
				status: Joi.string().max(50),
				details: Joi.string().max(10000)
			} : {})(),
			...(() => (session.role !== Role.Customer && session.role !== Role.Admin) ? {} : {
				addressId: Joi.number().integer().min(0),
				deliveryMethodId: Joi.number().integer().min(0)
			})(),
			...(() => session.role !== Role.Admin ? {} : {
				priority: Joi.string().max(20),
				dueDate: Joi.string().isoDate()
			})(),
		}).or(
			...(() => session.role !== Role.Customer ? ["status", "details"] : [])(),
			...(() => session.role !== Role.Customer && session.role !== Role.Admin ? [] : [
				"addressId", "deliveryMethodId"
			])(),
			...(() => session.role === Role.Admin ? ["priority", "dueDate"] : [])(),
		);

		const { error, value } = validationSchema.validate(input);
		if (error) return NextResponse.json({ message: error.details[0].message }, { status: 400 });

		const order = await prisma.order.findFirst({ where: { id: value.id }, include: { ...include, proofs: true } });
		if (!order) return NextResponse.json({ error: "There's no order with the specified id" }, { status: 400 });

		if (session.role === Role.Customer && order.status !== OrderStatus.PendingPayment)
			return NextResponse.json({ error: "Can't edit paid order" }, { status: 400 });

		if (
			!isNaN(value.addressId) && (isNaN(value.deliveryMethodId) || isNaN(order.deliveryMethodId)) ||
			!isNaN(value.deliveryMethodId) && (isNaN(value.addressId) || isNaN(order.addressId))
		) return NextResponse.json(
			{ error: "To apply delivery to the order you need both addressId and deliveryMethodId" }, { status: 400 }
		);

		if (!isNaN(value.addressId) && !order.user.addresses.some(address => address.id === value.addressId)) {
			return NextResponse.json(
				{ error: "The user doesn't have an address with the specified id" }, { status: 400 }
			);
		}

		await prisma.order.update({
			where: { id: value.id },
			data: value
		});

		if (value.status && value.status === OrderStatus.Complete && value.status !== order.status) {
			await makeApiRequest(
			  `${req.nextUrl.origin}/api/sendStatusEmail`,
			  {
				apiKey: process.env.SERVERLESS_API_KEY, orderId: order.id,
				newStatus: value.status
			  }
			)
		  }

		return NextResponse.json(null, { status: 200 });
	} catch (e) {
		if (e.message.includes("`status`"))
			return NextResponse.json({ error: "There's no such status value" }, { status: 400 });

		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json({ error: "Internal server error" }, { status: 500 });
	}
}
