import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role, OrderStatus} from "@prisma/client"
import {productInclude as include} from "@/prisma/includes"
const validationSchema = Joi.object({
	orderId: Joi.number().integer().min(0).required(),
	productId: Joi.number().integer().min(0).required(),
	quantity:  Joi.number().integer().greater(0),
	width: Joi.number().greater(0),
	height: Joi.number().greater(0)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const [order, product] = await Promise.all([
			prisma.order.findFirst({where: {id: value.orderId}}),
			prisma.product.findFirst({where: {id: value.productId}, include})
		])
		if(!order) return NextResponse.json({error: "There's no order with the specified id"}, {status: 400})
		if(!product) return NextResponse.json({error: "There's no product with the specified id"}, {status: 400})
		if(!session || (order.userId != session.id || product.userId !== null && product.userId != session.id)
			&& session.role != Role.Admin
		) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		if(order.status != OrderStatus.PendingPayment) return NextResponse.json(
			{error: `Cannot create an item of order with not ${OrderStatus.PendingPayment} status`},
			{status: 400}
		)
		const orderItem = await prisma.orderItem.create({data: {
			...value, width: product.width ? product.width : value.width,
			height: product.height ? product.height : value.height
		}})
		return NextResponse.json({orderItem})
	}
	catch(e) {
		if(e.code == "P2002") return NextResponse.json({error: "Order item already exists"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}