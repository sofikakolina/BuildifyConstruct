import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/libs/prisma";
import Joi from "joi";
import { Role } from "@prisma/client";

const validationSchema = Joi.object({
	proofId: Joi.number().integer().min(0).required(),
	userId: Joi.number().integer().min(0).required(),
	content: Joi.string().max(1000).required(),
});

export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);

		const { error, value } = validationSchema.validate(input);
		if (error) {
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		}

		const proof = await prisma.proof.findFirst({
			where: { id: value.proofId },
			include: {
				order: { include: { user: true } },
				productRequest: { include: { user: true } },
			},
		});

		if (!proof) {
			return NextResponse.json(
				{ error: "There's no proof with the specified id" },
				{ status: 400 }
			);
		}

		// Проверяем права доступа
		const isAuthorized =
			session.role === Role.Admin ||
			session.role === Role.Designer ||
			session.role === Role.Manager ||
			proof.order?.user?.id === session.id ||
			proof.productRequest?.user?.id === session.id;

		if (!session || !isAuthorized) {
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 401 }
			);
		}

		const proofMessage = await prisma.proofMessage.create({
			data: value,
			include: { user: true },
		});

		await new Promise((resolve) => setTimeout(resolve, 50));

		return NextResponse.json({ proofMessage });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
