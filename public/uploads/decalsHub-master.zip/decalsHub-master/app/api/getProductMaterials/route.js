import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import Joi from "joi"
const validationSchema = Joi.object({
	productId: Joi.number().integer().min(0).required(),
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10)
})
export async function POST(req) {
	try {
		const input = await req.json()
		const {error, value: {productId, page, size}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message})
		const [materials, total] = await Promise.all([
			prisma.material.findMany({where: {productId}, take: size, skip: page * size, include: {material: true}}),
			prisma.material.count({where: {productId}})
		])
		return NextResponse.json({materials, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)	
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}