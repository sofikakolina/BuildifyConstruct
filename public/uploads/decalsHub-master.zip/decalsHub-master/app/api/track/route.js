import Joi from "joi";
import { NextResponse } from "next/server";
import { getShipments } from "@/libs/shipstation";
import prisma from "@/libs/prisma";
import { Resend } from "resend";
import TrackingEmail from "@/libs/emails/tracking-email";

const resend = new Resend(process.env.RESEND_API_KEY);

const schema = Joi.object({
	resource_url: Joi.string().required(),
	resource_type: Joi.string().required(),
});

export async function POST(req) {
	try {
		const input = await req.json();
		const { error, value } = schema.validate(input);
		if (error) {
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		}

		const { resource_url, resource_type } = value;
		if (resource_type !== "SHIP_NOTIFY") {
			return NextResponse.json(
				{ error: "Unsupported resource type" },
				{ status: 400 }
			);
		}

		const shipments = await getShipments({ resource_url });

		await Promise.all(
			shipments.map(async (s) => {
				const where = {
					orderId: Number(s.orderNumber),
					deliveryOrderId: s.orderId,
				};
				const invoice = await prisma.invoice.findFirst({ where });

				if (!invoice) return;

				const object = {
					carrier_code: s.carrierCode,
					order_number: s.orderNumber,
					tracking_number: s.trackingNumber,
					postal_code: s.shipTo?.postalCode,
					locale: "en",
				};

				const params = Object.entries(object)
					.map(
						([key, value]) =>
							`${encodeURIComponent(key)}=${encodeURIComponent(
								value ?? ""
							)}`
					)
					.join("&");

				const trackingUrl = `https://trackshipment.shipstation.com/?${params}`;

				await prisma.invoice.update({
					where,
					data: {
						trackingNumber: s.trackingNumber,
						trackingUrl,
					},
				});

				await resend.emails.send({
					from: process.env.RESEND_FROM,
					to: invoice.email,
					subject: `Your order #${s.orderNumber} is on the way!`,
					react: TrackingEmail({
						trackingNumber: s.trackingNumber,
						trackingUrl,
						customerName: invoice.customerName,
						serviceCode: s.serviceCode,
					}),
				});
			})
		);

		return NextResponse.json(null, { status: 200 });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
