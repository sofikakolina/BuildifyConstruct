import { Storage } from '@google-cloud/storage';
import { NextResponse } from 'next/server';

const storage = new Storage({
  projectId: process.env.GCP_PROJECT_ID,
  credentials: {
    client_email: process.env.GCP_SERVICE_ACCOUNT_EMAIL,
    private_key: process.env.GCP_PRIVATE_KEY.replace(/\\n/g, '\n')
  }
});
const bucketName = process.env.GCP_BUCKET_NAME;

export async function GET(request, { params }) {
  const filePath = decodeURIComponent(params.path.join('/'));
  const gsFilePath = `gs://${bucketName}/${filePath}`;
  console.log('gsFilePath:', gsFilePath);

  const file = storage.bucket(bucketName).file(filePath);

  try {
    const [metadata] = await file.getMetadata();
    const [contents] = await file.download();

    const headers = new Headers();
    headers.append('Content-Type', metadata.contentType);

    return new NextResponse(contents, {
      headers,
    });
  } catch (error) {
    console.error(`Error retrieving image: ${error.message}`);
    console.error(error.stack);
    return new NextResponse(`Error retrieving image: ${error.message}`, { status: 500 });
  }
}
