import { NextResponse } from "next/server";
import Joi from "joi";
import { EmailTemplateType, Role } from "@prisma/client";
import { fromProofMessageFile } from "@/libs/interpretEmailTemplate";
import prisma from "@/libs/prisma";
import { Resend } from "resend";
import ProofEmail from "@/components/emails/ProofEmail";

const validationSchema = Joi.object({
	apiKey: Joi.string().min(50).max(100).required(),
	id: Joi.number().integer().min(0).required()
});

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req) {
	try {
		const input = await req.json();
		const { error, value: { apiKey, id } } = validationSchema.validate(input);
		if (error) return NextResponse.json({ error: error.details[0].message }, { status: 400 });
		if (apiKey !== process.env.SERVERLESS_API_KEY)
			return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });

		const [proofMessage, emailTemplate, admin] = await Promise.all([
			prisma.proofMessage.findFirst({
				where: { id },
				include: {
					proof: {
						include: {
							order: {
								include: {
									staffAssignments: { include: { employee: true } },
									user: true
								}
							},
							assets: true
						}
					},
					user: true
				}
			}),
			prisma.emailTemplate.findFirst({ where: { type: EmailTemplateType.ProofMessage } }),
			prisma.user.findFirst({ where: { role: Role.Admin } })
		]);

		if (!proofMessage) {
			return NextResponse.json({ error: "Proof message not found" }, { status: 404 });
		}

		const recipient = 
			proofMessage.user?.role !== Role.Customer
				? proofMessage.proof.order.user
				: proofMessage.proof.order.staffAssignments.find(
					assignment => assignment.employee.role === Role.Manager
				)?.employee || admin;

		if (!recipient) {
			return NextResponse.json({ error: "No valid recipient found" }, { status: 404 });
		}

		await resend.emails.send({
			to: recipient.email,
			from: process.env.RESEND_FROM,
			subject: emailTemplate?.subject || "Action Required: Proof Approval Needed",
			react: (
				<ProofEmail 
					name={recipient.name || "User"} 
					link={`${process.env.NEXT_PUBLIC_BASE_URL}/account/orders/proof/${proofMessage.proof.id}`} 
					message={proofMessage.content} 
				/>
			)
		});

		return NextResponse.json(null, { status: 200 });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json({ error: "Internal server error" }, { status: 500 });
	}
}
