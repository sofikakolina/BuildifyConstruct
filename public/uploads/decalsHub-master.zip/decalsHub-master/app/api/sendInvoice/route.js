import Joi from "joi";
import prisma from "@/libs/prisma";
import nodemailer from "nodemailer";
import { NextResponse } from "next/server";
import { fromOrder } from "@/libs/interpretEmailTemplate";
import { renderToBuffer } from "@react-pdf/renderer";
import InvoiceDocument from "@/components/invoicePdf";
import { EmailTemplateType } from "@prisma/client";
import { orderInclude } from "@/prisma/includes";

const validationSchema = Joi.object({
  apiKey: Joi.string().min(50).max(100).required(),
  id: Joi.number().integer().min(0).required(),
});

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: process.env.SMTP_SECURE,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

// Функция для валидации входных данных
async function validateInput(input) {
  const { error, value } = validationSchema.validate(input);
  if (error) {
    throw new Error(`Validation error: ${error.details[0].message}`);
  }
  return value;
}

// Функция для проверки авторизации по apiKey
function checkAuthorization(apiKey) {
  if (apiKey !== process.env.SERVERLESS_API_KEY) {
    throw new Error("Not authorized for action");
  }
}

// Функция для отправки email с вложением
async function sendInvoiceEmail(order, emailTemplate) {
  const pdfBuffer = await renderToBuffer(<InvoiceDocument order={order} />);
  await transporter.sendMail({
    to: order.invoice.email,
    subject: fromOrder(emailTemplate.subject, order),
    html: fromOrder(emailTemplate.html, order),
    from: process.env.SMTP_FROM,
    attachments: [
      {
        filename: `invoice_${order.invoice.id}.pdf`,
        content: pdfBuffer,
        type: "application/pdf",
      },
    ],
  });
}

export async function POST(req) {
  try {
    const input = await req.json();
    const { apiKey, id } = await validateInput(input);
    
    checkAuthorization(apiKey);

    const [order, emailTemplate] = await Promise.all([
      prisma.order.findFirst({ where: { id }, include: orderInclude }),
      prisma.emailTemplate.findFirst({ where: { type: EmailTemplateType.Invoice } }),
    ]);

    if (!order) {
      throw new Error(`Order with id ${id} not found`);
    }

    if (!emailTemplate) {
      throw new Error("Invoice email template not found");
    }

    await sendInvoiceEmail(order, emailTemplate);

    return NextResponse.json(null, { status: 200 });
  } catch (e) {
    console.error(`Error: ${e.message}\nStack: ${e.stack}`);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
