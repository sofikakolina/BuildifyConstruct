import { NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"
import prisma from "@/libs/prisma"
import { OrderStatus, Role } from "@prisma/client"
import { orderItemInclude } from "@/prisma/includes"
import { userSelect } from "@/prisma/selects"
const include = {
	proofs: { include: { messages: { include: { user: { select: userSelect } } }, assets: true } },
	orderItems: { include: orderItemInclude },
	tasks: { include: { assignee: { select: userSelect } } },
	assets: true,
	staffAssignments: { include: { employee: { select: userSelect } } },
	user: { select: userSelect },
	invoice: true,
	payment: true
}
export async function POST(req) {
	const session = await getToken({ req, secret: process.env.NEXTAUTH_SECRET })
	if (!session || session.role == Role.Customer)
		return NextResponse.json({ error: "Not authorized for action" }, { status: 401 })
	const jobs = {};
	const staffAssignments = { some: { employeeId: session.id } };
	(await Promise.all(session.role == Role.Admin ? [
		prisma.order.findMany({ where: { status: OrderStatus.Paid }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Design }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Proofing }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Prepress }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Production }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Hold }, include }),
		prisma.order.findMany({
			where: { status: OrderStatus.Complete },
			orderBy: { updatedAt: 'desc' },
			take: 10,
			include,
		}),
	] : [
		prisma.order.findMany({ where: { status: OrderStatus.Paid, staffAssignments }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Design, staffAssignments }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Proofing, staffAssignments }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Prepress, staffAssignments }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Production, staffAssignments }, include }),
		prisma.order.findMany({ where: { status: OrderStatus.Hold, staffAssignments }, include }),
		prisma.order.findMany({
			where: { status: OrderStatus.Complete },
			orderBy: { updatedAt: 'desc' },
			take: 10,
			include,
		}),
	])).forEach((orders, index) => {
		switch (index) {
			case 0: jobs.orders = orders; break
			case 1: jobs.design = orders; break
			case 2: jobs.proofing = orders; break
			case 3: jobs.prepress = orders; break
			case 4: jobs.production = orders; break
			case 5: jobs.hold = orders; break
			case 6: jobs.completed = orders; break
		}
	})
	return NextResponse.json({ jobs })
}