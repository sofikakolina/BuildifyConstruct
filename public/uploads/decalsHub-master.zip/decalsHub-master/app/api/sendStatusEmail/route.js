// pages/api/sendStatusEmail.js
import nodemailer from "nodemailer";
import { google } from "googleapis";
import { render } from "@react-email/render";
import StatusChangeEmail from "@/components/emails/StatusChangeEmail";
import prisma from "@/libs/prisma";
import { NextResponse } from "next/server";
import Joi from "joi";
import { orderInclude } from "@/prisma/includes";

// Определение схемы валидации
const validationSchema = Joi.object({
	apiKey: Joi.string().min(50).max(100).required(),
	orderId: Joi.number().integer().min(0).required(),
	newStatus: Joi.string().required()
});

// Настройка OAuth2 для Nodemailer
const OAuth2 = google.auth.OAuth2;
const oauth2Client = new OAuth2(
	process.env.SERVICE_CLIENT,
	process.env.OAUTH_PRIVATE_KEY,
	process.env.REDIRECT_URI
);

oauth2Client.setCredentials({
	refresh_token: process.env.REFRESH_TOKEN
});

async function getAccessToken() {
	return new Promise((resolve, reject) => {
		oauth2Client.getAccessToken((err, token) => {
			if (err) {
				reject('Failed to create access token :(');
			}
			resolve(token);
		});
	});
}

const transporter = nodemailer.createTransport({
	service: 'gmail',
	auth: {
		type: 'OAuth2',
		user: 'info@adwrapgraphics.com',
		clientId: process.env.SERVICE_CLIENT,
		clientSecret: process.env.OAUTH_PRIVATE_KEY,
		refreshToken: process.env.REFRESH_TOKEN,
		accessToken: getAccessToken()
	}
});

export async function POST(req) {
	try {
		const input = await req.json();
		const { error, value: { apiKey, orderId, newStatus } } = validationSchema.validate(input);
		if (error) return NextResponse.json({ error: error.details[0].message }, { status: 400 });

		if (apiKey !== process.env.SERVERLESS_API_KEY) {
			return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });
		}

		const order = await prisma.order.findFirst({ where: { id: orderId }, include: orderInclude });
		if (!order) {
			return NextResponse.json({ error: "Order not found" }, { status: 404 });
		}

		const emailHtml = render(StatusChangeEmail({ order, newStatus }));
		
		await transporter.sendMail({
			to: order.invoice.email,
			subject: `Order ${order.id} COMPLETED`,
			html: emailHtml,
			from: process.env.SMTP_FROM,
		});

		return NextResponse.json({ message: "Email sent successfully" }, { status: 200 });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json({ error: "Internal server error" }, { status: 500 });
	}
}
