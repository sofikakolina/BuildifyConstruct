import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
import {userSelect} from "@/prisma/selects"
export async function POST(req) {
	try {
		const session = await getToken({req, secret: process.env.NEXTAUTH_SECRET})
		if(!session || session.role == Role.Customer)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const [designers, executors, managers, sellers, total] = await Promise.all([
			prisma.user.findMany({where: {role: Role.Designer}, select: userSelect}),
			prisma.user.findMany({where: {role: Role.Executor}, select: userSelect}),
			prisma.user.findMany({where: {role: Role.Manager}, select: userSelect}),
			prisma.user.findMany({where: {role: Role.Seller}, select: userSelect}),
			prisma.user.count({where: {OR: [
				{role: Role.Designer},
				{role: Role.Executor},
				{role: Role.Manager},
				{role: Role.Seller}
			]}})
		])
		return NextResponse.json({staff: {designers, executors, managers, sellers}, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}
