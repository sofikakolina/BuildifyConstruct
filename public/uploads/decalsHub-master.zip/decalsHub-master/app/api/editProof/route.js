import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import Joi from "joi";
import prisma from "@/libs/prisma";
import { Role, ProductRequestStatus } from "@prisma/client";

const validationSchema = Joi.object({
  id: Joi.number().integer().min(0).required(),
  accepted: Joi.bool(),
  views: Joi.number().integer().min(0),
}).or("accepted", "views");

export async function POST(req) {
  try {
    const [input, session] = await Promise.all([
      req.json(),
      getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
    ]);

    const {
      error,
      value: { id, accepted, views },
    } = validationSchema.validate(input);
    if (error) {
      return NextResponse.json(
        { error: error.details[0].message },
        { status: 400 }
      );
    }

    const proof = await prisma.proof.findFirst({
      where: { id },
      include: {
        order: { include: { proofs: true, user: true } },
        productRequest: { include: { proofs: true, user: true } },
      },
    });

    if (!proof) {
      return NextResponse.json(
        { error: "Proof not found" },
        { status: 404 }
      );
    }

    const isAuthorized =
      session.role === Role.Admin ||
      proof.order?.user?.id === session.id ||
      proof.productRequest?.user?.id === session.id;

    if (!session || !isAuthorized) {
      return NextResponse.json(
        { error: "Not authorized for action" },
        { status: 401 }
      );
    }

    if (
      accepted &&
      proof.productRequest?.proofs?.some(
        (existingProof) => existingProof.id !== id && existingProof.accepted
      )
    ) {
      return NextResponse.json(
        {
          error: "Can't approve cause there's already an approved design",
        },
        { status: 400 }
      );
    }

    // Обновляем proof
    await prisma.proof.update({
      where: { id },
      data: { accepted, views },
    });

    // Обновляем статус ProductRequest
    if (proof.productRequest) {
      const hasApprovedProofs = await prisma.proof.findMany({
        where: {
          productRequestId: proof.productRequest.id,
          accepted: true,
        },
      });

      const newStatus =
        hasApprovedProofs.length > 0
          ? ProductRequestStatus.APPROVED
          : ProductRequestStatus.IN_PROGRESS;

      await prisma.productRequest.update({
        where: { id: proof.productRequest.id },
        data: { status: newStatus },
      });
    }

    return NextResponse.json(null, { status: 200 });
  } catch (e) {
    console.error(`${e.message}\n${e.stack}`);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
