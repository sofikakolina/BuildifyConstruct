import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/libs/prisma";
import Joi from "joi";
import { Role } from "@prisma/client";
import { userSelect } from "@/prisma/selects";

const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
});

export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);

		const { error, value } = validationSchema.validate(input);
		if (error)
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);

		const proof = await prisma.proof.findFirst({
			where: value,
			include: {
				messages: {
					include: {
						user: {
							select: userSelect,
						},
					},
				},
				assets: true,
				order: {
					include: {
						user: {
							select: userSelect,
						},
					},
				},
				productRequest: {
					include: {
						user: {
							select: userSelect,
						},
					},
				},
			},
		});

		if (!proof) {
			return NextResponse.json(
				{ error: "Proof not found" },
				{ status: 404 }
			);
		}

		if (
			!session ||
			(session.role !== Role.Admin && session.role !== Role.Designer &&
				proof.order?.user?.id !== session.id &&
				proof.productRequest?.user?.id !== session.id)
		) {
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 401 }
			);
		}

		const user =
			proof.order?.user ||
			proof.productRequest?.user ||
			null;

		return NextResponse.json({
			proof,
			user: user ? { id: user.id, name: user.name, email: user.email } : null,
		});
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
