import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import Joi from "joi";
import ApiError from "@/libs/apiError";
import { geocode } from "@/libs/geocoder";
import prisma from "@/libs/prisma";
import { AddressType, Role } from "@prisma/client";
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0).required(),
	type: Joi.string().max(50),
	label: Joi.string().max(50),
	address: Joi.string().max(200).required(),
	apartment: Joi.string().max(50),
});
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);
		const {
			error,
			value: { userId, type, label, address, apartment },
		} = validationSchema.validate(input);
		if (error)
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		if (!session || (session.id != userId && session.role != Role.Admin))
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 401 }
			);
		if (
			(!type || type == AddressType.Primary) &&
			(await prisma.address.findFirst({
				where: { userId, type: AddressType.Primary },
			}))
		)
			return NextResponse.json(
				{
					error: `Can't create a second address with type of \"${AddressType.Primary}\"`,
				},
				{ status: 400 }
			);
		let googleApiResponse = await geocode(address);
		return NextResponse.json({
			address: await prisma.address.create({
				data: { userId, type, label, ...googleApiResponse, apartment },
			}),
		});
	} catch (e) {
		if (e instanceof ApiError)
			return NextResponse.json(
				{ error: e.message },
				{ status: e.status }
			);
		if (e.message.includes("`type`"))
			return NextResponse.json(
				{ error: "There's no such type value" },
				{ status: 400 }
			);
		switch (e.code) {
			case "P2002":
				return NextResponse.json(
					{
						error: "Address with the specified value already exists",
					},
					{ status: 400 }
				);
			case "P2003":
				return NextResponse.json(
					{ error: "There's no user with the specified id" },
					{ status: 400 }
				);
			default:
				console.error(`${e.message}\n${e.stack}`);
				return NextResponse.json(
					{ error: "Internal server error" },
					{ status: 500 }
				);
		}
	}
}
