import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {invoiceInclude} from "@/prisma/includes"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	orderId: Joi.number().integer().min(0).required(),
	dueDate: Joi.string().isoDate()
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {orderId, dueDate}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const order = await prisma.order.findFirst({where: {id: orderId}, include: {invoice: true}})
		if(!order) return NextResponse.json({error: "There's no order with the specified id"}, {status: 400})
		if(order.invoice) return NextResponse.json({error: "Order with the specified id already has an invoice"}, {status: 400})
		return NextResponse.json({invoice: await prisma.invoice.create({data: {orderId, dueDate}, include: invoiceInclude})})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}