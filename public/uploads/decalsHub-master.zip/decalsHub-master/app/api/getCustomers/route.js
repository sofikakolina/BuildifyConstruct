import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {userSelect as select} from "@/prisma/selects"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10),
	search: Joi.string().max(100),
	sort: Joi.object({
		company: Joi.string().valid("asc", "desc"),
		createdAt: Joi.string().valid("asc", "desc")
	}).default({
		company: "asc"
	})
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		if(session?.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {page, size, search, sort}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const where = (() => {
			if(!search) return {}
			const object = {
				OR: [{phones: {some: {number: {contains: search, mode: "insensitive"}}}}]
			};
			["name", "email", "company"].forEach(
				key => object.OR.push({[key]: {contains: search, mode: "insensitive"}})
			)
			return object
		})()
		where.role = Role.Customer
		let [users, total] = await Promise.all([
			prisma.user.findMany(
				{where, take: size, skip: size * page, orderBy: Object.keys(sort).map(k => ({[k]: sort[k]})), select}
			),
			prisma.user.count({where})
		])
		return NextResponse.json({users, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}
