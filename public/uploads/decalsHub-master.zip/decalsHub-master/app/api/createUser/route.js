import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import {signUp} from "@/prisma/adapter.js"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	name: Joi.string().max(50).required(),
	email: Joi.string().email().required(),
	emailVerified: Joi.string().isoDate(),
	password: Joi.string().min(6).max(100).required(),
	image: Joi.string().max(1000),
	role: Joi.string().max(50),
	company: Joi.string().max(50),
	taxId: Joi.number().integer().min(0).allow(null)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		return await signUp(value).then((user) => NextResponse.json({user}))
	}
	catch(e) {
		if(e.code == "P2002") return NextResponse.json({error: "User with the specified email already exists"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: e.message}, {status: 500})
	}
}