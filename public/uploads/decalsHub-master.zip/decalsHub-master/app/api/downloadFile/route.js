import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import Joi from "joi"
const validationSchema = Joi.object({src: Joi.string().max(10000).required()})
export async function POST(req) {
  try {
    const [input, session] = await Promise.all(
      [req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
    )
    if(!session) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
    const {error, value: {src}} = validationSchema.validate(input)
    if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
    return NextResponse.json({
      base64: await fetch(src).then(response => response.arrayBuffer()).then(
        b => Buffer.from(b).toString("base64")
      )
    })
  }
  catch(e) {
    console.error(`${e.message}\n${e.stack}`)
    return NextResponse.json({error: "Internal server error"}, {status: 500})
  }
}