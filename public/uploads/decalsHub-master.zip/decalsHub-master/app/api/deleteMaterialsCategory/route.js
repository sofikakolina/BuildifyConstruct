import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({id: Joi.number().integer().min(0).required()})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		await prisma.materialsCategory.delete({where: value})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		if(e.code == "P2025") return NextResponse.json({error: "There's no materials templates category with the specified id"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}