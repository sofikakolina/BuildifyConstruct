import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
	userId: Joi.number().integer().min(0).allow(null),
	categoryId: Joi.number().integer().min(0),
	name: Joi.string().max(50),
	active: Joi.boolean(),
	width: Joi.number().greater(0),
	height: Joi.number().greater(0),
	price: Joi.number().integer().greater(0).allow(null),
	image: Joi.string().max(1000),
	discount: Joi.number().min(0),
	description: Joi.string().max(1000)
}).or("userId", "name", "active", "width", "height", "price", "image", "discount", "description")
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {id, ...value}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		await prisma.product.update({where: {id}, data: value})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		if(e.code == "P2025")
			return NextResponse.json({error: "There's no product with the specified id"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}