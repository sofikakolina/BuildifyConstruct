import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {orderInclude as include} from "@/prisma/includes"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({id: Joi.number().integer().min(0).required()})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_URL})])
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const order = await prisma.order.findFirst({where: value, include})
		if(!order) return NextResponse.json({error: "There's no order with the specified id"}, {status: 400})
		if(order.userId != session.id && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		return NextResponse.json({order})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}