import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import Joi from "joi";
import prisma from "@/libs/prisma";

const validationSchema = Joi.object({
  companyName: Joi.string().max(100).required(),
  usDotNumber: Joi.number().required(),
  mcNumber: Joi.number().allow(null),
  kyuNumber: Joi.number().allow(null),
  grossWeight: Joi.number().allow(null),
  stickerType: Joi.array()
    .items(Joi.string().max(50))
    .min(1)
    .required()
    .messages({
      "array.base": "Sticker type must be an array.",
      "array.min": "You must select at least one sticker type.",
      "array.includes": "Each sticker type must be a string.",
      "string.max": "Each sticker type must be at most 50 characters long.",
      "any.required": "Sticker type is required.",
    }),
  stickerDetails: Joi.object()
    .pattern(
      Joi.string(),
      Joi.object({
        quantity: Joi.number().required(),
        data: Joi.string().allow(null),
      })
    )
    .required()
    .messages({
      "any.required": "Sticker details are required.",
    }),
  hasLogo: Joi.boolean().required(),
  description: Joi.string().max(1000).allow(null, "").optional(),
});

export async function POST(req) {
  try {
    const [input, session] = await Promise.all([
      req.json(),
      getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
    ]);

    if (!session) {
      return NextResponse.json(
        { error: "Not authorized for action" },
        { status: 401 }
      );
    }

    const { error, value } = validationSchema.validate(input);
    if (error) {
      return NextResponse.json(
        { error: error.details[0].message },
        { status: 400 }
      );
    }

    const {
      companyName,
      usDotNumber,
      mcNumber,
      kyuNumber,
      grossWeight,
      stickerType,
      stickerDetails,
      hasLogo,
      description,
    } = value;

    // Create the main ProductRequest
    const productRequest = await prisma.productRequest.create({
      data: {
        companyName,
        usDotNumber,
        mcNumber,
        kyuNumber,
        grossWeight,
        stickerType,
        hasLogo,
        description,
        userId: session.id,
      },
    });

    // Create the sticker details
    const stickerDetailsData = Object.entries(stickerDetails).map(
      ([type, details]) => ({
        requestId: productRequest.id,
        stickerType: type,
        quantity: details.quantity,
        data: details.data || null,
      })
    );

    await prisma.stickerDetail.createMany({
      data: stickerDetailsData,
    });

    return NextResponse.json({ productRequest });
  } catch (e) {
    console.error(`${e.message}\n${e.stack}`);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
