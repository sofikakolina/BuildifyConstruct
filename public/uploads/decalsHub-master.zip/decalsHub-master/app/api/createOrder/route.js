import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import {OrderStatus, Role} from "@prisma/client"
import Joi from "joi"
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0).required(),
	status: Joi.string().max(50),
	deliveryMethod: Joi.string().max(50)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {userId, status, deliveryMethod}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		if(status == OrderStatus.PendingPayment && (await prisma.order.findMany({where: {userId, status: OrderStatus.PendingPayment}})).length)
			return NextResponse.json({error: "Can't create a second order with \"NotOrdered\" status"}, {status: 400})
		return NextResponse.json({order: await prisma.order.create({data: {userId, status, deliveryMethod}})})
	}
	catch(e) {
		if(e.message.includes("`status`")) return NextResponse.json({error: "There's no such status value"}, {status: 400})
		if(e.code == "P2003") return NextResponse.json({error: "There's no user with the specified id"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}