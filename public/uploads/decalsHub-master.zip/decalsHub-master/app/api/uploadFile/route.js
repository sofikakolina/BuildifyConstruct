import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { Storage } from "@google-cloud/storage";
const storage = new Storage({
	projectId: process.env.GCP_PROJECT_ID,
	credentials: {
		client_email: process.env.GCP_SERVICE_ACCOUNT_EMAIL,
		private_key: process.env.GCP_PRIVATE_KEY,
	},
});
export async function POST(req) {
	try {
		const formData = await req.formData();
		const data = formData.get("file");
		if (!data)
			return NextResponse.json(
				{ error: "No files received" },
				{ status: 400 }
			);
		const name = new Date().toISOString() + data.name;
		const file = storage.bucket(process.env.GCP_BUCKET_NAME).file(name);
		await file.save(Buffer.from(await data.arrayBuffer()));
		await file.makePublic();
		return NextResponse.json({ path: file.publicUrl() });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
