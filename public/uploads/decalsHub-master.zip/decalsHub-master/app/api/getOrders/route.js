import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import {orderInclude as include} from "@/prisma/includes.js"
import {OrderStatus, Role} from "@prisma/client"
import Joi from "joi"
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0),
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10),
	search: Joi.string().max(100)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		const {error, value: {userId, page, size, search}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		if(!session || userId != session.id && session.role == Role.Customer)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const pattern = (() => {
			if(!search) return {}
			const object = {OR: []}
			if(!isNaN(search)) {object.OR.push({id: Number(search)}); return object}
			["name", "company"].forEach(key => object.OR.push(
				{user: {[key]: {contains: search, mode: "insensitive"}}})
			)
			return object
		})()
		const [orders, total] = await Promise.all([
			prisma.order.findMany({
				where: {userId, status: {not: OrderStatus.PendingPayment}, ...pattern},
				take: size, skip: page * size, include,
				orderBy: { createdAt: "desc" }
			}),
			prisma.order.count({where: {userId, status: {not: OrderStatus.PendingPayment}, ...pattern}})
		])
		return NextResponse.json({orders, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}