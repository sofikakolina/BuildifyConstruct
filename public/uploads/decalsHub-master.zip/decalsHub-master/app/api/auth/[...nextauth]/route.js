import NextAuth from "next-auth/next";
import prismaAdapter from "@/prisma/adapter";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import Joi from "joi";
import { sendVerificationEmail } from "@/utils/sendVerificationEmail";
import crypto from "crypto";

const signInValidationSchema = Joi.object({
  login: Joi.string().max(50).required(),
  password: Joi.string().max(100).required(),
});

const signUpValidationSchema = Joi.object({
  name: Joi.string().max(50).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).max(100).required(),
  image: Joi.string().max(1000),
});

function validateCredentials(credentials, validationSchema) {
  const { error, value } = validationSchema.validate(credentials, { stripUnknown: true });
  if (error) throw new Error(error.details[0].message);
  return value;
}

async function checkEmail(email) {
  const existingUser = await prismaAdapter.getUserByEmail(email);
  return !!existingUser;
}

export const authOptions = {
  adapter: prismaAdapter,
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    }),
    CredentialsProvider({
      name: "Credentials",
      authorize: async (credentials) => {
        if (credentials.signUp === "true") {
          const emailExists = await checkEmail(credentials.email);
          if (emailExists) throw new Error("Email is already registered.");
          return await prismaAdapter.createUser(validateCredentials(credentials, signUpValidationSchema));
        }

        const user = await prismaAdapter.signIn(validateCredentials(credentials, signInValidationSchema));

        if (!user.emailVerified) {
          const existingToken = await prismaAdapter.getEmailVerificationByEmail(user.email);
          
          if (!existingToken) {
            const token = crypto.randomBytes(32).toString("hex");
            await prismaAdapter.createEmailVerification({ email: user.email, token });
            await sendVerificationEmail(user.email, user.name , token);
          }

          throw new Error("Please verify your email. We’ve sent you a new verification link.");
        }

        return user;
      },
    }),
  ],
  callbacks: {
    jwt: async ({ token, user }) => {
      if (user) {
        // Сохраняем обновленные данные пользователя в токен
        const { hashedPassword, ...rest } = user;
        token = { ...rest, hashedPassword };
      } else {
        // Получаем данные пользователя из базы, если токен уже существует
        const dbUser = await prismaAdapter.getUser(token.id);
        if (dbUser) {
          token = {
            id: dbUser.id,
            name: dbUser.name,
            email: dbUser.email,
            image: dbUser.image,
            role: dbUser.role,
            hashedPassword: dbUser.hashedPassword,
          };
        }
      }

      return token;
    },
    session: ({ session, token }) => {
      if (token.forceLogout) {
        return null;
      }
      // Привязываем обновленный токен к сессии
      session.user = token;
      return session;
    },
  },
  pages: { signIn: "/auth/login", signUp: "/auth/sign-up" },
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: "jwt" },
  debug: false,
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
