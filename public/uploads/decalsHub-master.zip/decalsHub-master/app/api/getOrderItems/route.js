import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
import {orderItemInclude as include} from "@/prisma/includes"
const validationSchema = Joi.object({
	orderId: Joi.number().integer().min(0).required(),
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		const {error, value: {orderId, page, size}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const order = await prisma.order.findFirst({where: {id: orderId}})
		if(!order) return NextResponse.json({error: "There's no order with the specified id"}, {status: 400})
		if(!session || order.userId != session.id && session.role == Role.Customer)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const [orderItems, total] = await Promise.all([
			prisma.orderItem.findMany({where: {orderId}, take: size, skip: page * size, include}),
			prisma.orderItem.count({where: {orderId}})
		])
		return NextResponse.json({orderItems, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}