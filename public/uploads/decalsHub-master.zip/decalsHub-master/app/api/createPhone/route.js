import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0).required(),
	type: Joi.string().max(50),
	number: Joi.string().pattern(/^\+?\d{1,15}$/).required()
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		if(!session || session.id != value.userId && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		return NextResponse.json({phone: await prisma.phone.create({data: value})})
	}
	catch(e) {
		if(e.message.includes("`type`")) return NextResponse.json({error: "There's no such type value"}, {status: 400})
		if(e.code == "P2002") return NextResponse.json({error: "User already has a number with the specified value"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}