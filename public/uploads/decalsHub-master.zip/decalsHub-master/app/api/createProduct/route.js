import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import prisma from "@/libs/prisma";
import resend from "@/libs/resend";
import Joi from "joi";
import { Role } from "@prisma/client";
import React from "react";
import ProductCreationEmail from "@/utils/CreateProductEmail";

const validationSchema = Joi.object({
  userId: Joi.number().integer().min(1).allow(null),
  categoryId: Joi.number().integer().min(1),
  name: Joi.string().max(100).required(),
  width: Joi.number().greater(0),
  height: Joi.number().greater(0),
  price: Joi.number().integer().greater(0).allow(null),
  image: Joi.string().max(1000),
  discount: Joi.number().min(0),
  description: Joi.string().max(1000),
  slug: Joi.string(),
});

const createSlug = async (name) => {
  const slug = name.trim().replaceAll(" ", "-");
  let editedSlug = slug;
  let counter = 1;
  while (await prisma.product.findFirst({ where: { slug: editedSlug } })) {
    editedSlug = slug + counter;
    counter++;
  }
  return editedSlug;
};

export async function POST(req) {
  try {
    const [input, session] = await Promise.all([
      req.json(),
      getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
    ]);

    if (session?.role !== Role.Admin) {
      return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });
    }

    const { error, value } = validationSchema.validate(input);
    if (error) {
      return NextResponse.json({ error: error.details[0].message }, { status: 400 });
    }

    const product = await prisma.product.create({
      data: {
        ...value,
        slug: value.slug ? value.slug : await createSlug(value.name),
      },
    });

    if (value.userId) {
      const user = await prisma.user.findUnique({ where: { id: value.userId } });

      if (user?.email) {
        await resend.emails.send({
          from: process.env.RESEND_FROM,
          to: user.email,
          subject: "Your product has been created!",
          react: ProductCreationEmail({ productName: value.name }),
        });
      }
    }

    return NextResponse.json({ product });
  } catch (e) {
    console.error(`${e.message}\n${e.stack}`);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
