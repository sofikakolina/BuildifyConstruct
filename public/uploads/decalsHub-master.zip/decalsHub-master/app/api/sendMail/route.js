import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import {Role} from "@prisma/client"
import Joi from "joi"
import nodemailer from "nodemailer"
const validationSchema = Joi.object({
	to: Joi.string().email().required(),
	subject: Joi.string().max(100),
	html: Joi.string().max(30000),
	attachments: Joi.array()
})
const transporter = nodemailer.createTransport({
	host: process.env.SMTP_HOST,
	port: process.env.SMTP_PORT,
	secure: process.env.SMTP_SECURE,
	auth: {user: process.env.SMTP_USER, pass: process.env.SMTP_PASS}
})
export async function POST(req) {
	try {
		const [formData, session] = await Promise.all([req.formData(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const input = ["to", "subject", "html"].reduce(
			(obj, cur) => !formData.get(cur) ? obj : {...obj, [cur]: formData.get(cur)}, {}
		)
		input.attachments = await Promise.all(formData.getAll("attachments").map(
			async a => ({filename: a.name, content: Buffer.from(await a.arrayBuffer()), contentType: a.type})
		))
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		await transporter.sendMail({...value, from: process.env.SMTP_FROM})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}