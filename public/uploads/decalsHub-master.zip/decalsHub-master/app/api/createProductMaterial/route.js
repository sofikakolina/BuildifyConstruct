import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	productId: Joi.number().integer().min(0).required(),
	materialId: Joi.number().integer().min(0).required()
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		return NextResponse.json({productMaterial: await prisma.productMaterial.create({data: value})})
	}
	catch(e) {
		switch(e.code) {
			case "P2002": return NextResponse.json({error: "Material already exists"}, {status: 400})
			case "P2003": return NextResponse.json({error: "Materials template or product doesn't exist"}, {status: 400})
			default: 
				console.error(`${e.message}\n${e.stack}`)
				return NextResponse.json({error: "Internal server error"}, {status: 500})
		}
	}
}