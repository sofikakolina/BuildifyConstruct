import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import {paymentInclude as include} from "@/prisma/includes"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0),
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		const {error, value: {userId, page, size}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		if(!session || userId != session.id && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const [payments, total] = await Promise.all([
			prisma.payment.findMany({where: {order: {userId}}, take: size, skip: size * page, include}),
			prisma.payment.count({where: {order: {userId}}})
		])
		return NextResponse.json({payments, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}