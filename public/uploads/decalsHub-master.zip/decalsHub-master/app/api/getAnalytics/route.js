import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import {OrderStatus, PaymentStatus, Role} from "@prisma/client"
import {paymentInclude} from "@/prisma/includes"
export async function POST(req) {
	try {
		const session = await getToken({req, secret: process.env.NEXTAUTH_SECRET})
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const date = new Date()
		const newYearIsoPlaceholder = "-01-01T00:00:00Z"
		const thisYear = {
			gte: date.getFullYear().toString() + newYearIsoPlaceholder,
			lt: (date.getFullYear() + 1).toString() + newYearIsoPlaceholder
		}
		const [newUsersThisYear, products, payments, orders, incompleteOrders] = await Promise.all([
			prisma.user.count({where: {createdAt: thisYear}}),
			prisma.product.findMany({
				where: {orderItems: {some: {order: {createdAt: thisYear, payment: {status: PaymentStatus.Captured}}}}},
				take: 5, 
				orderBy: {orderItems: {_count: "desc"}}, 
				select: {image: true, name: true}
			}),
			prisma.payment.findMany({
				where: {createdAt: thisYear, status: PaymentStatus.Captured}, include: paymentInclude
			}),
			prisma.order.count({where: {createdAt: thisYear}}),
			prisma.order.count({where: {AND: [
				{status: {not: OrderStatus.Complete}},
				{status: {not: OrderStatus.Delivered}},
				{status: {not: OrderStatus.Cancelled}},
				{status: {not: OrderStatus.PendingPayment}}
			]}})
		])
		return NextResponse.json({
			newUsersThisYear,
			products,
			payments,
			conversion: orders > 0 ? payments.length / orders * 100 : 0,
			incompleteOrders
		})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}