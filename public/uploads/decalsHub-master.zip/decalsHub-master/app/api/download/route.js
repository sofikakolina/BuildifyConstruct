export async function GET(req) {
    const { searchParams } = new URL(req.url);
    const fileUrl = searchParams.get("fileName");
  
    if (!fileUrl) {
      return new Response(
        JSON.stringify({ error: "File name is required" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }
  
    try {
      const response = await fetch(fileUrl);
  
      if (!response.ok) {
        throw new Error("Failed to fetch file from the public URL");
      }
  
      const blob = await response.blob();
      const headers = new Headers(response.headers);
      headers.set(
        "Content-Disposition",
        `attachment; filename="${fileUrl.split("/").pop()}"`
      );
  
      return new Response(blob, { headers });
    } catch (error) {
      console.error("Error fetching public file:", error);
      return new Response(
        JSON.stringify({ error: "Failed to download file" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
  }
