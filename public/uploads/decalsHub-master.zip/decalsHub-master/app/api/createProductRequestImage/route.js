import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import {Role} from "@prisma/client"
import prisma from "@/libs/prisma"
import Joi from "joi"
const validationSchema = Joi.object({
	requestId: Joi.number().integer().min(0).required(),
	src: Joi.string().max(1000).required()
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		const {error, value: {requestId, src}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const request = await prisma.productRequest.findFirst({where: {id: requestId}})
		if(!request) return NextResponse.json(
			{error: "There's no product request with the specified id"}, {status: 400}
		)
		if(!session || request.userId != session.id && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		return NextResponse.json(
			{productRequest: await prisma.productRequestImage.create({data: {requestId, src}})}
		)
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}