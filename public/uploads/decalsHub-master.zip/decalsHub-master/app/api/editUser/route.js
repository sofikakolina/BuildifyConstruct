import { getToken } from "next-auth/jwt";
import { NextResponse } from "next/server";
import bcrypt from "bcrypt";
import prisma from "@/libs/prisma";
import Joi from "joi";
import { Role } from "@prisma/client";

const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
	name: Joi.string().max(50),
	email: Joi.string().email().max(50).required(),
	emailVerified: Joi.string().isoDate().allow(null),
	image: Joi.string().max(1000),
	password: Joi.string().max(100),
	role: Joi.string().max(50),
	company: Joi.string().max(50),
	taxId: Joi.number().integer().min(0).allow(null)
}).or("name", "email", "emailVerified", "image", "password", "role", "company", "taxId");

export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET })
		]);

		const { error, value: { password, ...value } } = validationSchema.validate(input);
		if (error) return NextResponse.json({ error: error.details[0].message }, { status: 400 });
		if (!session || session.role !== Role.Admin && (session.id !== value.id || value.tax)) 
			return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });

		let updateData = { ...value };
		if (password) {
			updateData.hashedPassword = await bcrypt.hash(password, 10);
		}

		await prisma.user.update({
			where: { id: value.id },
			data: updateData
		});

		// Уведомляем клиент, что требуется завершение сессии
		return NextResponse.json({ logoutRequired: !!password }, { status: 200 });
	} catch (e) {
		if (e.code === "P2025") return NextResponse.json({ error: "There's no user with the specified id" }, { status: 400 });
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json({ error: "Internal server error" }, { status: 500 });
	}
}
