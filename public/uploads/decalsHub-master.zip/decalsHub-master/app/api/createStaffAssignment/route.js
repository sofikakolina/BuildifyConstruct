import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import {Role} from "@prisma/client"
import Joi from "joi"
import {userSelect} from "@/prisma/selects"
import prisma from "@/libs/prisma"
const validationSchema = Joi.object({
	orderId: Joi.number().integer().min(0).required(),
	employeeId: Joi.number().integer().min(0).required()
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		if(session?.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {orderId, employeeId}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const [assignments, employee] = await Promise.all([
			prisma.staffAssignment.findMany(
				{where: {orderId}, include: {employee: {select: userSelect}}}
			),
			prisma.user.findFirst({where:{id: employeeId}})
		])
		if(employee.role == Role.Customer)
			return NextResponse.json({error: "Can't assign customer to the job"}, {status: 400})
		if(employee.role == Role.Admin) return NextResponse.json(
			{
				error: "Are you serious? You're trying to assign the admin to the job? " +
				"Ain't gonna happen! Only over my dead body!!!"
			},
			{status: 400}
		)
		// if(assignments.some(a => a.employee.role == employee.role)) return NextResponse.json(
		// 	{error: "Employee with the specified role already assigned"}, {status: 400}
		// )
		return NextResponse.json({staffAssignment: await prisma.staffAssignment.create(
			{data: {orderId, employeeId}}
		)})
	}
	catch(e) {
		if(e.code == "P2002")
			return NextResponse.json({error: "Employee is already assigned to this job"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}