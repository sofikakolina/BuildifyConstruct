import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import {geocode} from "@/libs/geocoder"
import ApiError from "@/libs/apiError"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
	type: Joi.string().max(50),
	label: Joi.string().max(50),
	address: Joi.string().max(200),
	apartment: Joi.string().max(50)
}).or("type", "label", "address", "apartment")
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		let {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const address = await prisma.address.findFirst({where: {id: value.id}})
		if(!address) return NextResponse.json({error: "There's no address with the specified id"}, {status: 400})
		if(!session || session.id != address.userId && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		if(!value.address) {
			await prisma.address.update({where: {id: value.id}, data: value})
			return NextResponse.json(null, {status: 200})
		}
		let googleApiResponse = await geocode(value.address)
		await prisma.address.update({where: {id: value.id}, data: {type: value.type, label: value.label, ...googleApiResponse, apartment: value.apartment}})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		if(e instanceof ApiError) return NextResponse.json({error: e.message}, {status: e.status})
		if(e.message.includes("`type`")) return NextResponse.json({error: "There's no such type value"}, {status: 400})
		if(e.code == "P2002") return NextResponse.json({error: "Address with the specified value already exists"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}