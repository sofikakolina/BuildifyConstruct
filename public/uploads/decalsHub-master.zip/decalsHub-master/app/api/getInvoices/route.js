import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import Joi from "joi";
import prisma from "@/libs/prisma";
import { invoiceInclude as include } from "@/prisma/includes.js";
import { Role } from "@prisma/client";

const validationSchema = Joi.object({
  userId: Joi.number().integer().min(0),
  page: Joi.number().integer().min(0).default(0),
  size: Joi.number().integer().min(-2).default(10),
  search: Joi.string().max(100),
  startDate: Joi.date().optional(),
  endDate: Joi.date().optional(),
});

export async function POST(req) {
  try {
    const [input, session] = await Promise.all([
      req.json(),
      getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
    ]);

    const {
      error,
      value: { userId, page, size, search, startDate, endDate },
    } = validationSchema.validate(input);

    if (error) {
      return NextResponse.json({ message: error.details[0].message }, { status: 400 });
    }

    if (!session || (session.role !== Role.Admin && session.id !== userId)) {
      return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });
    }

    const where = {
      order: { userId },
      AND: [],
    };

    if (search) {
      where.OR = [
        isNaN(search) ?
          { order: { user: { name: { contains: search, mode: "insensitive" } } } } :
          { id: Number(search) },
        { order: { user: { company: { contains: search, mode: "insensitive" } } } },
      ];
    }

    if (startDate || endDate) {
      where.AND.push({
        createdAt: {
          gte: startDate ? new Date(startDate) : undefined,
          lte: endDate ? new Date(endDate) : undefined,
        },
      });
    }

	const pageSize = size === -1 ? undefined : size;
	const skip = size === -1 ? undefined : size * page; // Не передаем skip при all
	
	const [invoices, total] = await Promise.all([
	  prisma.invoice.findMany({ where, take: pageSize, skip, include }),
	  prisma.invoice.count({ where }),
	]);
	
	

    return NextResponse.json({ invoices, total });
  } catch (e) {
    console.error(`${e.message}\n${e.stack}`);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
