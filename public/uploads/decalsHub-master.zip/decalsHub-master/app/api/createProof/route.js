import { NextResponse } from "next/server";
import prisma from "@/libs/prisma";
import Joi from "joi";
import { getToken } from "next-auth/jwt";
import { Role } from "@prisma/client";
import { Resend } from "resend";
import ProofCreateEmail from "@/components/emails/ProofCreateEmail";

const resend = new Resend(process.env.RESEND_API_KEY);

const validationSchema = Joi.object({
	productRequestId: Joi.number().integer().min(0).required(),
	assetSrc: Joi.string().uri().required(),
	messageContent: Joi.string().max(500).required(),
	userId: Joi.number().integer().required(),
});

export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);

		if (
			!session ||
			(session.role !== Role.Admin && session.role !== Role.Designer)
		) {
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 401 }
			);
		}

		const { error, value } = validationSchema.validate(input);
		if (error) {
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		}

		// Создаём Proof
		const proof = await prisma.proof.create({
			data: {
				productRequestId: value.productRequestId,
			},
		});

		// Обновляем статус ProductRequest
		await prisma.productRequest.update({
			where: { id: value.productRequestId },
			data: { status: "IN_PROGRESS" },
		});

		// Создаём ProofAsset, связанный с Proof
		const proofAsset = await prisma.proofAsset.create({
			data: {
				proofId: proof.id,
				src: value.assetSrc,
			},
		});

		// Создаём сообщение для Proof
		const proofMessage = await prisma.proofMessage.create({
			data: {
				proofId: proof.id,
				userId: value.userId,
				content: value.messageContent,
			},
		});

		// Отправка email
		try {
			const productRequest = await prisma.productRequest.findUnique({
				where: { id: value.productRequestId },
				include: { user: true },
			});

			const recipient = productRequest?.user;

			if (!recipient) {
				throw new Error("No valid recipient found for the proof.");
			}

			await resend.emails.send({
				to: recipient.email,
				from: process.env.RESEND_FROM,
				subject: "New Proof Created",
				react: (
					<ProofCreateEmail
						name={recipient.name || "User"}
						link={`${process.env.NEXT_PUBLIC_BASE_URL}/account/orders/proof/${proof.id}`}
						proofDetails={value.messageContent}
						imageUrl={proofAsset.src}
					/>
				),
			});
		} catch (emailError) {
			console.error("Failed to send email:", emailError.message);
		}

		return NextResponse.json({ proof, proofAsset, proofMessage });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
