import { NextResponse } from "next/server";
import prisma from "@/libs/prisma";
import { Role } from "@prisma/client";
import Joi from "joi";
import { productInclude as include } from "@/prisma/includes";
import { getToken } from "next-auth/jwt";
const validationSchema = Joi.object({
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10),
	userId: Joi.number().integer().min(0),
	search: Joi.string().max(100),
});
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);
		const {
			error,
			value: { page, size, search, userId },
		} = validationSchema.validate(input);
		if (error)
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		const where = (() => {
			const object =
				session.role == Role.Admin
					? { userId }
					: { OR: [{ userId: session.id }, { userId: null }] };
			if (!search || object.OR) return object;
			object.OR = [];
			["name", "company"].forEach((key) =>
				object.OR.push({
					user: { [key]: { contains: search, mode: "insensitive" } },
				})
			);
			object.OR.push({ name: { contains: search, mode: "insensitive" } });
			return object;
		})();
		const [products, total] = await Promise.all([
			prisma.product.findMany({
				where,
				take: size,
				skip: size * page,
				include,
			}),
			prisma.product.count({ where }),
		]);
		return NextResponse.json({ products, total });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
