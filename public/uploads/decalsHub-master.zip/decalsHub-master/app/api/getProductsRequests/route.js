import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { Role } from "@prisma/client";
import prisma from "@/libs/prisma";
import Joi from "joi";
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0),
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10),
});
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);
		const {
			error,
			value: { userId, page, size },
		} = validationSchema.validate(input);
		if (error)
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		if (!session || (userId !== session.id && session.role != Role.Admin && session.role != Role.Designer))
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 401 }
			);
		const [productsRequests, total] = await Promise.all([
			prisma.productRequest.findMany({
				where: { userId },
				orderBy: { createdAt: "desc" },
				include: { images: true, user: true, proofs: true, },
				take: size,
				skip: size * page,
			}),
			prisma.productRequest.count({ where: { userId } }),
		]);
		return NextResponse.json({ productsRequests, total });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
