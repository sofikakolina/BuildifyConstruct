import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	name: Joi.string().max(50).required(),
	cost: Joi.number().integer().greater(0).required(),
	markup: Joi.number().greater(0).required(),
	categoryId: Joi.number().integer().min(0)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		return NextResponse.json({material: await prisma.material.create({data: value})})
	}
	catch(e) {
		switch(e.code) {
			case "P2002": return NextResponse.json({error: "Material with the specified name already exists"}, {status: 400})
			case "P2003": return NextResponse.json({error: "There's no materials category with the specified id"}, {status: 400})
			default: 
				console.error(`${e.message}\n${e.stack}`)
				return NextResponse.json({error: "Internal server error"}, {status: 500})
		}
	}
}