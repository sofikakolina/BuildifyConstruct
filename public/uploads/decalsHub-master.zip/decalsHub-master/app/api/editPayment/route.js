import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
	amount: Joi.number().greater(0),
	provider: Joi.string().max(50),
	status: Joi.string().max(50)
}).or("amount", "provider", "status")
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const payment = await prisma.payment.findFirst({where: {id: value.id}})
		if(!payment) return NextResponse.json({error: "There's no payment with the specified id"}, {status: 400})
		await prisma.payment.update({where: {id: value.id}, data: value})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		if(e.message.includes("`status`")) return NextResponse.json({error: "There's no such status value"}, {status: 400})
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}