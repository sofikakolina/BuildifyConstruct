import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import {Role} from "@prisma/client"
import prisma from "@/libs/prisma"
import Joi from "joi"
const validationSchema = Joi.object({productRequestId: Joi.number().integer().min(0).required()})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const request = await prisma.productRequest.findMany(
			{where: value}, {include: {images: true}}
		)
		if(!session || userId !== session.id && session.role != Role.Admin && session.role != Role.Designer)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		return NextResponse.json({productsRequestImages: request.images})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}