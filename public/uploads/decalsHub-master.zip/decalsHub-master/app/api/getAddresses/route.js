import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	userId: Joi.number().integer().min(0),
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		const {error, value: {userId, page, size}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		if(!session || session.id != userId && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const [addresses, total] = await Promise.all([
			prisma.address.findMany({where: {userId}, take: size, skip: page * size}),
			prisma.address.count({where: {userId}})
		])
		return NextResponse.json({addresses, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}