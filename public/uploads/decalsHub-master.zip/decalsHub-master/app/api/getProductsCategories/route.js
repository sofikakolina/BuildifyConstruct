import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
export async function POST(req) {
	const session = await getToken({req, secret: process.env.NEXTAUTH_SECRET})
	if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
	return NextResponse.json({productsCategories: await prisma.productCategory.findMany()})
}