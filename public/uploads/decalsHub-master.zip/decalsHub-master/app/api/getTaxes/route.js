import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	page: Joi.number().integer().min(0).default(0),
	size: Joi.number().integer().min(1).default(10)
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(session?.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value: {page, size}} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const [taxes, total] = await Promise.all([
			prisma.tax.findMany({take: size, skip: page * size}),
			prisma.tax.count()
		])
		return NextResponse.json({taxes, total})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}