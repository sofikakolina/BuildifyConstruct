import { NextResponse } from "next/server";
import prisma from "@/libs/prisma";
import { Role } from "@prisma/client";
import Joi from "joi";
import { getToken } from "next-auth/jwt";
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
});
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([
			req.json(),
			getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
		]);
		const { error, value } = validationSchema.validate(input);
		if (error)
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
			const productRequest = await prisma.productRequest.findFirst({
				where: value,
				include: {
					images: true,
					user: true,
					proofs: {
						include: {
							assets: true,
							messages: true,
						},
					},
				},
			});
			
		if (!productRequest)
			return NextResponse.json(
				{ error: "There's no product request with the specified id" },
				{ status: 400 }
			);
		if (
			!session ||
			(session.id != productRequest.userId && session.role != Role.Admin && session.role != Role.Designer)
		)
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 400 }
			);
		return NextResponse.json({ productRequest });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
