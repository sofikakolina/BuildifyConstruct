import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { Client } from "square";
import { randomUUID } from "crypto";
import prisma from "@/libs/prisma";
import { OrderStatus, PaymentStatus, PhoneType, Role, AddressType } from "@prisma/client";
import { orderInclude, invoiceInclude } from "@/prisma/includes";
import Joi from "joi";
import { getCartTotal } from "@/libs/calculations";
import getFullAddress from "@/libs/getFullAddress";
import { addOrder } from "@/libs/shipstation";
import makeApiRequest from "@/libs/makeApiRequest";

const validationSchema = Joi.object({
  orderId: Joi.number().integer().min(0).required(),
  sourceId: Joi.string().max(100).required(),
  shipToName: Joi.string(),
  shipToPhone: Joi.string(),
  shipToCompany: Joi.string(),
});

const { paymentsApi } = new Client({
  accessToken: process.env.SQUARE_ACCESS_TOKEN,
  environment: process.env.SQUARE_ENVIRONMENT,
});

export async function POST(req) {
  try {
    const [input, session] = await Promise.all([
      req.json(),
      getToken({ req, secret: process.env.NEXTAUTH_SECRET }),
    ]);

    const { error, value } = validationSchema.validate(input);
    if (error) {
      console.error("Validation error:", error.details[0].message);
      return NextResponse.json({ error: error.details[0].message }, { status: 400 });
    }
    const { orderId, sourceId, shipToName, shipToPhone, shipToCompany } = value;

    const order = await prisma.order.findFirst({ where: { id: orderId }, include: orderInclude });
    if (!order) {
      console.error("Order not found:", orderId);
      return NextResponse.json({ error: "There's no order with the specified id" }, { status: 400 });
    }

    if (order.payment) {
      console.error("Payment already exists for order:", orderId);
      return NextResponse.json({ error: "Can't create a second payment for the same order" }, { status: 400 });
    }

    if (!session || (order.userId != session.id && session.role != Role.Admin)) {
      console.error("Unauthorized action by session user:", session?.id);
      return NextResponse.json({ error: "Not authorized for action" }, { status: 401 });
    }

    const amount = getCartTotal(order);

    let paymentResult;
    try {
      paymentResult = await paymentsApi.createPayment({
        idempotencyKey: randomUUID(),
        sourceId,
        amountMoney: { currency: "USD", amount },
      });
    } catch (error) {
      console.error("Error creating payment:", error);
      if (error.errors && error.errors.length > 0) {
        console.error("Payment API errors:", error.errors);
        return NextResponse.json({ error: "Payment processing failed", details: error.errors }, { status: 400 });
      } else {
        return NextResponse.json({ error: "Payment processing failed", details: error.message }, { status: 400 });
      }
    }

    if (!paymentResult || !paymentResult.result || !paymentResult.result.payment) {
      console.error("Payment result is invalid:", paymentResult);
      return NextResponse.json({ error: "Payment processing failed" }, { status: 400 });
    }

    const paymentStatus = paymentResult.result.payment.status;
    if (paymentStatus !== 'COMPLETED') {
      console.error("Payment not completed:", paymentStatus);
      return NextResponse.json({ error: `Payment was not completed successfully. Status: ${paymentStatus}` }, { status: 400 });
    }

    let phone = order.user.phones.find(phone => phone.type == PhoneType.Mobile)?.number;
    if (!phone) phone = order.user.phones[0]?.number;

    let delivery = null;
    let shipTo = null;
    if (order.addressId !== null) {
      shipTo = order.address;
      const billTo = order.user.addresses.find(a => a.type == AddressType.Billing) || order.address;

      try {
        delivery = await addOrder(order, shipTo, billTo, shipToPhone || phone, shipToName, shipToCompany);
      } catch (e) {
        console.error("Error in ShipStation addOrder:", e);
      }
    }

    let payment, invoice;
    try {
      [payment, invoice] = await Promise.all([
        prisma.payment.create({
          data: {
            id: paymentResult.result.payment.id,
            orderId,
            amount,
            provider: "square",
            status: PaymentStatus.Captured,
          },
        }),
        prisma.invoice.create({
          data: {
            orderId,
            name: order.user.name,
            shipToName: shipToName || order.user.name,
            shipToPhone: shipToPhone || phone,
            company: order.user.company,
            shipToCompany: shipToCompany || order.user.company,
            ...(() => (shipTo ? { address: getFullAddress(shipTo), deliveryMethod: order.deliveryMethod.name } : {}))(),
            phone,
            email: order.user.email,
            taxRate: order.user.tax?.rate,
            deliveryCost: order.deliveryMethod ? order.deliveryMethod.cost : 0,
            deliveryOrderId: delivery?.orderId,
          },
          include: invoiceInclude,
        }),
        prisma.order.update({ where: { id: orderId }, data: { status: OrderStatus.Paid } }),
        ...order.orderItems.map(i => Promise.all([
          prisma.orderItem.update({
            where: { id: i.id },
            data: {
              name: i.product.name,
              image: i.product.image,
              discount: i.product.discount,
              price: i.product.price,
            },
          }),
          ...i.product.productMaterials.map(pm =>
            prisma.orderItemMaterial.create({
              data: {
                orderItemId: i.id,
                name: pm.material.name,
                cost: pm.material.cost,
                markup: pm.material.markup,
              },
            })
          ),
        ])),
      ]);
    } catch (e) {
      console.error("Error updating database records:", e);
      return NextResponse.json({ error: "Failed to update order records", details: e.message }, { status: 500 });
    }

    try {
      await makeApiRequest(`${req.nextUrl.origin}/api/sendInvoice`, {
        apiKey: process.env.SERVERLESS_API_KEY,
        id: orderId,
      });
    } catch (e) {
      console.error("Error sending invoice:", e);
    }

    await new Promise(resolve => setTimeout(resolve, 50));

    return NextResponse.json({ payment, invoice });
  } catch (e) {
    console.error("Internal server error:", e.message, e.stack);
    return NextResponse.json({ error: "Internal server error", details: e.message }, { status: 500 });
  }
}
