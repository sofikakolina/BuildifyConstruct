import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import Joi from "joi"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({
	id: Joi.number().integer().min(0).required(),
	name: Joi.string().max(100),
	description: Joi.string().max(1000)
}).or("name", "description")
export async function POST(req) {
	try {
		const [input, session] = await Promise.all(
			[req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})]
		)
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const productRequest = await prisma.productRequest.findFirst({where: {id: value.id}})
		if(!productRequest)
			return NextResponse.json({error: "There's no product request with the specified id"}, {status: 400})
		if(!session || productRequest.id != session.id && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		await prisma.productRequest.update({where: {id: value.id}, data: value})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}