import {NextResponse} from "next/server"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
import Joi from "joi"
import {getToken} from "next-auth/jwt"
const validationSchema = Joi.object({
	orderId: Joi.number().integer().required(),
	title: Joi.string().max(100).required(),
	description: Joi.string().max(10000),
	assigneeId: Joi.number().integer().min(0).required(),
	dueDate: Joi.string().isoDate().required(),
	done: Joi.bool()
})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		if(!session || session.role != Role.Admin && session.role != Role.Manager)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		return NextResponse.json({task: await prisma.task.create({data: value})})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}