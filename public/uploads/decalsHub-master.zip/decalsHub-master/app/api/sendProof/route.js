import { NextResponse } from "next/server";
import { EmailTemplateType } from "@prisma/client";
import Joi from "joi";
import prisma from "@/libs/prisma";
import { Resend } from "resend";
import ProofCreateEmail from "@/components/emails/ProofCreateEmail";

const validationSchema = Joi.object({
	apiKey: Joi.string().min(50).max(100).required(),
	id: Joi.number().integer().min(0).required(),
});

const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(req) {
	try {
		const input = await req.json();
		const {
			error,
			value: { apiKey, id },
		} = validationSchema.validate(input);
		if (error)
			return NextResponse.json(
				{ error: error.details[0].message },
				{ status: 400 }
			);
		if (apiKey !== process.env.SERVERLESS_API_KEY)
			return NextResponse.json(
				{ error: "Not authorized for action" },
				{ status: 401 }
			);

		const [emailTemplate, proof] = await Promise.all([
			prisma.emailTemplate.findFirst({
				where: { type: EmailTemplateType.Proof },
			}),
			prisma.proof.findFirst({
				where: { id },
				include: { order: { include: { user: true } }, assets: true },
			}),
		]);

		if (!proof || proof.assets.length === 0) {
			return NextResponse.json({ error: "Proof or assets not found" }, { status: 404 });
		}

		const proofDetails = `Proof ID: ${proof.id}, Assets: ${proof.assets.length}`;
		const link = `${process.env.NEXT_PUBLIC_BASE_URL}/account/orders/proof/${proof.id}`;
		const imageUrl = proof.assets[0].src;

		await resend.emails.send({
			to: proof.order.user.email,
			from: process.env.RESEND_FROM,
			subject: emailTemplate?.subject || "New Proof Created - Review Required",
			react: (
				<ProofCreateEmail
					name={proof.order.user.name || "User"}
					link={link}
					proofDetails={proofDetails}
					imageUrl={imageUrl}
				/>
			),
		});

		return NextResponse.json(null, { status: 200 });
	} catch (e) {
		console.error(`${e.message}\n${e.stack}`);
		return NextResponse.json(
			{ error: "Internal server error" },
			{ status: 500 }
		);
	}
}
