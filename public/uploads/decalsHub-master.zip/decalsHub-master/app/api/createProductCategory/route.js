import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
import {getToken} from "next-auth/jwt"
import {NextResponse} from "next/server"
import Joi from "joi"
const validationSchema = Joi.object({name: Joi.string().max(300).required()})
export async function POST(req) {
	const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
	if(session?.role != Role.Admin) return NextResponse.json({error: "Not authorized for action"}, {status: 401})
	const {error, value: {name}} = validationSchema.validate(input)
	if(error) return NextResponse.json({error: error.details[0].message})
	return NextResponse.json({productCategory: await prisma.productCategory.create({data: {name}})})
}