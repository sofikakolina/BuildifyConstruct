import {NextResponse} from "next/server"
import {getToken} from "next-auth/jwt"
import Joi from "joi"
import prisma from "@/libs/prisma"
import {Role} from "@prisma/client"
const validationSchema = Joi.object({id: Joi.number().integer().min(0).required()})
export async function POST(req) {
	try {
		const [input, session] = await Promise.all([req.json(), getToken({req, secret: process.env.NEXTAUTH_SECRET})])
		const {error, value} = validationSchema.validate(input)
		if(error) return NextResponse.json({error: error.details[0].message}, {status: 400})
		const address = await prisma.address.findFirst({where: value})
		if(!address) return NextResponse.json({error: "There's no address with the specified id"}, {status: 400})
		if(!session || session.id != address.userId && session.role != Role.Admin)
			return NextResponse.json({error: "Not authorized for action"}, {status: 401})
		await prisma.address.delete({where: value})
		return NextResponse.json(null, {status: 200})
	}
	catch(e) {
		console.error(`${e.message}\n${e.stack}`)
		return NextResponse.json({error: "Internal server error"}, {status: 500})
	}
}