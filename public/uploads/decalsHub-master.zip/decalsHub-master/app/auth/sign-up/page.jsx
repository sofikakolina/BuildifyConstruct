import SignUpForm from "@/components/auth/SignUpForm";
import Image from "next/image";

export const metadata = {
	title: "Register",
};

function SignUpPage() {
	return (
		<div className="flex flex-col lg:flex-row h-screen">
			<div className="lg:w-1/2 flex justify-center items-center bg-gray-100 py-6">
				<div className="container flex justify-center">
					<div className="flex flex-col justify-center gap-4 max-w-md">
						<h2 className="text-3xl font-bold text-primary">
							Sign Up
						</h2>
						<SignUpForm />
					</div>
				</div>
			</div>{" "}
			<div className="lg:w-1/2 lg:px-6 bg-cover bg-center bg-secondary-gradient flex items-center justify-center py-12">
				<div className="container flex gap-4 flex-col items-center justify-center">
					<h2 className="text-3xl text-center text-white">
						Welcome to
						<span className="text-primary font-bold">
							{" "}
							DecalsHub
						</span>
					</h2>
					<p className="text-white text-center px-4">
						We offer customized decals for every individual need
					</p>
					<Image
						src="/assets/auth/white_car_img.png"
						width={701}
						height={536}
						priority
						alt="White Car"
					/>
				</div>
			</div>
		</div>
	);
}

export default SignUpPage;
