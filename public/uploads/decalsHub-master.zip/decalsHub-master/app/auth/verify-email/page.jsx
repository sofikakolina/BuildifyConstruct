// app/auth/verify-email/page.jsx
'use client'

import React, { useState, useEffect, Suspense } from "react";
import { verifyEmail } from "@/app/(auth)/actions/verifyEmail";
import { useSearchParams } from "next/navigation";
import { CircularProgress } from "@mui/material";
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';

const VerifyEmailPage = () => {
  const searchParams = useSearchParams();
  const token = searchParams.get("token");
  const [status, setStatus] = useState("loading");

  useEffect(() => {
    if (token) {
      verifyEmail(token)
        .then(() => setStatus("success"))
        .catch(() => setStatus("error"));
    }
  }, [token]);

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100 px-4 text-center">
      <div className="bg-white p-8 rounded shadow-md max-w-md w-full">
        {status === "loading" && (
          <>
            <CircularProgress />
            <h2 className="text-2xl font-semibold mt-4">Verifying your email...</h2>
            <p className="text-gray-600 mt-2">Please wait a moment while we verify your email.</p>
          </>
        )}
        {status === "success" && (
          <>
            <CheckCircleOutlineIcon className="text-green-500" style={{ fontSize: 48 }} />
            <h2 className="text-2xl font-semibold mt-4">Email Verified!</h2>
            <p className="text-gray-600 mt-2">Your email has been successfully verified. You can now log in.</p>
            <a href="/auth/login" className="mt-4 inline-block px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition">
              Go to Login
            </a>
          </>
        )}
        {status === "error" && (
          <>
            <ErrorOutlineIcon className="text-red-500" style={{ fontSize: 48 }} />
            <h2 className="text-2xl font-semibold mt-4">Verification Failed</h2>
            <p className="text-gray-600 mt-2">The verification link is invalid or has expired.</p>
            <a href="/auth/resend-verification" className="mt-4 inline-block px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition">
              Resend Verification Email
            </a>
          </>
        )}
      </div>
    </div>
  );
}

// Обёртка с Suspense для корректного использования useSearchParams
export default function VerifyEmailWrapper() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <VerifyEmailPage />
    </Suspense>
  );
}
