// app/(auth)/actions/registerUserWithEmailVerification.ts

"use server";

import prismaAdapter from "@/prisma/adapter";
import Joi from "joi";
import { sendVerificationEmail } from "@/utils/sendVerificationEmail";
import crypto from "crypto";

const signUpValidationSchema = Joi.object({
	email: Joi.string().email().required(),
	company: Joi.string().max(100).required(),
	name: Joi.string().max(50).required(),
	password: Joi.string().min(6).max(100).required(),
	role: Joi.string().required(),
});

export async function registerUserWithEmailVerification({
	email,
	name,
	password,
	role,
	company,
}) {
	const { error } = signUpValidationSchema.validate({
		email,
		company,
		name,
		password,
		role,
	});
	if (error) {
		return { error: error.details[0].message };
	}

	const existingUser = await prismaAdapter.getUserByEmail(email);
	if (existingUser) {
		return { error: "Email is already registered." };
	}

	await prismaAdapter.createUser({
		email,
		name,
		password,
		role,
		company,
		emailVerified: null,
	});

	const token = crypto.randomBytes(32).toString("hex");
	await prismaAdapter.createEmailVerification({ token, email });

	await sendVerificationEmail(email, name, token);

	return { success: true };
}
