// app/(auth)/actions/registerUser.ts
'use server';

import prismaAdapter from '@/prisma/adapter';
import Joi from 'joi';
import { redirect } from 'next/navigation';

const signUpValidationSchema = Joi.object({
  name: Joi.string().max(50).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).max(100).required(),
  role: Joi.string().required(),
});

export async function registerUser({ email, name, password, role }) {
  const { error } = signUpValidationSchema.validate({ email, name, password, role });
  if (error) throw new Error(error.details[0].message);

  const existingUser = await prismaAdapter.getUserByEmail(email);
  if (existingUser) throw new Error('Email is already registered.');

  await prismaAdapter.createUser({ email, name, password, role });

  redirect('/auth/login');
}
