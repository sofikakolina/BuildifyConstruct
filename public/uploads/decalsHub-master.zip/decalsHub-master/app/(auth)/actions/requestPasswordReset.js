// app/(auth)/actions/requestPasswordReset.ts
'use server';

import prismaAdapter from '@/prisma/adapter';
import { sendResetPasswordEmail } from '@/utils/sendResetPasswordEmail';
import crypto from 'crypto';

export async function requestPasswordReset({ email }) {
  const user = await prismaAdapter.getUserByEmail(email);

  if (!user) {
    throw new Error('User not found');
  }

  const token = crypto.randomBytes(32).toString('hex');
  await prismaAdapter.createPasswordResetToken({ email, token });

  await sendResetPasswordEmail(email, token);
}
