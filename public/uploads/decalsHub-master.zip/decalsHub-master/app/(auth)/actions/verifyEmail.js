// app/(auth)/actions/verifyEmail.ts
'use server';

import prismaAdapter from '@/prisma/adapter';

export async function verifyEmail(token) {
  const emailVerification = await prismaAdapter.getEmailVerificationByToken(token);

  if (!emailVerification) {
    throw new Error('Invalid or expired token');
  }

  await prismaAdapter.updateUserByEmail(emailVerification.email, {
    emailVerified: new Date(),
  });
  await prismaAdapter.deleteEmailVerificationByToken(token);
}
