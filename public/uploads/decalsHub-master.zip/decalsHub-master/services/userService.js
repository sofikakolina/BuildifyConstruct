import useFetch from '@/hooks/useFetch';

export const useUserService = () => {
  const { fetchData } = useFetch();

  const getCustomers = (callback) => {
    fetchData('/api/getCustomers', 'GET')
      .then(data => callback(data))
      .catch(error => console.error(error));
  };

  const deleteUser = (userId, callback) => {
    fetchData(`/api/deleteUser/${userId}`, 'DELETE')
      .then(() => callback())
      .catch(error => console.error(error));
  };

  return { getCustomers, deleteUser };
};
