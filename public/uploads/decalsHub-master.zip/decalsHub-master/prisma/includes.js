import {userSelect} from "./selects"
export const userInclude = {
	phones: true,
	addresses: true,
	tax: true
}
export const productInclude = {
	productMaterials: {
		include: {
			material: true
		}
	},
	user: {select: userSelect},
	category: true
}
export const orderItemInclude = {
	materials: true,
	product: {include: productInclude}
}
export const orderInclude = {
	user: {select: userSelect},
	payment: true,
	orderItems: {include: orderItemInclude},
	invoice: true,
	deliveryMethod: true,
	address: true,
	proofs: true
}
export const invoiceInclude = {
	order: {
		include: {
			user: {select: userSelect},
			payment: true,
			orderItems: {include: orderItemInclude}
		}
	}
}
export const paymentInclude = {
	order: {
		include: {
			user: {select: userSelect},
			orderItems: {include: orderItemInclude},
			invoice: true
		}
	}
}
export const materialInclude = {
	productMaterials: {
		include: {
			product: {
				include: {
					orderItems: true,
				}
			}
		}
	}
} 