import prisma from "@/libs/prisma";
const bcrypt = require("bcrypt");
import { userSelect as select } from "./selects";

export async function signIn({ login, password }) {
	const user = await prisma.user.findFirst({
		where: { OR: [{ name: login }, { email: login }] },
	});
	if (!user)
		throw new Error("The user with the specified login doesn't exist!");
	if (await bcrypt.compare(password, user.hashedPassword)) return user;
	throw new Error("Incorrect password!");
}

export async function signUp({ password, ...data }) {
	if (password) var hashedPassword = await bcrypt.hash(password, 10);
	return await prisma.user.create({
		data: { ...data, hashedPassword },
		select,
	});
}

export async function getUserByAccount(provider_providerAccountId) {
	return (
		await prisma.account.findUnique({
			where: { provider_providerAccountId },
			select: { user: true },
		})
	)?.user;
}

export async function getUserByEmail(email) {
	return await prisma.user.findUnique({ where: { email } });
}

export async function linkAccount(data) {
	return await prisma.account.create({
		data: {
			userId: data.userId,
			type: data.type,
			provider: data.provider,
			providerAccountId: data.providerAccountId,
			refreshToken: data.refresh_token,
			accessToken: data.access_token,
			expiresAt: data.expires_at,
			tokenType: data.token_type,
			scope: data.scope,
			idToken: data.id_token,
			sessionState: data.session_state,
		},
	});
}

export async function getUserById(id) {
	return await prisma.user.findUnique({ where: { id } });
}

// Создание записи подтверждения email

export async function createEmailVerification({ email, token }) {
	// Проверяем, существует ли уже запись для данного email
	const existingVerification = await prisma.emailVerification.findUnique({
		where: { email },
	});

	if (existingVerification) {
		// Если запись существует, обновляем токен
		return await prisma.emailVerification.update({
			where: { email },
			data: { token },
		});
	} else {
		// Если записи нет, создаем новую
		return await prisma.emailVerification.create({
			data: { email, token },
		});
	}
}

// Получение записи подтверждения email по токену
export async function getEmailVerificationByToken(token) {
	return await prisma.emailVerification.findFirst({
		where: { token },
	});
}

// Удаление записи подтверждения email по токену
export async function deleteEmailVerificationByToken(token) {
	return await prisma.emailVerification.deleteMany({
		where: { token },
	});
}

// Обновление статуса пользователя на "подтвержден"
export async function updateUserByEmail(email, data) {
	return await prisma.user.update({
		where: { email },
		data,
	});
}

export async function getEmailVerificationByEmail(email) {
	return await prisma.emailVerification.findUnique({
	  where: { email },
	});
  }

const prismaAdapter = {
	getUser: getUserById,
	createUser: signUp,
	linkAccount,
	getUserByAccount,
	getUserByEmail,
	signIn,
	createEmailVerification,
	getEmailVerificationByToken,
	getEmailVerificationByEmail,
	deleteEmailVerificationByToken,
	updateUserByEmail,
};

export default prismaAdapter;
