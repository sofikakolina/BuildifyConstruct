-- AlterTable
ALTER TABLE "ProductRequest" ADD COLUMN     "companyName" TEXT,
ADD COLUMN     "grossWeight" INTEGER,
ADD COLUMN     "hasLogo" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "isRoofSticker" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "isUnitNumber" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "kyuNumber" INTEGER,
ADD COLUMN     "magnets" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "mcNumber" INTEGER,
ADD COLUMN     "stickerType" TEXT,
ADD COLUMN     "unitNumberHeight" INTEGER,
ADD COLUMN     "usDotNumber" INTEGER,
ADD COLUMN     "vinNumber" TEXT;
