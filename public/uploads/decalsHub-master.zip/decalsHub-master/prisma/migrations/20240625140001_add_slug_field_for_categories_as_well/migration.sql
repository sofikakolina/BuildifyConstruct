-- AlterTable
ALTER TABLE "ProductCategory" ADD COLUMN     "slug" TEXT;
