-- AlterTable
ALTER TABLE "Address" ADD COLUMN     "apartment" TEXT;
