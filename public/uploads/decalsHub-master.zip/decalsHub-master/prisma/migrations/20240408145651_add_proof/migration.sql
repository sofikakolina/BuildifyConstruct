-- CreateTable
CREATE TABLE "Proof" (
    "id" SERIAL NOT NULL,
    "orderId" INTEGER NOT NULL,
    "views" INTEGER NOT NULL DEFAULT 0,
    "accepted" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Proof_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ProofAsset" (
    "id" SERIAL NOT NULL,
    "proofId" INTEGER NOT NULL,
    "src" TEXT NOT NULL,

    CONSTRAINT "ProofAsset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ProofMessage" (
    "id" SERIAL NOT NULL,
    "userId" INTEGER,
    "proofId" INTEGER NOT NULL,
    "content" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProofMessage_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "ProofAsset" ADD CONSTRAINT "ProofAsset_proofId_fkey" FOREIGN KEY ("proofId") REFERENCES "Proof"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProofMessage" ADD CONSTRAINT "ProofMessage_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ProofMessage" ADD CONSTRAINT "ProofMessage_proofId_fkey" FOREIGN KEY ("proofId") REFERENCES "Proof"("id") ON DELETE CASCADE ON UPDATE CASCADE;
