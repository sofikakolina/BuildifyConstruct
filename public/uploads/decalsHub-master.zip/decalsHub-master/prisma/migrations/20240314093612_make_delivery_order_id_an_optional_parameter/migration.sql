-- AlterTable
ALTER TABLE "Invoice" ALTER COLUMN "deliveryOrderId" DROP NOT NULL;
