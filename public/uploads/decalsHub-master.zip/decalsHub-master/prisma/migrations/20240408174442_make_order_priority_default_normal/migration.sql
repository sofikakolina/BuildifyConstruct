-- AlterTable
ALTER TABLE "Order" ALTER COLUMN "priority" SET DEFAULT 'Normal';

-- AlterTable
ALTER TABLE "Task" ALTER COLUMN "title" DROP NOT NULL,
ALTER COLUMN "description" DROP NOT NULL;

-- CreateTable
CREATE TABLE "OrderAsset" (
    "id" SERIAL NOT NULL,
    "orderId" INTEGER NOT NULL,
    "src" TEXT NOT NULL,

    CONSTRAINT "OrderAsset_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "OrderAsset" ADD CONSTRAINT "OrderAsset_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "Order"("id") ON DELETE CASCADE ON UPDATE CASCADE;
