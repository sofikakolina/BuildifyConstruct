-- AlterTable
ALTER TABLE "Invoice" ADD COLUMN     "shipToCompany" TEXT;
