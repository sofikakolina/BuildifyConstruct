-- AlterTable
ALTER TABLE "OrderItem" ADD COLUMN     "price" INTEGER;

-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "price" INTEGER;
