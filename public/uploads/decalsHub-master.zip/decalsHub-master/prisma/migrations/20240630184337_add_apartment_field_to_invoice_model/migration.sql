-- AlterTable
ALTER TABLE "Invoice" ADD COLUMN     "apartment" TEXT;
