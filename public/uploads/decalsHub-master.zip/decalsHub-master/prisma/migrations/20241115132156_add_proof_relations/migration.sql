-- AlterTable
ALTER TABLE "Proof" ADD COLUMN     "productRequestId" INTEGER,
ALTER COLUMN "orderId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "Proof" ADD CONSTRAINT "Proof_productRequestId_fkey" FOREIGN KEY ("productRequestId") REFERENCES "ProductRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;
