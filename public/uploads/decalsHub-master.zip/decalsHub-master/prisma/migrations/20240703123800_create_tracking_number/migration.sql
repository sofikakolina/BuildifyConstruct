-- AlterTable
ALTER TABLE "Invoice" ADD COLUMN     "trackingNumber" TEXT,
ADD COLUMN     "trackingUrl" TEXT;
