/*
  Warnings:

  - You are about to drop the column `isRoofSticker` on the `ProductRequest` table. All the data in the column will be lost.
  - You are about to drop the column `isUnitNumber` on the `ProductRequest` table. All the data in the column will be lost.
  - You are about to drop the column `magnets` on the `ProductRequest` table. All the data in the column will be lost.
  - The `stickerType` column on the `ProductRequest` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "ProductRequest" DROP COLUMN "isRoofSticker",
DROP COLUMN "isUnitNumber",
DROP COLUMN "magnets",
DROP COLUMN "stickerType",
ADD COLUMN     "stickerType" TEXT[];
