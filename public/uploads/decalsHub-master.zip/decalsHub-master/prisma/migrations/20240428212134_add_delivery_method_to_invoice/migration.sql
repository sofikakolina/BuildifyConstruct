-- AlterTable
ALTER TABLE "Invoice" ADD COLUMN     "deliveryMethod" TEXT;
