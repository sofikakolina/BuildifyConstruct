/*
  Warnings:

  - Added the required column `subject` to the `EmailTemplate` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "EmailTemplate" ADD COLUMN     "subject" TEXT NOT NULL;
