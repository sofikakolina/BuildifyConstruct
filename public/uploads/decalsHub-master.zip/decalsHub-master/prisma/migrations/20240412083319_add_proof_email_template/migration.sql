-- AlterEnum
ALTER TYPE "EmailTemplateType" ADD VALUE 'Proof';
