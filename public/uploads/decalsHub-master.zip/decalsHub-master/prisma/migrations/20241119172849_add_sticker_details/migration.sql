/*
  Warnings:

  - You are about to drop the column `vinNumber` on the `ProductRequest` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ProductRequest" DROP COLUMN "vinNumber";

-- CreateTable
CREATE TABLE "StickerDetail" (
    "id" SERIAL NOT NULL,
    "requestId" INTEGER NOT NULL,
    "stickerType" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "data" TEXT,

    CONSTRAINT "StickerDetail_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "StickerDetail" ADD CONSTRAINT "StickerDetail_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES "ProductRequest"("id") ON DELETE CASCADE ON UPDATE CASCADE;
