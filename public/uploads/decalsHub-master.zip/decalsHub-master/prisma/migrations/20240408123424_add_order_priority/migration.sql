/*
  Warnings:

  - Added the required column `priority` to the `Order` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "OrderPriority" AS ENUM ('Normal', 'Rush');

-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "priority" "OrderPriority" NOT NULL;
