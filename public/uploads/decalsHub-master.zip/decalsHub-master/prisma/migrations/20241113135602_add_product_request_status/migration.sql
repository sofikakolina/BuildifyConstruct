-- CreateEnum
CREATE TYPE "ProductRequestStatus" AS ENUM ('REQUESTED', 'IN_PROGRESS', 'DONE');

-- AlterTable
ALTER TABLE "ProductRequest" ADD COLUMN     "status" "ProductRequestStatus" NOT NULL DEFAULT 'REQUESTED';
