/*
  Warnings:

  - The values [DONE] on the enum `ProductRequestStatus` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "ProductRequestStatus_new" AS ENUM ('REQUESTED', 'IN_PROGRESS', 'DECLINED', 'APPROVED');
ALTER TABLE "ProductRequest" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "ProductRequest" ALTER COLUMN "status" TYPE "ProductRequestStatus_new" USING ("status"::text::"ProductRequestStatus_new");
ALTER TYPE "ProductRequestStatus" RENAME TO "ProductRequestStatus_old";
ALTER TYPE "ProductRequestStatus_new" RENAME TO "ProductRequestStatus";
DROP TYPE "ProductRequestStatus_old";
ALTER TABLE "ProductRequest" ALTER COLUMN "status" SET DEFAULT 'REQUESTED';
COMMIT;
