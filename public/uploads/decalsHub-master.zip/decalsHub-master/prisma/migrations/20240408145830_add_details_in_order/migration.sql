-- AlterTable
ALTER TABLE "Order" ADD COLUMN     "details" TEXT;
