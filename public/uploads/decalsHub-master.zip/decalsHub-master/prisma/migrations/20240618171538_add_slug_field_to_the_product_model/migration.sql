-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "slug" TEXT;
