/*
  Warnings:

  - A unique constraint covering the columns `[orderId,productId,image]` on the table `OrderItem` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "OrderItem_orderId_productId_key";

-- CreateIndex
CREATE UNIQUE INDEX "OrderItem_orderId_productId_image_key" ON "OrderItem"("orderId", "productId", "image");
