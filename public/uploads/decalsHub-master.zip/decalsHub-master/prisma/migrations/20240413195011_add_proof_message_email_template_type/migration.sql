-- AlterEnum
ALTER TYPE "EmailTemplateType" ADD VALUE 'ProofMessage';
