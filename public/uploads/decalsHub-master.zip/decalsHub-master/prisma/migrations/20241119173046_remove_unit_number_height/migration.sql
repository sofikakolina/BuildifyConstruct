/*
  Warnings:

  - You are about to drop the column `unitNumberHeight` on the `ProductRequest` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ProductRequest" DROP COLUMN "unitNumberHeight";
