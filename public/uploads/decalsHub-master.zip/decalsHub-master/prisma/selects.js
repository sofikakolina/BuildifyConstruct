export const userSelect = {
	id: true,
	name: true,
	company: true,
	tax: true,
	email: true,
	emailVerified: true,
	image: true,
	role: true,
	createdAt: true,
	updatedAt: true,
	addresses: true,
	phones: true,
}