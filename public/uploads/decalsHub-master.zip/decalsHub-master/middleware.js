import { NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { Role } from '@prisma/client';

export async function middleware(req) {
    const session = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
    const currentPath = req.nextUrl.pathname;

    // Проверка на forceLogout
    if (session?.forceLogout) {
        if (!currentPath.startsWith("/auth/login")) {
            const response = NextResponse.redirect(new URL("/auth/login", req.url));
            response.headers.set("Set-Cookie", "next-auth.session-token=; Path=/; Max-Age=0; HttpOnly; Secure");
            return response;
        } else {
            const response = NextResponse.next();
            response.headers.set("Set-Cookie", "next-auth.session-token=; Path=/; Max-Age=0; HttpOnly; Secure");
            return response;
        }
    }

    // Проверка ролей и перенаправление
    switch (session?.role) {
        case Role.Seller:
        case Role.Manager:
        case Role.Executor:
        case Role.Designer:
        case Role.Admin:
            if (!currentPath.startsWith("/dashboard")) {
                return NextResponse.redirect(new URL("/dashboard", req.url));
            }
            break;
        case Role.Customer:
            if (!currentPath.startsWith("/account")) {
                return NextResponse.redirect(new URL("/account/products", req.url));
            }
            break;
        default:
            if (!currentPath.startsWith("/auth/login")) {
                return NextResponse.redirect(new URL("/auth/login", req.url));
            }
    }

    return NextResponse.next();
}

export const config = {
    matcher: ["/dashboard/:path*", "/account/:path*", "/"]
};
